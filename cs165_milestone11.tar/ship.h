#ifndef ship_h
#define ship_h

#define SHIP_SIZE 10

#define ROTATE_AMOUNT 6
#define THRUST_AMOUNT 0.5

#define ANGLE_START 45

#include "point.h"
#include "flyingObject.h"

class Ship : public FlyingObject
{
private:
	/**********************************************************

	**********************************************************/
	int  thrust;

public:
	Ship();

	Ship(Point point);

	/****************
	* Basic Getters
	****************/
	
	int getThrust()  const { return thrust;}


	/*****************
	* Drawing
	*****************/
	virtual void draw();

	/*****************
	* Movement
	*****************/
	void rotateLeft();
	void rotateRight();
	void moveForward ();

};

#endif /* ship_h */
