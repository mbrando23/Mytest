/*****************************************************
* File: flyingObjects.cpp
* Author: Br. Milton Nogueira Brando Neto
*
* Everything we need to know about how to fly into the game.
******************************************************/


#include "flyingObject.h"


///////////////////////////////////////
// CONSTRUCTORS
///////////////////////////////////////

/********************************************
FLYING OBJECTS :: CONSTRUCTOR
defaul constructor
********************************************/
FlyingObject::FlyingObject()
{
	setAlive(true);
	velocity.setDx(0.0);
	velocity.setDy(0.0);
	Point();
}


///////////////////////////////////////
// GETTERS
///////////////////////////////////////

/********************************************
FLYING OBJECTS :: GETPOINT
return point member
********************************************/
Point FlyingObject::getPoint() const
{
	return point;
}

/********************************************
FLYING OBJECTS :: GETVELOCITY
return velocity member
********************************************/
Velocity FlyingObject::getVelocity() const
{
	return velocity;
}


int FlyingObject::getHealth() const
{
	return health;
}

/********************************************
FLYING OBJECTS :: ISALIVE
return alive or not
********************************************/
bool FlyingObject::isAlive() const
{
	return alive;
}



///////////////////////////////////////
// SETTERS
///////////////////////////////////////


/********************************************
FLYING OBJECTS :: SETPOINT
set a point for flying objects
********************************************/
void FlyingObject::setPoint(Point point)
{
	this->point = point;
}

/********************************************
FLYING OBJECTS :: SETALIVE
set alive or not for a flying object
********************************************/
void FlyingObject::setAlive(bool alive)
{
	this->alive = alive;
}


/********************************************
FLYING OBJECTS :: SETVELOCITY
set velocity for a flying object
********************************************/
void FlyingObject::setVelocity(Velocity velocity)
{
	this->velocity = velocity;
}


///////////////////////////////////////
// OTHERS
///////////////////////////////////////

/********************************************
FLYING OBJECTS :: ADVANCE

********************************************/
void FlyingObject::advance()
{
	point.addX(velocity.getDx());
	point.addY(velocity.getDy());

	if (point.getX() > 200)
		point.setX(-200);
	else if (point.getX() < -200)
		point.setX(200);

	if (point.getY() > 200)
		point.setY(-200);
	else if (point.getY() < -200)
		point.setY(200);
}




/********************************************
FLYING OBJECTS :: KILL
set velocity for a flying object
********************************************/
void FlyingObject::kill()
{
	setAlive(false);
	// the instructions do not say anything about this function
	
}





