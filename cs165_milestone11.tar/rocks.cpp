/*****************************************************
* File: rocks.cpp
* Author: Br. Milton Nogueira Brando Neto
*
* Description: This file contains the methods for rocks.
******************************************************/


#include "rocks.h"
#include <cmath> // used for sin, cos, and M_PI

# define M_PI  3.14159265358979323846 /* pi */

// Put your Rock methods here

///////////////////////////////////////
// CONSTRUCTORS
///////////////////////////////////////

/*********************************************
* Default Constructor
*********************************************/
BigRock::BigRock()
{
	float y = random(-200, 200);
	float x = random(-200, 200);

	point.setY(y);
	point.setX(x);

	float dx = 1 * (-sin(M_PI / 180.0 * (random(0, 360))));
	float dy = 1 * (cos(M_PI / 180.0 * (random(0, 360))));
	velocity.setDx(dx);
	velocity.setDy(dy);
	
}


/*********************************************
* Non Default Constructor
*********************************************/
BigRock::BigRock(Point point)
{
	setPoint(point);
}


/*********************************************
* Default Constructor
*********************************************/
MediumRock::MediumRock()
{
	float y = random(-200, 200);
	float x = random(-200, 200);

	point.setY(y);
	point.setX(x);

	
	velocity.setDy(random(-1.0, 1.0));
	velocity.setDx(random(-1.0, 1.0));

	if (velocity.getDy() == 0.0)
		velocity.setDy(1.0);
	if (velocity.getDx() == 0.0)
		velocity.setDx(1.0);
}


/*********************************************
* Non Default Constructor
*********************************************/
MediumRock::MediumRock(Point point)
{
	setPoint(point);
}



/*********************************************
* Default Constructor
*********************************************/
SmallRock::SmallRock()
{
	float y = random(-200, 200);
	float x = random(-200, 200);

	point.setY(y);
	point.setX(x);

	velocity.setDy(random(-1.0, 1.0));
	velocity.setDx(random(-1.0, 1.0));

	if (velocity.getDy() == 0.0)
		velocity.setDy(1.0);
	if (velocity.getDx() == 0.0)
		velocity.setDx(1.0);
}


/*********************************************
* Non Default Constructor
*********************************************/
SmallRock::SmallRock(Point point)
{
	setPoint(point);
}






///////////////////////////////////////
// OTHERS
///////////////////////////////////////

/********************************************
BIG :: HIT
********************************************/
int BigRock::hit()
{
	setAlive(false);


	return 1;
}


/********************************************
BIG :: DRAW
********************************************/
void BigRock::draw()
{
	drawLargeAsteroid(point, rotate += BIG_ROCK_SPIN);
}


/********************************************
MEDIUM :: HIT
********************************************/
int MediumRock::hit()
{
	setAlive(false);
	return 1;
}


/********************************************
MEDIUM :: DRAW
********************************************/
void MediumRock::draw()
{
	drawMediumAsteroid(point, rotate += MEDIUM_ROCK_SPIN);
}



/********************************************
SMALL :: HIT
********************************************/
int SmallRock::hit()
{
	setAlive(false);
	return 1;
}


/********************************************
SMALL :: DRAW
********************************************/
void SmallRock::draw()
{
	drawSmallAsteroid(point, rotate += SMALL_ROCK_SPIN);
}