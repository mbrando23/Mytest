/*************************************************************
* File: ship.cpp
* Author: Br. Milton
*
* Description: Contains the function bodies for the ship class.
*************************************************************/

#include "point.h"
#include "uiDraw.h"

#include <cassert>

#include "ship.h"

#include <cmath> // used for sin, cos, and M_PI

# define M_PI  3.14159265358979323846 /* pi */

/*********************************************
* Default Constructor
*********************************************/
Ship::Ship() 
{

	point.setY(50);
	point.setX(50);
	angle = ANGLE_START;
	velocity.setDy(0);
	velocity.setDx(0);
}

/*********************************************
* Non Default Constructor
*********************************************/
Ship::Ship(Point point)
{
	setPoint(point);
}



void Ship::draw() 
{
	drawShip(point, angle, thrust);
}

void Ship::rotateLeft()
{
	angle += ROTATE_AMOUNT;


}



void Ship::rotateRight()
{
	angle -= ROTATE_AMOUNT;


}




void Ship::moveForward()
{
	float dx = (THRUST_AMOUNT * (-sin(M_PI / 180.0 * (angle)))) + velocity.getDx();
	float dy = (THRUST_AMOUNT * (cos(M_PI / 180.0 * (angle)))) + velocity.getDy();
	
	velocity.setDx(dx);
	velocity.setDy(dy);
}