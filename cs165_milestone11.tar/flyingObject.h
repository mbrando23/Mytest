/***********************************************************************
* Header File:
*    BASE : The representation of flying objects.
* Author:
*    Milton Nogueira Brando Neto
* Summary:
*    Description: This file contains the methods of a flying
*    object. This is also a base class.
************************************************************************/

#ifndef FLYINGOBJECTS_H
#define FLYINGOBJECTS_H

#include "uiDraw.h"
#include "point.h"
#include "velocity.h"


class FlyingObject
{
public:

	FlyingObject();

	void advance();

	virtual void draw() = 0;

	Point getPoint() const;

	int getHealth() const;

	Velocity getVelocity() const;

	bool isAlive() const;

	void kill(); 

	void setPoint(Point point);

	void setAlive(bool alive);

	void setVelocity(Velocity velocity);

	float getAngle() const { return angle; }



protected:

	Point point;

	Velocity velocity;

	bool alive;

	float angle;

	int health;

};







#endif /* FLYINGOBJECTS_H */
