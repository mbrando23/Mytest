#ifndef MAP_H
#define MAP_H

#include <iostream>
#include "bst.h"
#include "pair.h"

namespace custom
{
/*****************************************************************
 * class map
 * Create a Map based on Binary Search Tree
 *****************************************************************/
template <class K, class V>
class map
{
private:
    // typedef for map data
    typedef Pair<K,V> TMapData;

public:
    class iterator;

    virtual ~map();
    map();
    map(const map& rhs) throw (const char *);
    map& operator=(const map& rhs) throw (const char *);
    V& operator[](const K& key) throw (const char *);
    V operator[](const K& key) const throw (const char *);

    int size() const { return this->bst.size(); }
    bool empty() const { return this->bst.empty(); }
    void clear() { this->bst.clear(); }

    void insert(const TMapData& input) throw (const char *);
    void insert(const K& key, const V& value) throw (const char *);
    iterator find(const K& key);
    iterator begin();
    iterator end();



private:
    BST<TMapData> bst;
};

/*****************************************************************
 * class map::iterator
 * Define a nested class Iterator for Map
 *****************************************************************/
template <class K, class V>
class map<K,V>::iterator
{
public:
    iterator ()
        { }

    iterator(const typename BST<TMapData>::iterator& rhs)
        { this->it = rhs; }

    iterator(const iterator& rhs)
        { (*this) = rhs; }

    iterator& operator=(const iterator& rhs)
        { this->it = rhs.it; return (*this); }

    bool operator==(const iterator& rhs) const
        { return this->it == rhs.it; }

    bool operator!=(const iterator& rhs) const
        { return this->it != rhs.it; }

    iterator& operator++()
    {
        ++(this->it);
        return (*this);
    }

    iterator operator++(int postfix)
    {
        iterator itReturn = (*this);
        ++(this->it);
        return itReturn;
    }

    iterator& operator--()
    {
        --(this->it);
        return (*this);
    }

    iterator operator--(int postfix)
    {
        iterator itReturn = (*this);
        --(this->it);
        return itReturn;
    }

    const Pair<K,V>& operator*()
        { return *(this->it); }

private:
    typename BST<TMapData>::iterator it;
};

/******************************************************
* MAP :: DESTRUCTOR
* Delete memory of map
******************************************************/
template <class K, class V>
map<K,V>::~map()
{
    clear();
}

/******************************************************
* MAP :: CONSTRUCTOR (DEFAULT)
* Create a map with default values
******************************************************/
template <class K, class V>
map<K,V>::map()
{
}

template <class K, class V>
map<K,V>::map(const map<K,V>& rhs) throw (const char *)
{
    (*this) = rhs;
}

template <class K, class V>
map<K,V>& map<K,V>::operator=(const map<K,V>& rhs) throw (const char *)
{
    this->bst = rhs.bst;
    return (*this);
}

template <class K, class V>
V& map<K,V>::operator[](const K& key) throw (const char *)
{
    typename BST<TMapData>::iterator it;
    TMapData data;

    data.first = key;
    it = this->bst.find(data);
    if (it == this->bst.end())
    // not found so insert
    {
        this->bst.insert(data);
        it = this->bst.find(data);
    }

    return (*it).second;
}

template <class K, class V>
V map<K,V>::operator[](const K& key) const throw (const char *)
{
    return this->operator[](key);
}

/******************************************************
 * MAP :: INSERT (key, value)
 * Insert a pair with key-value
 ******************************************************/
template <class K, class V>
void map<K,V>::insert(const Pair<K,V>& data) throw (const char *)
{
    typename BST<TMapData>::iterator it;

    it = this->bst.find(data);
    if (it != this->bst.end())
        (*it) = data;
    else
        this->bst.insert(data);
}

/******************************************************
 * MAP :: INSERT (key, value)
 * Insert a key with its value in the map
 ******************************************************/
template <class K, class V>
void map<K,V>::insert(const K& key, const V& value) throw (const char *)
{
    TMapData data(key, value);
    typename BST<TMapData>::iterator it;

    it = this->bst.find(data);
    if (it != this->bst.end())
        (*it) = data;
    else
        this->bst.insert(data);
}

/******************************************************
 * MAP :: FIND (key)
 * If found, return an iterator pointing to data with key
 * If not, return end()
 ******************************************************/
template <class K, class V>
typename map<K,V>::iterator map<K,V>::find(const K& key)
{
    TMapData data;
    data.first = key;
    return iterator(this->bst.find(data));
}

/******************************************************
 * MAP :: BEGIN
 * Returns an iterator pointing the first element in map
 ******************************************************/
template <class K, class V>
typename map<K,V>::iterator map<K,V>::begin()
{
    return iterator(this->bst.begin());
}

/******************************************************
 * MAP :: BEGIN
 * Returns an iterator pointing the last element in map
 ******************************************************/
template <class K, class V>
typename map<K,V>::iterator map<K,V>::end()
{
    return iterator(this->bst.end());
}

}; // namespace custom

#endif // MAP_H

