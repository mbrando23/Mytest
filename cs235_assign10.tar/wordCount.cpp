/***********************************************************************
 * Module:
 *    Week 10, WORD COUNT
 *    Brother Jones L, CS 235
 * Author:
 *    <your name here>
 * Summary:
 *    This program will implement the wordCount() function
 ************************************************************************/
#include <iostream>
#include <fstream>
#include <string>
#include "map.h"       // for MAP
#include "wordCount.h" // for wordCount() prototype
using namespace std;
using namespace custom;

typedef map <string, int> TMapCount;

void readFile(TMapCount & counts, const string & fileName)
{
    // open the file
    ifstream fin(fileName.c_str());
    if (fin.fail())
    {
        cout << "ERROR: Unable to open file " << fileName << endl;
        return;
    }

    // read one word at a time and tabulate
    string word;
    while (fin >> word)
    {
        TMapCount::iterator it = counts.find(word);

        if (it == counts.end())
        // word not exists, so insert and count is one
            counts.insert(word, 1);
        else
        // word exists so increments number
            counts[word]++;
    }

    // all done
    fin.close();
    return;
}

/*****************************************************
 * WORD COUNT
 * Prompt the user for a file to read, then prompt the
 * user for words to get the count from
 *****************************************************/
void wordCount()
{
    TMapCount mapCount;
    string filename;
    string word;
    bool doLoop;

    cin.clear();
    cin.ignore();

    cout << "What is the filename to be counted? ";
    getline(cin, filename);

    readFile(mapCount, filename);

    cout << "What word whose frequency is to be found. Type ! when done" << endl;
    do
    {
        TMapCount::iterator it;

        cout << "> ";
        getline(cin, word);

        // check for end of loop
        if (word == "!")
            doLoop = false;
        else
            doLoop = true;

        if (doLoop == true)
        {
            // find word y get cout
            it = mapCount.find(word);
            if (it != mapCount.end())
                cout << "\t" << word << " : " << (*it).second << endl;
            else
                cout << "\t" << word << " : " << 0 << endl;
        }
    }
    while (doLoop == true);
}