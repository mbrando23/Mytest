/***********************************************************************
 * Header File:
 *    LANDER : A class representing the lunar craft.
 * Author:
 *    Br. Milton Nogueira B Neto
 * Summary:
 *    Everything about a lunar lander.
 ************************************************************************/

#ifndef LANDER_H
#define LANDER_H

#include "point.h"
#include "velocity.h"
#include "uiDraw.h"

/********************************************
 * LANDER
 * So easy for an astronaut
 ********************************************/

class Lander
{
   private:
      // it needs a place
      Point point;
	
      // it has inertia
      Velocity velocity;

      // stores its fuel
      int fuel;

      // alive or not state
      bool alive;

      // landed or not state
      bool landed;

   public:

      Lander();                          // default constructor

      Point getPoint() const;            // return point member

      Velocity getVelocity() const;      // return velocity member

      bool isAlive() const;              // return alive or not 
	
      bool isLanded() const;             // return landed or not

      int getFuel() const;               // return how much fuel

      bool canThrust();                  // return if lander can thrust or not

      void setLanded(bool landed);       // set if eagle has landed

      void setAlive(bool alive);         // set if lander is alive 

      void setFuel(int fuel);            // set how much fuel

      void applyGravity(float gravity);  // set the environment gravity

      void applyThrustLeft();            // set left lander push

      void applyThrustRight();           // set right lander push

      void applyThrustBottom();          // set bottom push

      void advance();                    // add from the velocity object

      void draw() const;                 // draw from the point object

	  void restart();                    // restart the game

};

#endif
