/***********************************************************************
 * Implementation File:
 *    LANDER : Representative of a craft lander.
 * Author:
 *    Br. Milton Nogueira B Neto
 * Summary:
 *    Everything about a lunar lander.
 ************************************************************************/

#include "lander.h"
const float LEFT_AMOUNT  = 0.1;
const float RIGHT_AMOUNT = 0.1;
const float UP_AMOUNT    = 0.3;

/********************************************
LANDER :: CONSTRUCTOR
set lander into the top of the screen 
********************************************/
Lander::Lander()
{  
   point.setX(random(-200, 200));
   point.setY(175);
   setLanded(false);
   setAlive(true);
   setFuel(500);
}

/********************************************
LANDER :: GETPOINT
return point member
********************************************/
Point Lander::getPoint() const
{
   return point;
}

/********************************************
LANDER :: GETVELOCITY
return velocity member
********************************************/
Velocity Lander::getVelocity() const
{
   return velocity;
}

/********************************************
LANDER :: ISALIVE
return alive or not
********************************************/
bool Lander::isAlive() const
{
   return alive;
}

/********************************************
LANDER :: ISLANDED
return landed or not
********************************************/
bool Lander::isLanded() const
{
   return landed;
}

/********************************************
LANDER :: GETFUEL
return how much fuel
********************************************/
int Lander::getFuel() const
{
   return fuel;
}

/********************************************
LANDER :: CANTHRUST
return if lander can thrust or not
********************************************/
bool Lander::canThrust()
{
   return (isAlive() && !isLanded() && fuel > 0);
}

/********************************************
LANDER :: SETLANDED
set if eagle has landed
********************************************/
void Lander::setLanded(bool landed)
{
   this->landed = landed;

}

/********************************************
LANDER :: SETALIVE
set if lander is alive
********************************************/
void Lander::setAlive(bool alive)
{
   this->alive = alive;
}

/********************************************
LANDER :: SETFUEL
set how much fuel
********************************************/
void Lander::setFuel(int fuel)
{
   this->fuel = fuel;
}

/********************************************
LANDER :: APPLYGRAVITY
set the environment gravity         
********************************************/
void Lander::applyGravity(float gravity)
{
   velocity.setDy(velocity.getDy() - gravity);
}

/********************************************
LANDER :: APPLYTHRUSTLEFT
velocity object's changes with the lander's 
velocity object
********************************************/
void Lander::applyThrustLeft()
{
   if (fuel > 0)
   {
      velocity.setDx(velocity.getDx() + LEFT_AMOUNT);
      fuel--;
   }
   if (fuel < 0)
   {
      fuel = 0; // assure fuel is zero when finished
   }
}

/********************************************
LANDER :: APPLYTHRUSTRIGHT
velocity object's changes with the lander's 
velocity object
********************************************/
void Lander::applyThrustRight()
{
   if (fuel > 0)
   {
      velocity.setDx(velocity.getDx() - RIGHT_AMOUNT);
      fuel--;
   }
   if (fuel < 0)
   {
      fuel = 0; // assure fuel is zero when finished
   }
}

/********************************************
LANDER :: APPLYTHRUSTBOTTOM
velocity object's changes with the lander's 
velocity object
********************************************/
void Lander::applyThrustBottom()
{
   if (fuel > 0)
   {
      velocity.setDy(velocity.getDy() + UP_AMOUNT);
      fuel -= 3;
   }
   if (fuel < 0)
   {
      fuel = 0; // assure fuel is zero when finished
   } 
}

/********************************************
LANDER :: ADVANCE
add from the velocity object        
********************************************/
void Lander::advance()
{
   point.addX(velocity.getDx());
   point.addY(velocity.getDy());
}

/********************************************
LANDER :: DRAW
can draw it on the screen.
********************************************/
void Lander::draw() const
{
   if (isAlive())
   {
      drawLander(point);
   }
}


/********************************************
LANDER :: RESTART
we can "restart" the game
********************************************/
void Lander::restart() 
{	
	setLanded(0);
	setFuel(500);
	setAlive(1);
	point.setY(175);
	point.setX(random(-200, 200));
	velocity.setDy(0);
	velocity.setDx(0);

}
