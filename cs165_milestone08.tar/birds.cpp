/*****************************************************
* File: Bird.cpp
* Author: Br. Milton
*
* Description: This file contains
******************************************************/


#include "birds.h"


/*********************************************
* Default Constructor
*********************************************/
Birds::Birds()
{
	float y = random(-200, 200);
	float x = -200;
	point.setY(y);
	point.setX(x);

	if (y > 0)
	{
		velocity.setDy(random(-4, -1));
		velocity.setDx(random(3, 6));
	}
	else
	{
		velocity.setDy(random(1, 4));
		velocity.setDx(random(3, 6));
	}
}


/*********************************************
* Non Default Constructor
*********************************************/
Birds :: Birds(Point point)
{
	setPoint(point);
}


int Birds::hit()
{

	setAlive(false);
	return 1;

/*  The hit() method for the Bird represents the bird being hit 
 *  and should either kill the bird (or decrement the number of 
 *  hits remaining for the tough bird) and return an integer 
 *  representing the points scored for that hit.*/


}



/********************************************
BIRD :: DRAW
can draw it on the screen.
********************************************/
void Birds::draw()
{
	
}