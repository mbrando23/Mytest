/* Header File:
 * BirdTough : The representation of a tough bird
 * Author :
 * Milton Nogueira Brando Neto
 * Summary :
 * Everything we need to know about a tough bird.
 ************************************************************************/

#ifndef TOUGH_H
#define TOUGH_H

#include "birds.h"


class Tough : public Birds
{
   public:

	   Tough();

       int getHealth() const;

	   int hit();

	   void draw();
	  



   private:

      int health;







};



#endif /* TOUGH_H */
