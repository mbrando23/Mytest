/*****************************************************
* File: birdStandard.cpp
* Author: Br. Milton
*
* Description: This file contains
******************************************************/


#include "birdStandard.h"


/*********************************************
* Default Constructor
*********************************************/
Standard::Standard()
{




}


int Standard::hit()
{
	setAlive(false);
	return 1;

}

void Standard ::draw()
{
	drawCircle(point, 15);

}