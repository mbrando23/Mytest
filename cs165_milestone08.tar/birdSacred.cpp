/*****************************************************
* File: birdSacred.cpp
* Author: Br. Milton
*
* Description: This file contains
******************************************************/


#include "birdSacred.h"


/*********************************************
* Default Constructor
*********************************************/
Sacred::Sacred()
{




}

int Sacred::hit()
{
	setAlive(false);
	return 1;

}

void Sacred::draw()
{
	drawSacredBird(point, 15);

}