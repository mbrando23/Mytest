/***********************************************************************
* Header File:
*    BASE : The representation of flying objects.
* Author:
*    Milton Nogueira Brando Neto
* Summary:
*    Everything we need to know about how flying into the game.
************************************************************************/

#ifndef BASE_H
#define BASE_H

#include "uiDraw.h"
#include "point.h"
#include "velocity.h"


class Base
{
public:

	Base();

	void advance();

	void draw();

	Point getPoint() const;

	Velocity getVelocity() const;

	bool isAlive() const;

	void kill(); 

	void setPoint(Point point);

	void setAlive(bool alive);

	void setVelocity(Velocity velocity);



protected:

	Point point;

	Velocity velocity;

	bool alive;

};







#endif /* BASE_H */
