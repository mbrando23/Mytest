/*****************************************************
* File: birdTough.cpp
* Author: Br. Milton
*
* Description: This file contains
******************************************************/


#include "birdTough.h"


/*********************************************
* Default Constructor
*********************************************/
Tough::Tough()
{
	health = 3;

}




/********************************************
BIRD :: DRAW
can draw it on the screen.
********************************************/
int Tough::getHealth() const
{
	
	return health;


}


int Tough :: hit()
{
	if (health > 0)
		health--;
	if (health == 0)
		setAlive(false);
	
	return health;
}

void Tough :: draw()
{

	drawToughBird(point, 15, health);

}