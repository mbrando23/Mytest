/*****************************************************
* File: Bullet.cpp
* Author: Br. Milton
*
* Description: This file contains
******************************************************/


#include "bullets.h"
#include <cmath> // used for sin, cos, and M_PI

#define BULLET_SPEED 10.0
# define M_PI  3.14159265358979323846 /* pi */



/*********************************************
* Constructor
*********************************************/
Bullet :: Bullet()
{
	point.setX(199);
	point.setY(-199);
	angle = 60.0;
}

/*********************************************
* Fire
*********************************************/
void Bullet :: fire(Point point, float angle)
{
	float dx = BULLET_SPEED * (-cos(M_PI / 180.0 * angle));
	float dy = BULLET_SPEED * (sin(M_PI / 180.0 * angle));
	velocity.setDx(dx);
	velocity.setDy(dy);
	setPoint(point);
}




