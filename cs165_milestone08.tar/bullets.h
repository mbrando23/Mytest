/***********************************************************************
* Header File:
*    Bullet : The representation of a bullet
* Author:
*    Milton Nogueira Brando Neto
* Summary:
*    Everything we need to know about a bullet.
************************************************************************/

#ifndef BULLETS_H
#define BULLETS_H

#include "base.h"


class Bullet : public Base
{
public:

	Bullet();

	void fire(Point point, float angle);

private:

	float angle;

};



#endif /* BULLETS_H */