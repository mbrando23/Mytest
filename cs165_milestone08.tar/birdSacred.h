/* Header File :
 * BirdSacred : The representation of a sacred bird
 * Author :
 * Milton Nogueira Brando Neto
 * Summary :
 * Everything we need to know about a sacred bird.
 ************************************************************************/

#ifndef SACRED_H
#define SACRED_H

#include "birds.h"


class Sacred : public Birds
{
   public:
	   Sacred();

	   int hit();

	   void draw();

   private:










};



#endif /* SACRED_H */