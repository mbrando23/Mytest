/* Header File :
 * BirdStandard : The representation of a standard bird
 * Author :
 * Milton Nogueira Brando Neto
 * Summary :
 * Everything we need to know about a standard bird.
 ************************************************************************/

#ifndef STANDARD_H
#define STANDARD_H

#include "birds.h"


class Standard : public Birds
{
   public:
	   Standard();

	   int hit();

	   void draw();


   private:









};



#endif /* STANDARD_H */
