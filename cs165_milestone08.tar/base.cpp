/*****************************************************
* File: Base.cpp
* Author: Br. Milton
*
* Description: This file contains the methods of a flying
* object.
******************************************************/


#include "base.h"


///////////////////////////////////////
// CONSTRUCTORS
///////////////////////////////////////

/********************************************
BASE :: CONSTRUCTOR
defaul constructor
********************************************/
Base::Base()
{
	setAlive(true);
	velocity.setDx(0.0);
	velocity.setDy(0.0);
	Point();
}


///////////////////////////////////////
// GETTERS
///////////////////////////////////////

/********************************************
BASE :: GETPOINT
return point member
********************************************/
Point Base::getPoint() const
{
	return point;
}

/********************************************
BASE :: GETVELOCITY
return velocity member
********************************************/
Velocity Base::getVelocity() const
{
	return velocity;
}


/********************************************
BASE :: ISALIVE
return alive or not
********************************************/
bool Base::isAlive() const
{
	return alive;
}



///////////////////////////////////////
// SETTERS
///////////////////////////////////////


/********************************************
BASE :: SETPOINT
set a point for flying objects
********************************************/
void Base::setPoint(Point point)
{
	this->point = point;
}

/********************************************
BASE :: SETALIVE
set alive or not for a flying object
********************************************/
void Base::setAlive(bool alive)
{
	this->alive = alive;
}


/********************************************
BASE :: SETVELOCITY
set velocity for a flying object
********************************************/
void Base::setVelocity(Velocity velocity)
{
	this->velocity = velocity;
}


///////////////////////////////////////
// OTHERS
///////////////////////////////////////


void Base::advance()
{
	point.addX(velocity.getDx());
	point.addY(velocity.getDy());
}


void Base::draw()
{
	drawDot(point);
}


void Base::kill()
{
	setAlive(false);
	// the instructions do not say anything about this function
	
}





