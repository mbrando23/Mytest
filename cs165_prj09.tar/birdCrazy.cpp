
/*****************************************************
* File: birdCrazy.cpp
* Author: Br. Milton Nogueira Brando Neto
*
* Description: This file contains the methods for a bird that seems
*              like a crazy box.
******************************************************/


#include "birdCrazy.h"


///////////////////////////////////////
// CONSTRUCTORS
///////////////////////////////////////


/*********************************************
* Default Constructor
*********************************************/
Crazy::Crazy()
{
	float y = random(-200, 200);
	float x = -200;
	point.setY(y);
	point.setX(x);

	if (y > 0)
	{
		velocity.setDy(random(-6, -4));
		velocity.setDx(random(4, 6));
	}
	else
	{
		velocity.setDy(random(4, 6));
		velocity.setDx(random(4, 6));
	}

}

///////////////////////////////////////
// OTHERS
///////////////////////////////////////

/********************************************
HEART :: HIT
returns how many points
********************************************/
int Crazy::hit()
{
	setAlive(false);
	return 5;

}

/********************************************
HEART :: DRAW
draw the bird on the screen
********************************************/
void Crazy::draw()
{
	drawCircle(point, 8);
	drawCircle(point, 10);
	drawCircle(point, 12);
	drawPolygon(point);

}
