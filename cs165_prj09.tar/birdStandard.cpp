/*****************************************************
* File: birdStandard.cpp
* Author: Br. Milton
*
* Description: This file contains
******************************************************/


#include "birdStandard.h"

///////////////////////////////////////
// CONSTRUCTORS
///////////////////////////////////////


/*********************************************
* Default Constructor
*********************************************/
Standard::Standard()
{
	float y = random(-200, 200);
	float x = -200;
	point.setY(y);
	point.setX(x);

	if (y > 0)
	{
		velocity.setDy(random(-4, -1));
		velocity.setDx(random(3, 6));
	}
	else
	{
		velocity.setDy(random(1, 4));
		velocity.setDx(random(3, 6));
	}

}


///////////////////////////////////////
// OTHERS
///////////////////////////////////////

/********************************************
STANDARD :: HIT
returns how many points
********************************************/
int Standard::hit()
{
	setAlive(false);
	return 1;

}


/********************************************
STANDARD :: DRAW
draw the bird on the screen
********************************************/
void Standard ::draw()
{
	drawCircle(point, 15);

}