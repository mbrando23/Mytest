/*****************************************************
* File: flyingObjects.cpp
* Author: Br. Milton Nogueira Brando Neto
*
* Everything we need to know about how to fly into the game.
******************************************************/


#include "flyingObjects.h"


///////////////////////////////////////
// CONSTRUCTORS
///////////////////////////////////////

/********************************************
FLYING OBJECTS :: CONSTRUCTOR
defaul constructor
********************************************/
FlyingObjects::FlyingObjects()
{
	setAlive(true);
	velocity.setDx(0.0);
	velocity.setDy(0.0);
	Point();
}


///////////////////////////////////////
// GETTERS
///////////////////////////////////////

/********************************************
FLYING OBJECTS :: GETPOINT
return point member
********************************************/
Point FlyingObjects::getPoint() const
{
	return point;
}

/********************************************
FLYING OBJECTS :: GETVELOCITY
return velocity member
********************************************/
Velocity FlyingObjects::getVelocity() const
{
	return velocity;
}


/********************************************
FLYING OBJECTS :: ISALIVE
return alive or not
********************************************/
bool FlyingObjects::isAlive() const
{
	return alive;
}



///////////////////////////////////////
// SETTERS
///////////////////////////////////////


/********************************************
FLYING OBJECTS :: SETPOINT
set a point for flying objects
********************************************/
void FlyingObjects::setPoint(Point point)
{
	this->point = point;
}

/********************************************
FLYING OBJECTS :: SETALIVE
set alive or not for a flying object
********************************************/
void FlyingObjects::setAlive(bool alive)
{
	this->alive = alive;
}


/********************************************
FLYING OBJECTS :: SETVELOCITY
set velocity for a flying object
********************************************/
void FlyingObjects::setVelocity(Velocity velocity)
{
	this->velocity = velocity;
}


///////////////////////////////////////
// OTHERS
///////////////////////////////////////

/********************************************
FLYING OBJECTS :: ADVANCE

********************************************/
void FlyingObjects::advance()
{
	point.addX(velocity.getDx());
	point.addY(velocity.getDy());
}




/********************************************
FLYING OBJECTS :: KILL
set velocity for a flying object
********************************************/
void FlyingObjects::kill()
{
	setAlive(false);
	// the instructions do not say anything about this function
	
}





