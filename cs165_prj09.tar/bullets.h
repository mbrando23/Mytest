/***********************************************************************
* Header File:
*    Bullet : The representation of a bullet
* Author:
*    Milton Nogueira Brando Neto
* Summary:
*    Everything we need to know about firing into the game.
************************************************************************/

#ifndef BULLETS_H
#define BULLETS_H

#include "flyingObjects.h"
#include <vector>


class Bullet : public FlyingObjects
{
public:

	Bullet();

	void draw();

	void fire(Point point, float angle);

	void machineGun(Point point, float angle);

	void shotGun(Point point, float angle, std::vector<Bullet>& bullets);

private:

	float angle;

};



#endif /* BULLETS_H */