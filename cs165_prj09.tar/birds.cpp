/*****************************************************
* File: bird.cpp
* Author: Br. Milton Nogueira Brando Neto
*
* Description: This file contains the methods for birds.
******************************************************/


#include "birds.h"


///////////////////////////////////////
// CONSTRUCTORS
///////////////////////////////////////

/*********************************************
* Default Constructor
*********************************************/
Birds::Birds()
{

}


/*********************************************
* Non Default Constructor
*********************************************/
Birds :: Birds(Point point)
{
	setPoint(point);
}



///////////////////////////////////////
// OTHERS
///////////////////////////////////////

/********************************************
BIRD :: HIT
pure virtual
********************************************/
int Birds::hit()
{

	setAlive(false);
	return 1;

/*  The hit() method for the Bird represents the bird being hit 
 *  and should either kill the bird (or decrement the number of 
 *  hits remaining for the tough bird) and return an integer 
 *  representing the points scored for that hit.*/


}


/********************************************
BIRD :: DRAW
pure virtual
********************************************/
void Birds::draw()
{
	
}