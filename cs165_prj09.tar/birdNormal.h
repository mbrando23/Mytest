/* Header File :
*  birdNormal : The representation of a normal bird
*  Author :
*  Milton Nogueira Brando Neto
*  Summary :
*  Everything we need to know about a normal bird.
************************************************************************/

#ifndef NORMAL_H
#define NORMAL_H

#include "birds.h"


class Normal : public Birds
{
public:
	Normal();

	virtual int hit();

	virtual void draw();

private:


};



#endif /* NORMAL_H */



