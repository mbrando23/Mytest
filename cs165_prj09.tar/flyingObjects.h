/***********************************************************************
* Header File:
*    BASE : The representation of flying objects.
* Author:
*    Milton Nogueira Brando Neto
* Summary:
*    Description: This file contains the methods of a flying
*    object. This is also a base class.
************************************************************************/

#ifndef FLYINGOBJECTS_H
#define FLYINGOBJECTS_H

#include "uiDraw.h"
#include "point.h"
#include "velocity.h"


class FlyingObjects
{
public:

	FlyingObjects();

	void advance();

	virtual void draw() = 0;

	Point getPoint() const;

	Velocity getVelocity() const;

	bool isAlive() const;

	void kill(); 

	void setPoint(Point point);

	void setAlive(bool alive);

	void setVelocity(Velocity velocity);



protected:

	Point point;

	Velocity velocity;

	bool alive;

};







#endif /* FLYINGOBJECTS_H */
