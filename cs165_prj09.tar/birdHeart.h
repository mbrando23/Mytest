/* Header File :
*  birdHeart : The representation of a bird.
*  Author :
*  Milton Nogueira Brando Neto
*  Summary :
*  Everything we need to know about a bird that looks like a heart. 
************************************************************************/

#ifndef HEART_H
#define HEART_H

#include "birds.h"


class Heart : public Birds
{
public:
	Heart();

	virtual int hit();

	virtual void draw();

private:


};



#endif /* HEART_H */
