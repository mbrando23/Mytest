
/*****************************************************
* File: birdHeart.cpp
* Author: Br. Milton Nogueira Brando Neto
*
* Description: This file contains the methods for a bird that seems
*              like a red heart.
******************************************************/


#include "birdHeart.h"


///////////////////////////////////////
// CONSTRUCTORS
///////////////////////////////////////


/*********************************************
* Default Constructor
*********************************************/
Heart::Heart()
{
	float y = random(-200, 200);
	float x = -200;
	point.setY(y);
	point.setX(x);

	if (y > 0)
	{
		velocity.setDy(random(-6, -4));
		velocity.setDx(random(4, 6));
	}
	else
	{
		velocity.setDy(random(4, 6));
		velocity.setDx(random(4, 6));
	}

}

///////////////////////////////////////
// OTHERS
///////////////////////////////////////

/********************************************
HEART :: HIT
returns how many points
********************************************/
int Heart::hit()
{
	setAlive(false);
	return 10;

}

/********************************************
HEART :: DRAW
draw the bird on the screen
********************************************/
void Heart::draw()
{
	drawHeart(point);
}
