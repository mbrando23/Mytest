/*****************************************************
* File: birdSacred.cpp
* Author: Br. Milton
*
* Description: This file contains
******************************************************/


#include "birdSacred.h"


///////////////////////////////////////
// CONSTRUCTORS
///////////////////////////////////////

/*********************************************
* Default Constructor
*********************************************/
Sacred::Sacred()
{
	float y = random(-200, 200);
	float x = -200;
	point.setY(y);
	point.setX(x);

	if (y > 0)
	{
		velocity.setDy(random(-4, -1));
		velocity.setDx(random(3, 6));
	}
	else
	{
		velocity.setDy(random(1, 4));
		velocity.setDx(random(3, 6));
	}

}


///////////////////////////////////////
// OTHERS
///////////////////////////////////////


/********************************************
SACRED :: HIT
returns how many points
********************************************/
int Sacred::hit()
{
	setAlive(false);
	return -10;

}

/********************************************
SACRED :: DRAW
draw the bird on the screen
********************************************/
void Sacred::draw()
{
	drawSacredBird(point, 15);

}