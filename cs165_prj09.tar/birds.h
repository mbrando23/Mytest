/***********************************************************************
* Header File:
*    Bird : The representation of a bird
* Author:
*    Milton Nogueira Brando Neto
* Summary:
*    Everything we need to know about a bird. We have an
*    abstract class.
************************************************************************/

#ifndef BIRDS_H
#define BIRDS_H

#include "uiDraw.h"
#include "flyingObjects.h"


class Birds : public FlyingObjects
{
public:

	Birds();
	
	Birds(Point point);

	virtual int hit() = 0;
	
	virtual void draw() = 0;
	


private:

	


};




#endif /* BIRDS_H */
