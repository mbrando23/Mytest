/*****************************************************
* File: birdTough.cpp
* Author: Br. Milton
*
* Description: This file contains
******************************************************/


#include "birdTough.h"


///////////////////////////////////////
// CONSTRUCTORS
///////////////////////////////////////

/*********************************************
* Default Constructor
*********************************************/
Tough::Tough()
{
	health = 3;
	float y = random(-200, 200);
	float x = -200;
	point.setY(y);
	point.setX(x);

	if (y > 0)
	{
		velocity.setDy(random(-3, -1));
		velocity.setDx(random(2, 4));
	}
	else
	{
		velocity.setDy(random(1, 3));
		velocity.setDx(random(2, 4));
	}
}


///////////////////////////////////////
// GETTER
///////////////////////////////////////

/********************************************
TOUGH :: GETHEALTH
returns how many lives the bird has.
********************************************/
int Tough::getHealth() const
{
	
	return health;


}

///////////////////////////////////////
// OTHERS
///////////////////////////////////////

/********************************************
TOUGH :: HIT
returns the points and decreases health.
********************************************/
int Tough :: hit()
{
	if (health > 1)
	{
		health--;
		return 1;
	}
		
	if (health == 1)
	{
		setAlive(false);
		return 3;
	}
		
	
	return health;
}

/********************************************
TOUGH :: DRAW
draw the bird on the screen
********************************************/
void Tough :: draw()
{

	drawToughBird(point, 15, health);

}