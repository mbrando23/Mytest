/* Header File :
* BirdSacred : The representation of a crazy bird
* Author :
* Milton Nogueira Brando Neto
* Summary :
* Everything we need to know about a crazy bird.
************************************************************************/

#ifndef CRAZY_H
#define CRAZY_H

#include "birds.h"


class Crazy : public Birds
{
public:
	Crazy();

	virtual int hit();

	virtual void draw();

private:



};



#endif /* CRAZY_H */
