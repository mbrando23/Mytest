
/*****************************************************
* File: birdNormal.cpp
* Author: Br. Milton Nogueira Brando Neto
*
* Description: This file contains the methods of normal bird.
******************************************************/


#include "birdNormal.h"


///////////////////////////////////////
// CONSTRUCTORS
///////////////////////////////////////


/*********************************************
* Default Constructor
*********************************************/
Normal::Normal()
{
	float y = random(-200, 200);
	float x = -200;
	point.setY(y);
	point.setX(x);

	if (y > 0)
	{
		velocity.setDy(random(-4, -1));
		velocity.setDx(random(3, 6));
	}
	else
	{
		velocity.setDy(random(1, 4));
		velocity.setDx(random(3, 6));
	}

}

///////////////////////////////////////
// OTHERS
///////////////////////////////////////

/********************************************
NORMAL :: HIT
returns how many points
********************************************/
int Normal::hit()
{
	setAlive(false);
	return 2;

}

/********************************************
NORMAL :: DRAW
draw the bird on the screen
********************************************/
void Normal::draw()
{
	drawNormal(point);

}
