/*****************************************************
* File: Bullet.cpp
* Author: Br. Milton Nogueira Brando Neto
*
* Description: This file contains the methods for bullets.
******************************************************/


#include "bullets.h"
#include <cmath> // used for sin, cos, and M_PI

#define BULLET_SPEED 10.0
#define SHOTGUN_SPEED 6.0
#define MACH_SPEED 8.0
# define M_PI  3.14159265358979323846 /* pi */



/*********************************************
* Constructor
*********************************************/
Bullet :: Bullet()
{
	point.setX(199);
	point.setY(-199);
	angle = 60.0;
}


/********************************************
BULLETS :: DRAW
set velocity for a flying object
********************************************/
void Bullet::draw()
{
	drawDot(point);
}


/*********************************************
* Normal Gun
*********************************************/
void Bullet :: fire(Point point, float angle)
{
	float dx = BULLET_SPEED * (-cos(M_PI / 180.0 * angle));
	float dy = BULLET_SPEED * (sin(M_PI / 180.0 * angle));
	velocity.setDx(dx);
	velocity.setDy(dy);
	setPoint(point);
}


/*********************************************
* Machine Gun
*********************************************/
void Bullet::machineGun(Point point, float angle)
{
	float dx = MACH_SPEED * (-cos(M_PI / 180.0 * angle));
	float dy = MACH_SPEED * (sin(M_PI / 180.0 * angle));
	velocity.setDx(dx);
	velocity.setDy(dy);
	setPoint(point);
}


/*********************************************
* Shot Gun
*********************************************/
void Bullet::shotGun(Point point, float angle, std::vector<Bullet>& bullets)
{
	for (int i = 0; i < 10; i++)
	{
	   Bullet newBullet;
	   float dx = SHOTGUN_SPEED * (-cos(M_PI / 180.0 * (angle + 3*i) ));
	   float dy = SHOTGUN_SPEED * (sin(M_PI / 180.0 * (angle + 3*i)));
	   newBullet.velocity.setDx(dx);
	   newBullet.velocity.setDy(dy);
	   newBullet.setPoint(point);
	   bullets.push_back(newBullet);
    }
}

