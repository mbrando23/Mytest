/***********************************************************************
 * Header:
 *    Graph
 * Summary:
 *    This will contain the class definition of:
 *        Graph         : A class that represents a graph
 *        
 * Author
 *    Luis Orbezua
 ************************************************************************/

#ifndef GRAPH_H
#define GRAPH_H

#include <iostream>
#include <cstring>
#include <vector>
#include <list>
#include <queue>
using namespace std;

#include "set.h"
#include "list.h"
#include "vector.h"
using namespace custom;

#include "vertex.h"

// Implemented as Adjacency-Matrix
class Graph
{
public:
// constructors, destructors, and assignment operator
    virtual ~Graph()
    {
        clear();
    }
    Graph(unsigned numNodes=0) throw (const char *)
        : matrixArray(NULL), numCapacity(0), numNodes(numNodes), numEdges(0)
    {
        this->numCapacity = numNodes * numNodes;
        this->matrixArray = allocateMatrixAsArray(this->numCapacity);
    }

    Graph(const Graph& rhs) throw (const char *)
        : matrixArray(NULL), numCapacity(0), numNodes(0), numEdges(0)
    {
        (*this) = rhs;
    }
    Graph& operator=(const Graph& rhs) throw (const char *)
    {
        clear();
        this->matrixArray = allocateMatrixAsArray(rhs.numCapacity, rhs.matrixArray);
        this->numCapacity = rhs.numCapacity;
        this->numNodes = rhs.numNodes;
        this->numEdges = rhs.numEdges;

        return (*this);
    }
    // standard container interfaces
    int size() const
    {
        return this->numNodes;
    }
    bool empty()
    {
        return (this->numNodes == 0);
    }
    int capacity()
    {
        return (this->numCapacity);
    }
    void clear()
    {
        // in graph class, clear has the mission of free memory
        if (this->matrixArray != NULL)
        {
            delete [] this->matrixArray;
            this->matrixArray = NULL;
        }
        this->numNodes = 0;
        this->numEdges = 0;
    }

    void add(const Vertex& v1, const Vertex& v2)
    {
        // if not exists an edge between v1 and v2
        if (isEdge(v1, v2) == false)
        {
            // set true in adjacency matrix indicating an edge is set between v1 and v2
            (*this)(v1, v2) = true;
            // increment the number of edges
            this->numEdges++;
        }
    }
    void add(const Vertex& v1, const set<Vertex>& setVertex)
    {
        set<Vertex>::const_iterator it;
        for (it = setVertex.cbegin(); it != setVertex.cend(); ++it)
            add(v1, (*it));
    }

    bool isEdge(const Vertex& v1, const Vertex& v2) const
    {
        bool existsEdge;

        existsEdge = ((*this)(v1, v2) == true);

        return existsEdge;
    }

    set<Vertex> findEdges(const Vertex& from)
    {
        set<Vertex> edges;

        for (unsigned i=0; i<this->numNodes; i++)
        {
            // create a vertex with i value
            Vertex to(i);
            // if exists a edge from-to insert in edges
            if (isEdge(from, to) == true)
                edges.insert(to);
        }

        return edges;
    }

    /*
    * Implements the Breadth First Search algorithm
    * info to comprension of the algorithm: http://www.geeksforgeeks.org/?p=18382
    */
    custom::vector<Vertex> findPath(const Vertex& source, const Vertex& destination)
    {
        // list with the vertex found from source to destination vertex
        custom::vector<Vertex> path;
        // create a vector with size equals to numNodes and
        // initialize to -1
        std::vector<int> distances(this->numNodes, -1);
        // list for store in memory the vertex to traverse
        std::list<Vertex> toVisit;
        //
        int distance = 0;
        //
        std::vector<int> predecessor(this->numNodes, -1);

        // set distance for v to zero
        distances[source.index()] = 0;
        // put source the first vertex to traverse
        toVisit.push_back(source);

        // loop while there vertex to traverse
        while (toVisit.size() > 0 && distances[destination.index()] == -1)
        {
            Vertex v;
            set<Vertex> adjacentVertexes;

            // extract the first vertex to visit
            v = toVisit.front();
            toVisit.pop_front();

            if (distances[v.index()] > distance)
                distance++;

            // get the adjacent vertexes from v (the vertexes connected to v)
            adjacentVertexes = findEdges(v);
            // iterate over the adjacentVertexes to discover next nodes in the path
            set<Vertex>::iterator it=adjacentVertexes.begin();
            for (; it != adjacentVertexes.end(); ++it)
            {
                Vertex adjacentVertex;
                int index;

                // get the vertex pointed by the iterator
                adjacentVertex = (*it);
                // get the index of the vertex
                index = adjacentVertex.index();
                // if the vertex is not visited then push in the list toVisit
                if (distances[index] == -1)
                {
                    toVisit.push_back(adjacentVertex);
                    distances[index] = distance + 1;
                    predecessor[index] = v.index();
                }
            }
        } // end while

        distance++;

        if (distances[destination.index()] == -1)
            throw ("ERROR in shortestPath");

        path.push_back(destination);
        for (int i=1; i<=distance;i++)
            path.push_back(predecessor[path[i-1].index()]);

        return path;
    }

private:
    bool* matrixArray; // Adjacency-Matrix. fromIndex(cols), toIndex(rows)
    unsigned numCapacity;
    unsigned numNodes;
    unsigned numEdges;

    bool& operator()(const Vertex& from, const Vertex& to) const
    {
        unsigned index;
        unsigned fromIndex;
        unsigned toIndex;

        fromIndex = from.index();
        toIndex = to.index();

        assert(fromIndex < this->numCapacity);
        assert(toIndex < this->numCapacity);

        index = toIndex * this->numNodes + fromIndex;
        return this->matrixArray[index];
    }

    // helper method to allocate memory for adjacency matrix
    static bool* allocateMatrixAsArray(unsigned capacity, bool* rhsMatrixArray=NULL)
    {
        bool* matrixArray;

        if (capacity == 0)
        {
            matrixArray = NULL;
        }
        else
        {
            matrixArray = new(std::nothrow)bool[capacity];
            if (matrixArray == NULL)
                throw ("ERROR: Unable to allocate memory for the graph.");

            if (rhsMatrixArray == NULL)
                // set array elements to false
                std::memset(matrixArray, false, capacity * sizeof(bool));
            else
                // copy element values from rhsMatrix
                std::memcpy(matrixArray, rhsMatrixArray, capacity * sizeof(bool));
        }
        return matrixArray;
    }
};

#endif // GRAPH_H
