#ifndef LIST_H
#define LIST_H

namespace custom
{
    /// forward declaration
    template <class T>
    class Node;

    template <class T>
    class list
    {
    public:
        /// forward declaration
        class iterator;
        class reverse_iterator;

        virtual ~list();
        list();
        list(const list& rhs) throw (const char *);
        list& operator=(const list& rhs) throw (const char *);

        int size() const;
        bool empty() const;
        void clear();

        void push_front(const T& e) throw (const char*);
        void push_back(const T& e) throw (const char*);
        void pop_front() throw (const char*);
        void pop_back() throw (const char*);

        T& front() throw (const char*);
        T& back() throw (const char*);
        T front() const throw (const char*);
        T back() const throw (const char*);

        void erase(iterator& it);
        iterator insert(const iterator& it, const T& element) throw (const char *);

        iterator begin() const;
        iterator end() const;
        reverse_iterator rbegin() const;
        reverse_iterator rend() const;

        class iterator
        {
            friend iterator list<T>::insert(const iterator & it, const T & data) throw (const char *);
            friend void list<T>::erase(iterator & it) throw (const char *);
        public:
            iterator() : p(NULL) {}
            iterator(Node<T> * p) : p(p) {}
            iterator(const iterator& rhs) : p(NULL) { (*this) = rhs; }
            iterator& operator=(const iterator& rhs) { this->p = rhs.p; return (*this); }

            bool operator==(const iterator& rhs) const { return (this->p == rhs.p); }
            bool operator!=(const iterator& rhs) const { return (this->p != rhs.p); }

            iterator& operator++() { if (p != NULL) { this->p = this->p->pNext; } return (*this); }
            iterator& operator--() { if (this->p != NULL && this->p->pPrev != NULL) { this->p = this->p->pPrev; } return (*this); }
            iterator operator++(int) { iterator t(this->p); if (p != NULL) { this->p = this->p->pNext; } return t; }
            iterator operator--(int) { iterator t(this->p); if (this->p != NULL && this->pPrev != NULL) { this->p = this->p->pPrev; } return t; }

            T& operator*() { return (p->data); }

        private:
            Node<T> * p;
        };

        class reverse_iterator
        {
        public:
            reverse_iterator() : p(NULL) {}
            reverse_iterator(Node<T> * p) : p(p) {}
            reverse_iterator(const reverse_iterator& rhs) : p(NULL) { (*this) = rhs; }
            reverse_iterator& operator=(const reverse_iterator& rhs) { this->p = rhs.p; return (*this); }

            bool operator==(const reverse_iterator& rhs) const { return (this->p == rhs.p); }
            bool operator!=(const reverse_iterator& rhs) const { return (this->p != rhs.p); }

            reverse_iterator& operator++() { if (this->p != NULL) { this->p = this->p->pPrev; } return (*this); }
            reverse_iterator& operator--() { if (p != NULL && this->p->pNext != NULL) { this->p = this->p->pNext; } return (*this); }
            reverse_iterator operator++(int) { reverse_iterator t(this->p); if (this->p != NULL) { this->p = this->p->pPrev; } return t; }
            reverse_iterator operator--(int) { reverse_iterator t(this->p); if (p != NULL && this->p->pNext != NULL) { this->p = this->p->pNext; } return t; }

            T& operator*() { return (p->data); }

        private:
            Node<T> * p;
        };

    private:
        Node<T> * pHead;
        Node<T> * pTail;
        int numElements;

        Node<T> * prv_createNode(const T& t) throw (const char *)
        {
            Node<T> * pNewNode;
            pNewNode = new(std::nothrow) Node<T>(t);
            if (pNewNode == NULL)
                throw ("ERROR: unable to allocate a new node for a list");
            return pNewNode;
        }
    };

    /// list implementation
    template <class T>
    list<T>::~list()
    {
        Node<T> * pNode;
        while (pHead != NULL)
        {
            pNode = pHead;
            pHead = pHead->pNext;
            delete pNode;
        }
        this->pHead = NULL;
        this->pTail = NULL;
        this->numElements = 0;
    }

    template <class T>
    list<T>::list()
    {
        this->pHead = NULL;
        this->pTail = NULL;
        this->numElements = 0;
    }

    template <class T>
    list<T>::list(const list& rhs) throw (const char *)
        : pHead(NULL), pTail(NULL), numElements(0)
    {
        (*this) = rhs;
    }

    template <class T>
    list<T>& list<T>::operator=(const list<T>& rhs) throw (const char *)
    {
        /// borrar los nodos de esta lista
        clear();
        /// copiar los nodos de la otra lista. Recorremos la lista rhs e insertamos los datos en this
        for (Node<T> * pNode = rhs.pHead; pNode != NULL; pNode = pNode->pNext)
        {
            push_back(pNode->data);
        }
        /// como siempre devolver this
        return (*this);
    }

    template <class T>
    int list<T>::size() const
    {
        return this->numElements;
    }

    template <class T>
    bool list<T>::empty() const
    {
        return size() == 0;
    }

    template <class T>
    void list<T>::clear()
    {
        this->~list();
    }

    template <class T>
    void list<T>::push_front(const T& e) throw (const char*)
    {
        insert(begin(), e);
    }

    template <class T>
    void list<T>::push_back(const T& e) throw (const char*)
    {
        insert(end(), e);
    }

    template <class T>
    void list<T>::pop_front() throw (const char*)
    {
        if (this->pHead != NULL)
        {
            Node<T> * pRemove = this->pHead;
            if (this->pHead->pNext != NULL)
                this->pHead->pNext->pPrev = NULL;
            this->pHead = this->pHead->pNext;
            if (this->pTail == pRemove)
                this->pTail = NULL;
            delete pRemove;
            this->numElements--;
        }
    }

    template <class T>
    void list<T>::pop_back() throw (const char*)
    {
        if (this->pTail != NULL)
        {
            Node<T> * pRemove = this->pTail;
            if (this->pTail->pPrev != NULL)
                this->pTail->pPrev->pNext = NULL;
            this->pTail = this->pTail->pPrev;
            if (this->pHead == pRemove)
                this->pHead = NULL;
            delete pRemove;
            this->numElements--;
        }
    }

    template <class T>
    T& list<T>::front() throw (const char*)
    {
        if (empty() == false)
            return this->pHead->data;
        throw "ERROR: unable to access data from an empty list";
    }

    template <class T>
    T& list<T>::back() throw (const char*)
    {
        if (empty() == false)
            return this->pTail->data;
        throw "ERROR: unable to access data from an empty list";
    }

    template <class T>
    T list<T>::front() const throw (const char*)
    {
        if (empty() == false)
            return this->pHead->data;
        throw "ERROR: unable to access data from an empty list";
    }

    template <class T>
    T list<T>::back() const throw (const char*)
    {
        if (empty() == false)
            return this->pTail->data;
        throw "ERROR: unable to access data from an empty list";
    }

    template <class T>
    void list<T>::erase(iterator& it)
    {
        if (it.p != NULL)
        {
            if (it.p->pNext != NULL)
                it.p->pNext->pPrev = it.p->pPrev;
            else
                this->pTail = it.p->pPrev;

            if (it.p->pPrev != NULL)
                it.p->pPrev->pNext = it.p->pNext;
            else
                this->pHead = it.p->pNext;

            delete it.p;
            it.p = NULL;
        }
    }

    template <class T>
    typename list<T>::iterator list<T>::insert(const iterator& it, const T& e) throw (const char *)
    {
        Node<T> * pNew = prv_createNode(e);

        if (empty() == true) // lista vacia
        {
            this->pHead = this->pTail = pNew;
        }
        else // lista no vacia
        {
            if (it == end()) // push_back
            {
                pNew->pPrev = this->pTail;
                this->pTail->pNext = pNew;
                this->pTail = pNew;
            }
            else // push_front it
            {
                pNew->pNext = it.p;
                pNew->pPrev = it.p->pPrev;

                if (pNew->pNext != NULL)
                    pNew->pNext->pPrev = pNew;
                if (pNew->pPrev != NULL)
                    pNew->pPrev->pNext = pNew;

                if (this->pHead == it.p)
                    this->pHead = pNew;
            }
        }

        this->numElements++;
        return iterator(pNew);
    }

    template <class T>
    typename list<T>::iterator list<T>::begin() const
    {
        return iterator(this->pHead);
    }

    template <class T>
    typename list<T>::iterator list<T>::end() const
    {
        return iterator(NULL); // end es NULL, fin de la lista
    }

    template <class T>
    typename list<T>::reverse_iterator list<T>::rbegin() const
    {
        return reverse_iterator(this->pTail); // como es reverse begin es pTail
    }

    template <class T>
    typename list<T>::reverse_iterator list<T>::rend() const
    {
        return reverse_iterator(NULL); // end es null, fin de lista
    }

    // NODE
    template <class T>
    class Node
    {
    public:
        virtual ~Node();
        Node();
        Node(const T& data);

        T data;
        Node* pPrev;
        Node* pNext;
    };

    template <class T>
    Node<T>::~Node()
    {
        this->pNext = NULL;
        this->pPrev = NULL;
    }

    template <class T>
    Node<T>::Node()
    {
        this->pNext = NULL;
        this->pPrev = NULL;
    }

    template <class T>
    Node<T>::Node(const T& data)
    {
        this->data = data;
        this->pNext = NULL;
        this->pPrev = NULL;
    }


    template <typename T>
    Node<T> * copy(Node<T>* pSource)
    {
        Node<T>* pDestination;
        Node<T> * pSrc, * pDest;

        if (pSource == NULL)
        {
            pDestination = NULL;
        }
        else
        {
            pDestination = new Node<T>(pSource->data);
            pSrc = pSource;
            pDest = pDestination;
            for (pSrc = pSrc->pNext; pSrc != NULL; pSrc = pSrc->pNext)
            {
                pDest = insert(pDest, pSrc->data, true);
            }
        }

        return pDestination;
    }

    template <typename T>
    Node<T> * insert(Node<T>* pCurrent, const T& data, bool after=false)
    {
        Node<T>* pNewNode = new Node<T>(data);

        if (pCurrent != NULL && after == false)
        {
            pNewNode->pNext = pCurrent;
            pNewNode->pPrev = pCurrent->pPrev;
            pCurrent->pPrev = pNewNode;
            if (pNewNode->pPrev != NULL)
                pNewNode->pPrev->pNext = pNewNode;
        }
        else
        if (pCurrent != NULL && after == true)
        {
            pNewNode->pPrev = pCurrent;
            pNewNode->pNext = pCurrent->pNext;
            pCurrent->pNext = pNewNode;
            if (pNewNode->pNext != NULL)
                pNewNode->pNext->pPrev = pNewNode;
        }

        return pNewNode;
    }

    template <typename T>
    Node<T> * find(Node<T> * pHead, const T& data)
    {
        for (Node<T> * p = pHead; p; p = p->pNext)
            if (p->data == data)
                return p;
        return NULL;
    }

    template <typename T>
    Node<T> * remove(Node<T> * pRemove)
    {
        Node<T>* pNodeReturn;

        if (pRemove == NULL)
            pNodeReturn = NULL;
        else
        {
            if (pRemove->pPrev != NULL)
                pRemove->pPrev->pNext = pRemove->pNext;
            else
            if (pRemove->pNext != NULL)
                pRemove->pNext->pPrev = pRemove->pPrev;

            if (pRemove->pPrev != NULL)
                pNodeReturn = pRemove->pPrev;
            else
                pNodeReturn = pRemove->pNext;

            delete pRemove;
        }

        return pNodeReturn;
    }

    template <typename T>
    void freeData(Node<T> *& pHead)
    {
    /** iterative version
        for (Node<T> * pNode = pHead; pNode != NULL; )
        {
            Node<T> * pDelete = pNode;
            pNode = pNode->pNext;
            delete pDelete;
        }

        pHead = NULL;
    */

    /// recursive version
        if (pHead == NULL) /// base case
        {
            ; /// empy list
        }
        else /// recursive case
        {
            freeData(pHead->pNext);
            delete pHead;
            pHead = NULL;
        }
    }

    template <typename T>
    std::ostream & operator << (std::ostream & out, const Node<T> * pHead)
    {
        for (const Node<T> * p = pHead; p; p = p->pNext)
        {
            out << p->data;
            if (p->pNext != NULL)
                out << ", ";
        }
        return out;
    }
};

#endif // LIST_H
 
