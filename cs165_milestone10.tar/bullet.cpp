/*****************************************************
* File: Bullet.cpp
* Author: Br. Milton Nogueira Brando Neto
*
* Description: This file contains the methods for bullets.
******************************************************/

// Put your bullet methods here



#include "bullet.h"
#include <cmath> // used for sin, cos, and M_PI

# define M_PI  3.14159265358979323846 /* pi */



/*********************************************
* Constructor
*********************************************/
Bullet::Bullet()
{
	setPoint(point);
}


/********************************************
BULLETS :: DRAW
set velocity for a flying object
********************************************/
void Bullet::draw()
{
	drawDot(point);
}


/*********************************************
* Normal Gun
*********************************************/
void Bullet::fire(Point point, float angle)
{
	float dx = BULLET_SPEED * (-sin(M_PI / 180.0 * (angle)));
	float dy = BULLET_SPEED * (cos(M_PI / 180.0 * (angle)));
	velocity.setDx(dx);
	velocity.setDy(dy);
	setPoint(point);
}




