/***********************************************************************
 * Module:
 *    Week 11, Sort Merge
 *    Brother Helfrich, CS 235
 * Author:
 *    <author>
 * Summary:
 *    This program will implement the Merge Sort
 ************************************************************************/

#ifndef SORT_MERGE_H
#define SORT_MERGE_H


/*****************************************************
 * MERGE
 * Two sorted sub-arrays turn into one
 ****************************************************/
template <class T>
void merge(T array[], T* pSrc1, int size1, T* pSrc2, int size2)
{
   /*
    int i1, i2;

    i1 = 0;
    i2 = 0;
    for (int iDst=0; iDst<size1+size2; iDst++)
    {
        if (i1<= size1 && (i2==size2 || pSrc1[i1] < pSrc2[i2]))
        {
            array[iDst] = pSrc1[i1];
            i1++;
        }
        else
        {
            array[iDst] = pSrc2[i2];
            i2++;
        }
    }
    */
}

/*****************************************************
 * SORT MERGE
 * Perform the merge sort
 ****************************************************/
template <class T>
void sortMerge(T array[], int num)
{
   /*
   int numIterations;
   int iBegin1;
   int iBegin2;
   int iEnd1;
   int iEnd2;
		
    T *source = new T[num];
    for (int i = 0; i < num; i++)
        source[i] = array[i];

    do 
    {
        numIterations = 0;
        while (iBegin1 < num)
        {
            numIterations++;
			
            for (iEnd1 = iBegin1 + 1; iEnd1 < num && !(source[iEnd1-1] > source[iEnd1]); iEnd1++)
               iBegin2 = iEnd1;

            for (iEnd2 = iBegin2 + 1; iEnd2 < num && !(source[iEnd2-1] > source[iEnd2]); iEnd2++)
			{
               if (iBegin2 < num)
                  merge(array
                    , source+iBegin1, iEnd1 - iBegin1 + 1
                    , source+iBegin2, iEnd2 - iBegin2 + 1);
               iBegin1 = iEnd2;
			}
        }
		// swap them
		T *temp = new T[num];
	    for (int i = 0; i < num; i++)
          temp[i] = array[i];
	    for (int i = 0; i < num - 1; i++)
          array[i] = source[i];
	    for (int i = 0; i < num - 1; i++)
          source[i] = temp[i];
	    delete [] temp;

    }
    while (numIterations > 1);

    if (array != source)
	   for (int i = 0; i < num; i++)
          array[i] = source[i];

	*/

}





#endif // SORT_MERGE_H
