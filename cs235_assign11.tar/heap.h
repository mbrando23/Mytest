/*************************************************
* HEAP
* Create a heap. This is like a "pile" except
* considerably less organized
*************************************************/
#ifndef HEAP_H
#define HEAP_H

#include <iostream>
#include <cassert>

template <class T>
class Heap
{
public:
    // constructors
    Heap() : array(NULL), num(0) {}
    Heap(T * array, int num) : array(array), num(num) {}

    T & getMax() throw (const char *); // retrieve the maximum element
    void deleteMax() throw (const char *); // delete the top element
    void heapify(); // create a heap out of array
    void sort(); // destructively sort

private:
    void percolateDown(int iRoot, int iEnd); // fix heap from index down

    void swap(int i1, int i2) // swap two items, inline for speed
    {
        T temp = array[i1];
        array[i1] = array[i2];
        array[i2] = temp;
    }

    void print()
    {
        std::cout << "[ ";
        for (int i=0; i<num; i++)
            std::cout << array[i] << " ";
        std::cout << "]";
    }

    T * array; // the array
    int num; // the number of items in the array
};

template <class T>
T & Heap<T>::getMax() throw (const char *) // retrieve the maximum element
{
    if (this->num == 0)
        throw ("ERROR: heap is empty");

    T maxValue = this->array[0];
    for (int i=1; i<num; i++)
        if (this->array[i] > maxValue)
            maxValue = this->array[i];

    return maxValue;
}

template <class T>
void Heap<T>::deleteMax() throw (const char *) // delete the top element
{

}

/**********************************************
* HEAP :: HEAPIFY
* Create a heap out of the current array
*********************************************/
template <class T>
void Heap<T>::heapify()
{
    // percolate all the non-leaf nodes
    int i = (num / 2) - 1;
    for (; i >= 0; i--)
        percolateDown(i, num);
}

/**************************************************
* HEAP :: SORT
* From a heap, perform the sort. This will serve
* to remove all the known items from the heap
*************************************************/
template <class T>
void Heap<T>::sort()
{
    heapify();

    for (int iEnd=num-1; iEnd > 0; iEnd--)
    {
        // put the highest element at the end of the list and forget about it!
        swap(0, iEnd);
        //this->num--;
        // percolate the root
        percolateDown(0, iEnd);
    }
}

/************************************************
* HEAP :: PERCOLATE DOWN
* The item at the passed index may be out of heap
* order. Take care of that little detail!
************************************************/
template <class T>
void Heap<T>::percolateDown(int i, int n)
{
    int iRoot, iLeft, iRight;

    // while the root has at least one child
    while (i < n)
    {
        iRoot = i;
        iLeft = iRoot * 2 + 1;  // left child of root
        iRight = iLeft + 1;     // right child of root
        if (iLeft < n && array[iLeft] > array[iRoot])
            iRoot = iLeft;
        if (iRight < n && array[iRight] > array[iRoot])
            iRoot = iRight;
        if (iRoot == i)
            break;

        swap(i, iRoot);
        i = iRoot;
    }
}

#endif
