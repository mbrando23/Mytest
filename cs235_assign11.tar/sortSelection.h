/***********************************************************************
 * Module:
 *    Week 11, Sort Select
 *    Brother Helfrich, CS 235
 * Author:
 *    <your name>
 * Summary:
 *    This program will implement the Selection Sort
 ************************************************************************/

#ifndef SORT_SELECTION_H
#define SORT_SELECTION_H

/*****************************************************
 * SORT SELECTION
 * Perform the selection sort
 ****************************************************/
template <class T>
void sortSelection(T array[], int num)
{   
   // The outer loop checks each spot in the array and looks for the
   // item to go there.
   for (int iWall = 0; iWall < num; iWall++)
   {
      int iSmallest = iWall;

      // find the smallest item
      for (int iCheck = iSmallest + 1; iCheck < num; iCheck++)
      {
         if (array[iSmallest] > array[iCheck])
            iSmallest = iCheck;
      }
      // swap them
      if (iSmallest != iWall)
      {
         T temp = array[iWall];
         array[iWall] = array[iSmallest];
         array[iSmallest] = temp;
      }
   }
}


#endif // SORT_SELECTION_H
