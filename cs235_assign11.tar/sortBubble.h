/***********************************************************************
 * Module:
 *    Week 11, Sort Bubble
 *    Brother Helfrich, CS 235
 * Author:
 *    <your name>
 * Summary:
 *    This program will implement the Bubble Sort
 ************************************************************************/

#ifndef SORT_BUBBLE_H
#define SORT_BUBBLE_H

/*****************************************************
 * SORT BUBBLE
 * Perform the bubble sort
 ****************************************************/
template <class T>
void sortBubble(T array[], int num)
{
   bool swapped = true;

   // The outer loop checks each spot in the array and looks for the
   // item to go there.
   for (int iSpot = num - 1; iSpot >= 1 && swapped; iSpot--)

      // The inner loop brings the correct item to the spot.  This is done
      // by "bubbling" the item to the correct location.
      for (int iCheck = 0, swapped = false; iCheck <= iSpot - 1; iCheck++)
      {  
         // If a pair is out of order, swap them.
         if (array[iCheck] > array[iCheck + 1])
            {
               // swap involves a temp variable because a variable can only
               // hold one item at a time.
               T temp = array[iCheck];
               array[iCheck] = array[iCheck + 1];
               array[iCheck  + 1] = temp;

               // once a swap has occured, set swapped to true so we know
               // we need to go through the outer loop again.
               swapped = true;
            }
      }
}


#endif // SORT_BUBBLE_H
