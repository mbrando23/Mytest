/***********************************************************************
 * Module:
 *    Week 11, Sort Insertion
 *    Brother JonesL, CS 235
 * Author:
 *    Luis Orbezua
 * Summary:
 *    This program will implement the Insertion Sort
 ************************************************************************/


#ifndef SORT_INSERTION_H
#define SORT_INSERTION_H

#include <cassert>

/*****************************************************
 * SORT INSERTION
 * Perform the insertion sort
 ****************************************************/
template <class T>
int binarySearch(T array[], T searchValue, int iBegin, int iEnd);

template <class T>
void sortInsertion(T array[], int num)
{
    for (int iPivot=num-2; iPivot>=0; iPivot--)
    {
        T valuePivot;
        int iInsert;
        int iShift;

        valuePivot = array[iPivot];
        iInsert = binarySearch(array, valuePivot, iPivot+1, num-1);
        iInsert--;
        for (iShift=iPivot; iShift<iInsert; iShift++)
        {
            // swap
            T temp = array[iShift];
            array[iShift] = array[iShift+1];
            array[iShift+1] = temp;
        }

        array[iShift] = valuePivot;
    }
}

template <class T>
int binarySearch(T array[], T searchValue, int iBegin, int iEnd)
{
    int iMiddle;

    iMiddle = (iBegin + iEnd)/2;
    if (iBegin > iEnd)
        return iBegin;
    if (array[iMiddle] == searchValue)
        return iMiddle;
    if (searchValue > array[iMiddle])
        return binarySearch(array, searchValue, iMiddle + 1, iEnd);
    else
        return binarySearch(array, searchValue, iBegin, iMiddle - 1);
}

#endif // SORT_INSERTION_H
