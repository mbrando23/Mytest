/***********************************************************************
 * Module:
 *    Week 11, Sort Quick
 *    Brother JonesL, CS 235
 * Author:
 *    Luis Orbezua
 * Summary:
 *    This program will implement the Quick Sort
 ************************************************************************/


#ifndef SORT_QUICK_H
#define SORT_QUICK_H

/*****************************************************
 * SORT QUICK
 * Perform the quick sort
 ****************************************************/
template <class T>
void swap(T& a, T& b)
{
    T temp = a;
    a = b;
    b = temp;
}

template <class T>
void sortQuick(T array[], int n)
{
    int iDown, iEnd, iUp;
    T pivotValue;

    if (n <= 1)
        return;

    iUp = 0;
    iDown = n - 1;
    iEnd = n - 1;
    pivotValue = array[iEnd/2];

    while (iUp <= iDown)
    {
        while (iUp <= iEnd && pivotValue > array[iUp])
            iUp++;
        while (iDown>=0 && array[iDown] > pivotValue)
            iDown--;
        if (iUp <= iDown)
        {
            swap(array[iUp], array[iDown]);
            iUp++;
            iDown--;
        }
    }

    sortQuick(array, iUp);
    sortQuick(array + iUp, iEnd - iUp + 1);
}


#endif // SORT_QUICK_H

