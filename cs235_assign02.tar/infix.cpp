/***********************************************************************
* Module:
*    Week 02, Stack
*    Brother Helfrich, CS 235
* Author:
*    Br. Helfrich
* Summary:
*    This program will implement the convertInfixToPostfix() function
************************************************************************/


#include <iostream>    // for ISTREAM and COUT
#include <string>      // for STRING
#include <cassert>     // for ASSERT
#include <sstream>     // for string streams
#include <map>         // for MAP
#include "stack.h"     // for STACK
#include "infix.h"
using namespace std;
using namespace custom;

/*************************************************
* TOKEN TYPE
* What type of token are we working with?
************************************************/
enum TokenType
{
	LITERAL,    // Literal such as 0 or 5.4
	VARIABLE,   // Variable such as 'a'
	O_PAREN,    // (
	C_PAREN,    // )
	ADDITION,   // + -
	MULTIPLY,   // * % /
	EXPONENT,   // ^
	UNKNOWN
};

/**************************************************
* ASSEMBLY COMMANDS
*************************************************/
#define LOD  "\tLOD "   // Load a value from memoryinto the register
#define SET  "\tSET "   // Set the register to some literal value
#define SAV  "\tSAV "   // Save the value in a register to some memory location
#define ADD  "\tADD "   // Add a value to the register
#define SUB  "\tSUB "   // Subtract a value from what is in the register
#define MUL  "\tMUL "   // Multiply the current value in the register by value
#define DIV  "\tDIV "   // Integer division for some value in the register
#define MOD  "\tMOD "   // Find the remainder of the division 
#define EXP  "\tEXP "   // Exponent

/****************************************************
* TOKEN
* One member of the token type
***************************************************/
class Token
{
public:
	// constructors and assignment operator
	Token() : type(UNKNOWN) {              }
	Token(const Token & rhs) { *this = rhs; }
	Token(const char * str) { type = VARIABLE; value = str; }
	Token & operator = (const Token & rhs)
	{
		type = rhs.type;
		value = rhs.value;
		return *this;
	}

	// standard getters and setters
	TokenType    getType()  const { return type; }
	string       getValue() const { return value; }
	const char * getAssm()  const;

	// input and output
	friend ostream & operator << (ostream & out, Token & rhs)
	{
		out << rhs.value;
		return out;
	}
	friend istream & operator >> (istream & in, Token & rhs);

	// comparison
	bool operator >  (const Token & rhs) const { return type >  rhs.type; }
	bool operator >= (const Token & rhs) const { return type >= rhs.type; }
	bool operator <  (const Token & rhs) const { return type <  rhs.type; }
	bool operator <= (const Token & rhs) const { return type <= rhs.type; }

	// increment the variable name
	Token & operator ++ ()
	{
		assert(type == VARIABLE);
		value[0]++;
		return *this;
	}

private:
	TokenType type;
	string    value;
};


/****************************************************
* GET ASSMembly
* Return the assembly command associated with each token
****************************************************/
const char * Token::getAssm() const
{
	switch (type)
	{
	case EXPONENT:
		return EXP;
	case MULTIPLY:
		if (value[0] == '*')
			return MUL;
		if (value[0] == '/')
			return DIV;
		return MOD;
	case ADDITION:
		return (value[0] == '+' ? ADD : SUB);
	}

	assert(false);
	return "ERROR";
}


/****************************************************
* TOKEN EXTRACTION
* From a given input, determine the type
***************************************************/
istream & operator >> (istream & in, Token & rhs)
{
	// skip the leading white spaces
	while (in.good() && isspace(in.peek()))
		in.get();

	// what kind of data did we read?
	rhs.value = (char)in.get();
	switch (rhs.value[0])
	{
	case '(':
		rhs.type = O_PAREN;
		break;
	case ')':
		rhs.type = C_PAREN;
		break;
	case '^':
		rhs.type = EXPONENT;
		break;
	case '*':
	case '%':
	case '/':
		rhs.type = MULTIPLY;
		break;
	case '+':
	case '-':
		rhs.type = ADDITION;
		break;


		// only variable names begin with _
	case '_':
		rhs.type = VARIABLE;
		while (isalpha(in.peek()) || in.peek() == '_' ||
			isdigit(in.peek()))
			rhs.value += (char)in.get();
		break;

		// only literals begin with '.'
	case '.':
		rhs.type = LITERAL;
		while (isdigit(in.peek()))
			rhs.value += (char)in.get();
		break;

	default:
		// only literals begin with a digit
		if (isdigit(rhs.value[0]))
		{
			rhs.type = LITERAL;
			// first consume all the digits
			while (isdigit(in.peek()))
				rhs.value += (char)in.get();
			// if we encounter a decimal, consume it 
			if (in.peek() == '.')
			{
				rhs.value += (char)in.get();
				while (isdigit(in.peek()))
					rhs.value += (char)in.get();
			}
		}

		// only variable names begin with letters
		else if (isalpha(rhs.value[0]))
		{
			rhs.type = VARIABLE;
			while (isalpha(in.peek()) || in.peek() == '_' ||
				isdigit(in.peek()))
				rhs.value += (char)in.get();
		}

		// everything else is an error
		else
			rhs.type = UNKNOWN;
		break;
	}

	return in;
}

/*****************************************************
* CONVERT INFIX TO POSTFIX
* Convert infix equation "5 + 2" into postifx "5 2 +"
*****************************************************/
string convertInfixToPostfix(const string & infix)
{
	string         postfix;          // output string
	stack <Token>  ops;              // stack of operations
	istringstream  sin(infix);
	Token          token;

	// loop through the tokens
	sin >> token;
	while (token.getType() != UNKNOWN)
	{
		switch (token.getType())
		{
		case LITERAL:
		case VARIABLE:
			
			break;

		case O_PAREN:
			
			break;

		case C_PAREN:
			while (ops.top().getType() != O_PAREN)
			{
				
			}
			
			break;

		default:
			assert(token.getType() == EXPONENT ||
				token.getType() == MULTIPLY ||
				token.getType() == ADDITION);
			while (!ops.empty() && token <= ops.top())
			{
				
			}
			
			break;
		}
		sin >> token;
	}

	// everything left on the stack goes to output
	while (!ops.empty())
	{
		
	}

	return postfix;
}

/*****************************************************
 * TEST INFIX TO POSTFIX
 * Prompt the user for infix text and display the
 * equivalent postfix expression
 *****************************************************/
void testInfixToPostfix()
{
   string input;
   cout << "Enter an infix equation.  Type \"quit\" when done.\n";
   
   do
   {
      // handle errors
      if (cin.fail())
      {
         cin.clear();
         cin.ignore(256, '\n');
      }
      
      // prompt for infix
      cout << "infix > ";
      getline(cin, input);

      // generate postfix
      if (input != "quit")
      {
         string postfix = convertInfixToPostfix(input);
         cout << "\tpostfix: " << postfix << endl << endl;
      }
   }
   while (input != "quit");
}

/**********************************************
* CONVERT POSTFIX TO ASSEMBLY
* Convert postfix "5 2 +" to assembly:
*     LOAD 5
*     ADD 2
*     STORE VALUE1
**********************************************/
string convertPostfixToAssembly(const string & postfix)
{
	string assembly;             // output
	istringstream  sin(postfix);
	stack <Token> values;       // stack of values
	Token variable("A");

	// loop through the tokens
	Token token;
	sin >> token;
	while (token.getType() != UNKNOWN)
	{
		// if it is a value, push it on the stack
		if (token.getType() == LITERAL || token.getType() == VARIABLE)
			values.push(token);

		// if it is an operation, then pop it off
		else
		{
			assert(token.getType() == EXPONENT ||
				token.getType() == MULTIPLY ||
				token.getType() == ADDITION);

			// pop off the operands
			
			// display the load statement
			

			// display the operand
			

			// store the value
			
		}

		sin >> token;
	}

	return assembly;

}

/*****************************************************
 * TEST INFIX TO ASSEMBLY
 * Prompt the user for infix text and display the
 * resulting assembly instructions
 *****************************************************/
void testInfixToAssembly()
{
   string input;
   cout << "Enter an infix equation.  Type \"quit\" when done.\n";

   do
   {
      // handle errors
      if (cin.fail())
      {
         cin.clear();
         cin.ignore(256, '\n');
      }
      
      // prompt for infix
      cout << "infix > ";
      getline(cin, input);
      
      // generate postfix
      if (input != "quit")
      {
         string postfix = convertInfixToPostfix(input);
         cout << convertPostfixToAssembly(postfix);
      }
   }
   while (input != "quit");
      
}

