/***********************************************************************
* Header:
*    STACK      
* Summary:
*    This class contains the notion of a stack: a bucket to hold
*    data for the user. 
*
*    This will contain the class definition of:
*       stack             : similar to std::stack
* Authors
*    Luis Orbezua, Milton Nogueira Brando Neto, Isaac Sanchez
************************************************************************/

#ifndef STACK_H
#define STACK_H

#include <iostream>
#include <cassert>  // because I am paranoid

namespace custom
{
	
/*************************************************************
* Stack
* A class that holds stuff
*************************************************************/
template <class T>
class stack
{
   public:

      // default constructor : empty and kinda useless
      stack() : numItems(0), numCapacity(0), data(0x00000000) {}

      // non-default constructor : pre-allocate
      stack(int capacity) throw (const char *);
   
      // copy constructor : copy it
      stack(const stack & rhs) throw (const char *);
   
      // destructor : free everything
      ~stack() { if (numCapacity) delete[] data; }

      // assignment operator
      stack & operator = (const stack & rhs) throw (const char *);

      /////////////////////Normal Methods////////////////////
   
      // Test whether the stack is empty. This method takes no
      //parameters and returns a Boolean value.
      bool empty() const { return numItems == 0; ; }
   
      // Return the stack size. This method takes no
      // parameters and returns an integer value.
      int size() const { return numItems; } // Pg.46 says that it returns numItems 
   
      //Clear the contents. This method takes no parameters
      //and returns nothing. Note that you do not need to
      //free the allocated memory; just set the size
      //member variable to zero.
      void clear() { numItems = 0; }
   
      /////////////////////New Methods////////////////////
   
      // add an item to the container
      void push(const T & t) throw (const char *);
	  void insert(const T & t) throw (const char *);
   
      // removing the top-most element from the stack.
      void pop() throw (const char *);
   
      // to access the last element added to the stack
	  T top() const throw (const char *)
	  {
         if (numItems > 0)
            return (data[numItems - 1]);
         else
            std::cout << "\tERROR";
      //StackElement garbage;
      //return garbage;  
	  }
	  
	  // to modify the top element of the stack
	  T & top() throw (const char *)
	  {
         if (numItems > 0)
            return (data[numItems - 1]);
         else
		 {
			std::cerr << "\t\"ERROR: Unable to reference the element from an empty Stack";
			return (data[numItems]);
		 }
 
	  
	  }
	  

   private:
      T * data;         // dynamically allocated stack of T
      int numCapacity;  // how many items can I put on the Container before full?
      int numItems;     // how many items are currently in the Container?
};

/***************************************************
 * STACK: Non Default Constructor
 * capacity value as a parameter
 * If there is insufficient memory to allocate a
 * new buffer, then the following exception is thrown:
 * ERROR: Unable to allocate a new buffer for Stack.
 ***************************************************/
template<class T>
stack<T> ::stack(int capacity) throw (const char *)
{   
   if (numCapacity == 0)
   {
      numCapacity = numItems = 0;
      data = 0x00000000;
      return;
   }

   // copy over the stuff
   numCapacity = capacity;
   numItems    = 0;
   
   // attempt to allocate
   try
   {
      data = new T[numCapacity];
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: Unable to allocate a new buffer for stack";
   }
   assert(numCapacity >= 0);
   // do nothing if there is nothing to do
}
   
/***************************************************
 * STACK: COPY CONSTRUCTOR
 * Makes a copy of the stack, Buffer does not need
 * to be copied see pag. 47
 * If there is insufficient memory to allocate a
 * new buffer, then the following exception is thrown:
 * ERROR: Unable to allocate a new buffer for Stack.
 ***************************************************/
template<class T>
stack<T> ::stack(const stack<T> & rhs) throw(const char *)
{
   assert(rhs.numCapacity >= 0);

   // do nothing if there is nothing to do
   if (rhs.numCapacity == 0)
   {
      numCapacity = numItems = 0;
      data = 0x00000000;
      return;
   }

   // attempt to allocate
   try
   {
      data = new T[rhs.numCapacity];
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: Unable to allocate a new buffer for stack";
   }

   // see page 47, extra elements are not used
   assert(rhs.numItems >= 0 && rhs.numItems <= rhs.numCapacity);
   numItems = rhs.numItems;

   for (int i = 0; i < numItems; i++)
      data[i] = rhs.data[i];	  	  
}

/*******************************************
 * STACK :: Assignment Operator
 *******************************************/
template <class T>
stack <T> & stack <T> :: operator = (const stack <T> & rhs)
                            throw (const char *)
{
   numItems = rhs.numItems;
   
   for (int i = 0; i < numCapacity; i++)
      data[i] = rhs.data[i];

   return *this;
}

   
/***************************************************
 * STACK: PUSH
 * Adds an element to the top of the stack, thereby
 * Increasing size by one. pg.46
 ***************************************************/
template<class T>
void stack <T> :: push(const T & t) throw(const char*)
{
   T* newData;

   if (numItems >= numCapacity)
   {
      if (numCapacity == 0)
      {
         numCapacity = 1;
      }

      else
      {
         numCapacity *= 2;
      }

      newData = new T[numCapacity];

      for (int idx = 0; idx < numItems; ++idx)
      {
         newData[idx] = data[idx];
      }

      delete[] data;
      data = newData;
   }
   
   insert(t);
}

/***************************************************
* CONTAINER :: INSERT
* Insert an item on the end of the container
**************************************************/
template <class T>
void stack <T> :: insert(const T & t) throw (const char *)
{
   // do we have space?
   if (numCapacity == 0 || numCapacity == numItems)
      throw "ERROR: Insufficient space";

   // add an item to the end
   data[numItems++] = t;
   
}


/***************************************************
 * STACK: POP
 * Removes the top element from the stack, pg 49.
 ***************************************************/
template<class T>
void stack <T> :: pop() throw(const char*)
{
   if (numItems > 0)
      numItems--;
   else
   {
      std::cout << "\tCorrect! When we pop() with an empty stack, nothing bad happens.\n";
   }
}
 
 
 
 
 /***************************************************
 * STACK: TOP
 * Accesses the last element added, pg.50.
 ***************************************************
template<class T>
T & stack <T> :: top() const throw (const char *)
{
   if (numItems > 0)
      return (data[numItems - 1]);
   else
      std::cout << "*** Stack is empty -- returning garbage value ***\n";
      //StackElement garbage;
      //return garbage;  
}

/***************************************************
 * STACK: TOP
 * Modify the top element of the stack, pg.50.
 **************************************************
template<class T>
T stack <T> :: top() throw (const char *)
{
   if (numItems > 0)
      return (data[numItems - 1]);
   else
      std::cout << "*** Stack is empty -- returning garbage value ***\n";
      //StackElement garbage;
      //return garbage;	
}
*/




};

#endif //STACK_H
