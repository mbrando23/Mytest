// NOT FINISHED, This is what I have for the moment!

// Im still working on this

// last update: 1:43am 22 september at Push
// it is not finished, I migth not be able to see you tomorrow
// I will be giving service with my stake
// ISAAC SANCHEZ



#ifndef STACK_H
#define STACK_H

#include <iostream>

namespace custom
{
/*************************************************************
* Stack
* A class that holds stuff
*************************************************************/
template <class T>
   class stack
{
  public:

   // constructors - destructors

   // Default Constructor creates a stack with zero elements in it
  stack() : stackA(NULL), maxSize(0), numItems(0) {}
   //non Def constructor taking capacity as a parameter
   stack(int capacity) throw(const char *);
   //copy constructor NOT READY!
   stack(const stack<T> & rhs) throw(const char *);
   //When finished, the class should delete all the allocated memory
   ~stack() { if (numItems) delete[] stackA; }


   // Return the stack size. This method takes no
   // parameters and returns an integer value.
   int size() const { return numItems; } // Pg.46 says that it returns numItems


   /////////////////////New Methods////////////////////
   
   // Test whether the stack is empty. This method takes no
   //parameters and returns a Boolean value.
   bool empty() const { return numItems == 0; ; }
   //Clear the contents. This method takes no parameters
   //and returns nothing. Note that you do not need to
   //free the allocated memory; just set the size
   //member variable to zero.
   void clear() { numItems = 0; }
   
   ////////////////////////////////////////////////////


  private:
   T * stackA;              // dynamically allocated stack of T
   int maxSize;             // how many items can I put on the
                            //vector before full? this is size!!
   int numItems;            // Capacity?

   };

/***************************************************
 * STACK: Non Default Constructor
 * capacity value as a parameter
 * If there is insufficient memory to allocate a
 * new buffer, then the following exception is thrown:
 * ERROR: Unable to allocate a new buffer for Stack.
 ***************************************************/
   template<class T>
      stack<T> ::stack(int capacity) throw (const char *)
   {
      // items are not copied
      // see page 47, extra elements are not used
      numItems = 0;
      //maxsize is capacity, will be used to allocate a buffer
      maxSize = capacity;

      // attempt to allocate
      try
      {
         stackA = new T[maxSize];
         //stackA = new T[capacity]; //it's the same
      }
      // if fails then throw error
      catch (std::bad_alloc)
      {
         throw "ERROR: Unable to allocate a new buffer for Vector";
      }
   }
   

/***************************************************
 * STACK: COPY CONSTRUCTOR
 * Makes a copy of the stack, Buffer does not need
 * to be copied see pag. 47
 * If there is insufficient memory to allocate a
 * new buffer, then the following exception is thrown:
 * ERROR: Unable to allocate a new buffer for Stack.
 *
 *
 * I'm Not sure if it is working!!!
 ***************************************************/
   template<class T>
      stack<T> ::stack(const stack<T> & rhs) throw(const char *)
   {
      // items are not copied
      // see page 47, extra elements are not used
      numItems = 0;
      //will be used to allocate a buffer
      maxSize = rhs.maxSize;

      stackA = new T[rhs.maxSize];

      if (!maxSize)
         return;
      // attempt to allocate
      try
      {
         stackA = new T[maxSize];
      }
      catch (std::bad_alloc)
      {
         throw "ERROR: Unable to allocate a new buffer for Vector";
      }

      //copy the data
      /*while (numItems < rhs.numItems)
        {
        stackA[numItems] = rhs.stackA[numItems];
        numItems++;
        }*/

      for (int i = 0; i < numItems; i++)
      {
         stackA[i] = rhs.stackA[i];
      }
      return;
   }

/***************************************************
 * STACK: PUSH
 * Adds an element to the top of the stack, thereby
 * Increasing size by one. pg.46
 *
 ***************************************************/
   template<class T>
      void stack<T> ::push(const T & t) throw(const char*)
   {

      if (stackA == NULL)
      {
         stackA = new T[1];
         maxSize = 1;

      }

      // for a full stack
      if (maxSize == numItems)
      {
         2 * maxSize;

      }

      T * tempStack;
      try
      {
         tempStack = new T[maxSize];
      }
      //throw an exeption if the allocation fails
      catch (std::bad_alloc)
      {
         throw "ERROR: Unable to allocate a new buffer for Vector";;
      }

      for (int i = 0; i < numItems; i++)
         tempStack[i] = stackA[i];

      delete[] stackA;
      stackA = tempStack;
   }
   






   
};
#endif //STACK_H
