/***********************************************************************
 * Component:
 *    Assignment 09, Binary Search Tree (BST)
 *    Brother Jones L, CS 235
 * Authors:
 *     Orbezuza Luis
 *     Brando Milton
 *     Sanchez Isaac
 * Summary:
 *    Create a binary search tree
 ************************************************************************/

#ifndef BST_H
#define BST_H

#include <iostream>
#include <cassert>
#include <stack>

namespace custom
{
    // Binary Search Tree
    template<class T> class BST
    {
    public:
        /// forward declaration
        class BNode;
        class iterator;

        virtual ~BST();
        BST();
        BST(const BST& rhs) throw (const char *);
        BST& operator=(const BST& rhs) throw (const char *);
        int size() const;
        bool empty() const;
        void clear();
        void insert(const T& e) throw (const char *);
        void erase(iterator& it);
        iterator find(const T& e);

        iterator begin() const;
        iterator end() const;
        iterator rbegin() const;
        iterator rend() const;

        BNode * getRoot() { return root; }

        /// Iterator: has to traverse the binary passing throw the elements in order
        class iterator
        {
            friend void BST<T>::erase(iterator & it);
        public:
            iterator(BNode * pNode=NULL)
                { this->stackNodes.push(pNode); }

            iterator(const std::stack<BNode*> &s)
                { this->stackNodes = s; }

            iterator(const iterator& rhs)
                { (*this) = rhs; }

            iterator& operator=(const iterator& rhs)
                { this->stackNodes = rhs.stackNodes; return (*this); }

            bool operator==(const iterator& rhs) const
                { return (this->stackNodes.top() == rhs.stackNodes.top()); }

            bool operator!=(const iterator& rhs) const
                { return (this->stackNodes.top() != rhs.stackNodes.top()); }

            iterator operator++()
            {
                BNode * pRet;
                if (this->stackNodes.empty() == true)
                    pRet = NULL;
                else
                {
                    pRet = this->stackNodes.top();
                    this->stackNodes.pop();
                    if (pRet != NULL)
                        for (BNode * pNode = pRet->pRight; pNode != NULL; pNode = pNode->pLeft)
                            this->stackNodes.push(pNode);
                }
                return iterator(pRet);
            }

            iterator operator++(int postfix)
            {
                iterator itReturn = (*this);
                ++(*this);
                return itReturn;
            }

            iterator operator--()
            {
                BNode * pRet;
                if (this->stackNodes.empty() == true)
                    pRet = NULL;
                else
                {
                    pRet = this->stackNodes.top();
                    this->stackNodes.pop();
                    if (pRet != NULL)
                    {
                        for (BNode * pNode = pRet->pLeft; pNode != NULL; pNode = pNode->pRight)
                            this->stackNodes.push(pNode);
                        pRet = this->stackNodes.top();
                    }
                }
                return iterator(pRet);
            }

            iterator operator--(int postfix)
            {
                iterator itReturn = (*this);
                --(*this);
                return itReturn;
            }

            const T& operator*()
                { return (this->stackNodes.top()->data); }



        private:
            std::stack<BNode*> stackNodes;

            BNode * getNode(){ return this->stackNodes.top(); }
        };

    private:
        BNode * root;

        void deleteNode(BNode& toDelete, bool right);
        void deleteBinaryTree(BNode *& toDelete);
        BNode * copyBinaryTree(BNode * pSrc) throw (const char *);
/*
        void rotateLeft(BNode * pNode)
        {
            BNode<T> ** ppRoot;
            BNode<T> * pRight;

            if (pNode == NULL)
                return;

            if (pNode->pParent == NULL)
                ppRoot = &this->root;
            else
            {
                if (pNode == pNode->pParent->pLeft)
                    ppRoot = &pNode->pParent->pLeft;
                else
                if (pNode == pNode->pParent->pRight)
                    ppRoot = &pNode->pParent->pRight;
            }

            pRight = pNode->pRight;
            pNode->pRight = pRight->pLeft;
            pRight->pRight = pNode;
            if (pNode->pParent != NULL)
                (*ppRoot)->pParent = pRight;
        }
*/

        void insertNode(BNode ** ppNode, BNode * pParent, const T& data) throw (const char *)
        {
            BNode * pNode = (*ppNode);

            if (pNode == NULL)
            // free child where insert the new node
            {
                (*ppNode) = BNode::allocateNode(data);
                (*ppNode)->pParent = pParent;
            }
            else
            // go left or right child
            {
                if (data < pNode->data)
                    insertNode(&(pNode->pLeft), pNode, data);
                else
                if (data > (*ppNode)->data)
                    insertNode(&(pNode->pRight), pNode, data);
                else
                    throw ("BST no allows duplicate elements");
            }
        }

        void deleteNode(BNode ** ppNode, const T& data)
        {
            BNode * pNode = (*ppNode);

            if (pNode == NULL) { return; }

            // recursive call findindg node with data
            if (data < pNode->data)
                deleteNode(&(pNode->pLeft), data);
            else
            if (data > pNode->data)
                deleteNode(&(pNode->pRight), data);
            else
            // this is the node with the data, so delete this node
            {
                if (pNode->pLeft == NULL) // left is null so take right
                    (*ppNode) = pNode->pRight;
                else
                if (pNode->pRight == NULL) // right is null so take left
                    (*ppNode) = pNode->pLeft;
                else
                // no childs are null -> complex case
                {
                    // Method : replace this node with greater from the left, Se reemplaza por el mayor de los menores
                    BNode * pGreater = findGreater(pNode->pLeft);
                    // Set greater->Right pNode Right
                    pGreater->pRight = pNode->pRight;
                    // Update pNode with its left
                    (*ppNode) = pNode->pLeft;
                }
            }

            delete pNode;
        }

        BNode * findGreater(BNode * pNode)
        {
            if (pNode->pRight == NULL)
                return pNode;
            else
                return findGreater(pNode->pRight);
        }
    };

    // Binary Search Tree, Binary Node
    template<class T> class BST<T>::BNode
    {
    public:
        static BNode * allocateNode(const T& e) throw (const char *);

        virtual ~BNode();
        BNode();
        BNode(const T& data);
        int size() const
        {
            return 1 +
                (pLeft== NULL? 0 : pLeft->size()) +
                (pRight == NULL ? 0 : pRight->size());
        }

        BNode * pParent;
        BNode * pLeft;
        BNode * pRight;
        T data;
        bool isRed;

    private:
        void verifyRB(int depth);
        void verifyBST();
        void balance();
    };

    // BST Implementation
    template<class T>
    BST<T>::~BST()
    {
        clear();
    }

    template<class T>
    BST<T>::BST()
        : root(NULL)
    {
    }

    template<class T>
    BST<T>::BST(const BST<T>& rhs) throw (const char *)
        : root(NULL)
    {
        (*this) = rhs;
    }

    template<class T>
    BST<T>& BST<T>::operator=(const BST<T>& rhs) throw (const char *)
    {
        clear();
        this->root = copyBinaryTree(rhs.root);
        return (*this);
    }

    template<class T>
    int BST<T>::size() const
    {
        return (empty()==true)? 0 : this->root->size();
    }

    template<class T>
    bool BST<T>::empty() const
    {
        return (this->root == NULL);
    }

    template<class T>
    void BST<T>::clear()
    {
        deleteBinaryTree(this->root);
        assert(empty() == true);
    }

    template<class T>
    void BST<T>::insert(const T& data) throw (const char *)
    {
        insertNode(&(this->root), NULL, data);
    }

    template<class T>
    void BST<T>::erase(iterator& it)
    {
        BNode * pNodeIt = it.getNode();
        deleteNode(&(this->root), pNodeIt->data);
    }

    template<class T>
    typename BST<T>::iterator BST<T>::find(const T& data)
    {
        BNode * pFindNode;
        bool isFound;

        isFound = false;
        pFindNode = this->root;
        while (isFound == false && pFindNode != NULL)
            if (data == pFindNode->data)
                isFound = true;
            else
            if (data < pFindNode->data)
                pFindNode = pFindNode->pLeft;
            else
                pFindNode = pFindNode->pRight;

        return iterator(pFindNode);
    }

    template<class T>
    typename BST<T>::iterator BST<T>::begin() const
    {
        std::stack<BNode*> stackNodes;
        stackNodes.push(NULL);
        stackNodes.push(this->root);
        while (stackNodes.top() != NULL && stackNodes.top()->pLeft != NULL)
            stackNodes.push(stackNodes.top()->pLeft);
        return iterator(stackNodes);
    }

    template<class T>
    typename BST<T>::iterator BST<T>::end() const
    {
        return iterator(NULL);
    }

    template<class T>
    typename BST<T>::iterator BST<T>::rbegin() const
    {
        std::stack<BNode*> stackNodes;
        stackNodes.push(NULL);
        stackNodes.push(this->root);
        while (stackNodes.top() != NULL && stackNodes.top()->pRight != NULL)
            stackNodes.push(stackNodes.top()->pRight);
        return iterator(stackNodes);
    }

    template<class T>
    typename BST<T>::iterator BST<T>::rend() const
    {
        return iterator(NULL);
    }

    template<class T>
    void BST<T>::deleteBinaryTree(BNode *& pNode)
    {
        if (pNode != NULL)
        {
            deleteBinaryTree(pNode->pLeft);
            deleteBinaryTree(pNode->pRight);
            delete pNode;
            pNode = NULL;
        }
    }

    template<class T>
    typename BST<T>::BNode * BST<T>::copyBinaryTree(BNode * pSrc) throw (const char *)
    {
        BNode * pDest;

        // base case for recursion
        if (pSrc == NULL)
            // as src is null return null
            pDest = NULL;
        else
        {
            // copy node : allocate new node with src data
            pDest = BNode::allocateNode(pSrc->data);

            // copy left child : recursive call with left node
            pDest->pLeft = copyBinaryTree(pSrc->pLeft);
            if (pDest->pLeft != NULL)
                // set this node as parent of copied node
                pDest->pLeft->pParent = pDest;

            // copy right child : recursive call with right node
            pDest->pRight = copyBinaryTree(pSrc->pRight);
            if (pDest->pRight != NULL)
                // set this node as parent of copied node
                pDest->pRight->pParent = pDest;
        }

        return pDest;
    }

    // BNode implementation
    template <class T>
    typename BST<T>::BNode * BST<T>::BNode::allocateNode(const T& e) throw (const char *)
    {
        BST<T>::BNode * pNode = new(std::nothrow) BST<T>::BNode(e);
        if (pNode == NULL)
             throw ("ERROR: Unable to allocate a node");
        return pNode;
    }

    template <class T>
    BST<T>::BNode::~BNode()
    {
        this->pParent = NULL;
        this->pLeft = NULL;
        this->pRight = NULL;
    }

    template <class T>
    BST<T>::BNode::BNode()
    {
        this->pParent = NULL;
        this->pLeft = NULL;
        this->pRight = NULL;
        this->isRed = false;
    }

    template <class T>
    BST<T>::BNode::BNode(const T& data)
        : data(data)
    {
        this->pParent = NULL;
        this->pLeft = NULL;
        this->pRight = NULL;
        this->isRed = false;
    }

    template <class T>
    void BST<T>::BNode::verifyRB(int depth)
    {

    }

    template <class T>
    void BST<T>::BNode::verifyBST()
    {

    }

    template <class T>
    void BST<T>::BNode::balance()
    {

    }
};

#endif // BST_H