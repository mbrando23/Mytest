#ifndef BNODE_H
#define BNODE_H

#include <iostream>

//namespace custom
//{
    template <class T>
    class BNode
    {
    public:
        static BNode * allocateNode(const T& e) throw (const char *);

        virtual ~BNode();
        BNode();
        BNode(const T& data);

        BNode * pParent;
        BNode * pLeft;
        BNode * pRight;
        T data;
    };

    template <class T>
    BNode<T> * BNode<T>::allocateNode(const T& e) throw (const char *)
    {
        BNode<T> * pNode = new(std::nothrow) BNode<T>(e);
        if (pNode == NULL)
             throw ("ERROR: Unable to allocate a node");
        return pNode;
    }

    template <class T>
    BNode<T>::~BNode()
    {
        this->pParent = NULL;
        this->pLeft = NULL;
        this->pRight = NULL;
    }

    template <class T>
    BNode<T>::BNode()
    {
        this->pParent = NULL;
        this->pLeft = NULL;
        this->pRight = NULL;
    }

    template <class T>
    BNode<T>::BNode(const T& data)
        : data(data)
    {
        this->pParent = NULL;
        this->pLeft = NULL;
        this->pRight = NULL;
    }

    template <class T>
    void addLeft(BNode<T> * pNode, BNode<T>* pAdd)
    {
        assert(pNode != NULL);
        if (pAdd != NULL)
            pAdd->pParent = pNode;
        pNode->pLeft = pAdd;
    }

    template <class T>
    void addRight(BNode<T> * pNode, BNode<T>* pAdd)
    {
        assert(pNode != NULL);
        if (pAdd != NULL)
            pAdd->pParent = pNode;
        pNode->pRight = pAdd;
    }

    template <class T>
    void addLeft(BNode<T> * pNode, const T& data) throw (const char *)
    {
        BNode<T> * pAdd = BNode<T>::allocateNode(data);
        addLeft(pNode, pAdd);
    }

    template <class T>
    void addRight(BNode<T> * pNode, const T& data) throw (const char *)
    {
        BNode<T> * pAdd = BNode<T>::allocateNode(data);
        addRight(pNode, pAdd);
    }

    template <class T>
    int sizeBTree(const BNode<T> * pNode)
    {
        int numNodes;

        if (pNode == NULL)
            numNodes = 0;
        else
        {
            numNodes = 1;
            numNodes += sizeBTree(pNode->pLeft);
            numNodes += sizeBTree(pNode->pRight);
        }

        return numNodes;
    }

    template <class T>
    BNode<T> * copyBTree(const BNode<T> * pSrc) throw (const char *)
    {
        BNode<T> * pDest;

        // base case for recursion
        if (pSrc == NULL)
            // as src is null return null
            pDest = NULL;
        else
        {
            // copy node : allocate new node with src data
            pDest = BNode<T>::allocateNode(pSrc->data);

            // copy left child : recursive call with left node
            pDest->pLeft = copyBTree(pSrc->pLeft);
            if (pDest->pLeft != NULL)
                // set this node as parent of copied node
                pDest->pLeft->pParent = pDest;

            // copy right child : recursive call with right node
            pDest->pRight = copyBTree(pSrc->pRight);
            if (pDest->pRight != NULL)
                // set this node as parent of copied node
                pDest->pRight->pParent = pDest;
        }

        return pDest;
    }

    template <class T>
    void deleteBTree(BNode<T> *& pNode)
    {
        if (pNode == NULL)
            // base case
            ;
        else
            // recursive case
        {
            // recursive call for left child
            deleteBTree(pNode->pLeft);
            // recursive call for right child
            deleteBTree(pNode->pRight);
            // now delete the node
            delete pNode;
            // and set to null : can change ptr value as is passed as reference
            pNode = NULL;
        }
    }

    template <typename T>
    std::ostream & operator << (std::ostream & out, const BNode<T> * pHead)
    {
        if (pHead != NULL)
        {
            out << pHead->pLeft;
            out << pHead->data << ' ';
            out << pHead->pRight;
        }
        return out;
    }
//};

#endif // BNODE_H