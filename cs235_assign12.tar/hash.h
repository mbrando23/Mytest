#ifndef HASH_H
#define HASH_H

#include <iostream>
#include <iomanip>
#include <cassert>
using namespace std;

//#include "list.h"

#include "bst.h"
using namespace custom;

/************************************************
* HASH
* An abstract Hash base class
************************************************/
template <class T>
class Hash
{
    // define type for hash entries
    // in this manner can change for another container easily (vector, list, etc..)
    typedef BST<T> TBucket;

    // allocate method. mange exceptions in only one method
    static TBucket* allocate(unsigned capacity)
    {
        TBucket* table;
        table = new(std::nothrow)TBucket[capacity];
        if (table == NULL)
            throw ("ERROR: Unable to allocate memory for the hash.");
        return table;
    }
public:
    // constructors, destructor, and assignment operator
    virtual ~Hash()
    {
        clear(); // reuse clear because it just delete memory
    }
    Hash(unsigned numBuckets=0) throw (const char *)
        : table(NULL), numBuckets(0), numElements(0)
    {
        // as allocate zero memory has no sense, put this condition
        if (numBuckets > 0)
        {
            this->table = allocate(numBuckets);
            this->numBuckets = numBuckets;
        }
    }
    Hash(const Hash& rhs) throw (const char *)
        : table(NULL), numBuckets(0), numElements(0)
    {
        // reuse operator =
        (*this) = rhs;
    }
    Hash& operator=(const Hash& rhs)
    {
        // free previous allocated memory
        clear();
        // allocate new memory to be as big as rhs
        this->table = allocate(rhs.numBuckets);
        // copy all the buckets from rhs
        for (int i=0; i<rhs.numBuckets; i++)
            this->table[i] = rhs.table[i];

        // now this has the same valueas as rhs
        this->numBuckets = rhs.numBuckets;
        this->numElements = rhs.numElements;

        return (*this);
    }

    // standard container interfaces
    int size() const
    {
        return this->numElements;
    }
    bool empty()
    {
        return (size() == 0);
    }
    int capacity() const
    {
        return this->numBuckets;
    }
    void clear()
    {
        // in hash class, clear has the mission of free memory
        if (this->table != NULL)
        {
            delete [] this->table;
            this->table = NULL;
        }
        this->numBuckets = 0;
        this->numElements = 0;
    }

    // hash-specific interfaces
    bool find(const T& e) const
    {
        int hashIndex;
        typename TBucket::iterator itFind;

        // call hash method to get a bucket index
        hashIndex = hash(e);
        // call bucket index where to find the element
        itFind = this->table[hashIndex].find(e);
        // if itFind is equals end() the element is not found
        return (itFind != this->table[hashIndex].end());
    }
    void insert(const T& e) throw (const char *)
    {
        int hashIndex;

        // call hash method to get a bucket index
        hashIndex = hash(e);
        // prevent index out of range
        assert(hashIndex >= 0 && hashIndex < capacity());
        // insert the element in the bucket index
        this->table[hashIndex].insert(e);
        // increase the number of elements in the hash
        this->numElements++;
    }

    // pure virtual function
    virtual int hash(const T& value) const = 0;

    // display the bucket sizes
    void display ()
    {
        int numEmpty = 0;
        int sizeLargest = 0;
        int sizeTotal = 0;

        for (int i = 0; i < capacity(); i++)
        {
            if (table[i].size() == 0)
                numEmpty++;
            else
                sizeTotal += table[i].size();

            if (table[i].size() > sizeLargest)
                sizeLargest = table[i].size();

            // std::cout << std::setw(10) << i
            // << " : " << table[i].size()
            // << std::endl;
        }

        std::cerr << "Number of empty buckets: " << numEmpty << std::endl;
        std::cerr << "Size of the largest bucket: " << sizeLargest << std::endl;
        std::cerr << "Total number of elements: " << sizeTotal << std::endl;
    }

private:
    TBucket* table; // a dynamic array of buckets. TBucket is defined forward
    int numBuckets;
    int numElements;
};

#endif // HASH_H