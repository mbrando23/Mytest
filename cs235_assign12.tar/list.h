/***********************************************************************
 * Header:
 *    LIST
 * Summary:
 *    This will contain the class definition of:
 *        List         : A class that represents a List
 *        ListIterator : An interator through List
 * Author
 *    Br. Helfrich
 ************************************************************************/

#ifndef LIST_H
#define LIST_H
#include <cassert>     // for ASSERT
#include <iostream>    // for NULL

namespace custom
{

/**************************************************
 * LIST
 * Generic linked list class. Supports the following:
 *    =          : copy one list onto another
 *    ERASE      : empty the list
 *    EMPTY      : is the list currently empty?
 *    PUSH_BACK  : add an item to the tail
 *    PUSH_FRONT : add an item to the head of the list
 *    BACK       : returns the last element in the list
 *    FRONT      : returns the first element in the list
 *    INSERT     : add an item to a location somewhere in the middle
 *    iterators  : forward and backward iterators, const and non-const
 **************************************************/
template <class T>
class list
{
public:
   // constructors, destructores, and assignment operator
   list() : numItems(0), pHead(NULL), pTail(NULL) {}
   list(const list <T> & rhs) throw (const char *) :
          pHead(NULL), pTail(NULL), numItems(0) { *this = rhs; }
  ~list()                                       { clear();     }
   list <T> & operator = (const list <T> & rhs) throw (const char *);

   // standard container interfaces
   void clear();
   bool empty() const { return (pHead == NULL); }
   int  size()  const { return numItems;        }

   // nested linked list class
   class Node;
   
   // iterators
   class               iterator;
   class         const_iterator;
   class       reverse_iterator;
   class const_reverse_iterator;
   iterator                 begin()       { return         iterator (pHead); }
   reverse_iterator        rbegin()       { return reverse_iterator (pTail); }
   const_iterator          cbegin() const { return   const_iterator (pHead); }
   iterator                 end()         { return         iterator (NULL);  }
   reverse_iterator        rend()         { return reverse_iterator (NULL);  }
   const_iterator          cend()   const { return   const_iterator (NULL);  }
   const_reverse_iterator crbegin() const
   { return const_reverse_iterator (pTail); }
   const_reverse_iterator crend()   const
   { return const_reverse_iterator (NULL);  }

   // list-specific interfaces
   void push_front(const T & data)                throw (const char *);
   void push_back (const T & data)                throw (const char *);
   T & front()                                    throw (const char *);
   T & back()                                     throw (const char *);
   iterator insert(iterator & it, const T & data) throw (const char *);
   iterator erase(iterator it);
   
private:
   int numItems;    // though we could count, it is faster to keep a variable
   Node * pHead;    // pointer to the beginning of the list
   Node * pTail;    // pointer to the ending of the list
};

/*************************************************
 * NODE
 * the node class.  Since we do not validate any
 * of the setters, there is no point in making them
 * private.  This is the case because only the
 * List class can make validation decisions
 *************************************************/
template <class T>
class list <T> :: Node
{
public:
   // default constructor: set pointers to NULL.  This is the only reason
   // why Node is not a structure
   Node() : pNext(NULL), pPrev(NULL), data() {}

   // non-default.  Initialize data as we create the node
   Node(const T & data) : pNext(NULL), pPrev(NULL), data(data) {}

   T data;                 // user data
   Node * pNext;       // pointer to next node
   Node * pPrev;       // pointer to previous node
};

/*************************************************
 * LIST ITERATOR
 * Iterate through a List, non-constant version
 ************************************************/
template <class T>
class list <T> :: iterator
{
public:
   // constructors, destructors, and assignment operator
   iterator() : p(NULL) {}
   iterator(Node * p) : p(p) {}
   iterator(const iterator  & rhs) { *this = rhs; }
   iterator & operator = (const iterator & rhs)
   {
      p = rhs.p;
      return *this;
   }
   
   // equals, not equals operator
   bool operator == (const iterator & rhs) const { return rhs.p == this->p; }
   bool operator != (const iterator & rhs) const { return rhs.p != this->p; }

   // dereference operator, fetch a node
   T & operator * () throw (const char *)
   {
      if (p)
         return p->data;
      else
         throw "ERROR: Trying to dereference a NULL pointer";
   }

   // postfix increment
   iterator operator ++ (int postfix)
   {
      iterator old(*this);
      assert(p);
      p = p->pNext;
      return old;
   }

   // prefix increment
   iterator & operator ++ ()
   {
      assert(p);
      p = p->pNext;
      return *this;
   }
   
   // postfix decrement
   iterator operator -- (int postfix)
   {
      iterator old(*this);
      assert(p);
      p = p->pPrev;
      return old;
   }

   // prefix decrement
   iterator & operator -- ()
   {
      assert(p);
      p = p->pPrev;
      return *this;
   }

   // two friends who need to access p directly
   friend iterator list <T> :: insert(iterator & it, const T & data)
                                    throw (const char *);
   friend iterator list <T> :: erase(iterator it);

private:
   list <T> :: Node * p;
};

/*************************************************
 * LIST CONST ITERATOR
 * Iterate through a List, constant version
 ************************************************/
template <class T>
class list <T> :: const_iterator
{
public:
   // constructors, destructors, and assignment operator
   const_iterator() : p(NULL) {}
   const_iterator(Node * p) : p(p) {}
   const_iterator(const const_iterator  & rhs) { *this = rhs; }
   const_iterator & operator = (const const_iterator & rhs)
   {
      p = rhs.p;
      return *this;
   }
   
   // equals, not equals operator
   bool operator == (const const_iterator & rhs) const
   { return rhs.p == this->p; }
   bool operator != (const const_iterator & rhs) const
   { return rhs.p != this->p; }

   // dereference operator, fetch a node
   T & operator * () throw (const char *)
   {
      if (p)
         return p->data;
      else
         throw "ERROR: Trying to dereference a NULL pointer";
   }

   // postfix increment
   const_iterator operator ++ (int postfix)
   {
      const_iterator old(*this);
      assert(p);
      p = p->pNext;
      return old;
   }

   // prefix increment
   const_iterator & operator ++ ()
   {
      assert(p);
      p = p->pNext;
      return *this;
   }
   
   // postfix decrement
   const_iterator operator -- (int postfix)
   {
      const_iterator old(*this);
      assert(p);
      p = p->pPrev;
      return old;
   }

   // prefix decrement
   const_iterator & operator -- ()
   {
      assert(p);
      p = p->pPrev;
      return *this;
   }

private:
   list <T> :: Node * p;
};
/*************************************************
 * LIST REVERSE ITERATOR
 * Iterate through a List backwards, non-constant version
 ************************************************/
template <class T>
class list <T> :: reverse_iterator
{
public:
   // constructors, destructors, and assignment operator
   reverse_iterator() : p(NULL) {}
   reverse_iterator(Node * p) : p(p) {}
   reverse_iterator(const reverse_iterator  & rhs) { *this = rhs; }
   reverse_iterator & operator = (const reverse_iterator & rhs)
   {
      p = rhs.p;
      return *this;
   }
   
   // equals, not equals operator
   bool operator == (const reverse_iterator & rhs) const
   { return rhs.p == this->p; }
   bool operator != (const reverse_iterator & rhs) const
   { return rhs.p != this->p; }

   // dereference operator, fetch a node
   T & operator * () throw (const char *)
   {
      if (p)
         return p->data;
      else
         throw "ERROR: Trying to dereference a NULL pointer";
   }

   // postfix increment
   reverse_iterator operator ++ (int postfix)
   {
      reverse_iterator old(*this);
      assert(p);
      p = p->pPrev;
      return old;
   }

   // prefix increment
   reverse_iterator & operator ++ ()
   {
      assert(p);
      p = p->pPrev;
      return *this;
   }
   
   // postfix decrement
   reverse_iterator operator -- (int postfix)
   {
      reverse_iterator old(*this);
      assert(p);
      p = p->pNext;
      return old;
   }

   // prefix decrement
   reverse_iterator & operator -- ()
   {
      assert(p);
      p = p->pNext;
      return *this;
   }

private:
   list <T> :: Node * p;
};

/*************************************************
 * LIST CONST REVERSE ITERATOR
 * Iterate through a List backwards, constant version
 ************************************************/
template <class T>
class list <T> :: const_reverse_iterator
{
public:
   // constructors, destructors, and assignment operator
   const_reverse_iterator() : p(NULL) {}
   const_reverse_iterator(Node * p) : p(p) {}
   const_reverse_iterator(const const_reverse_iterator  & rhs) { *this = rhs; }
   const_reverse_iterator & operator = (const const_reverse_iterator & rhs)
   {
      p = rhs.p;
      return *this;
   }
   
   // equals, not equals operator
   bool operator == (const const_reverse_iterator & rhs) const
   { return rhs.p == this->p; }
   bool operator != (const const_reverse_iterator & rhs) const
   { return rhs.p != this->p; }

   // dereference operator, fetch a node
   T & operator * () throw (const char *)
   {
      if (p)
         return p->data;
      else
         throw "ERROR: Trying to dereference a NULL pointer";
   }

   // postfix increment
   const_reverse_iterator operator ++ (int postfix)
   {
      const_iterator old(*this);
      assert(p);
      p = p->pPrev;
      return old;
   }

   // prefix increment
   const_reverse_iterator & operator ++ ()
   {
      assert(p);
      p = p->pPrev;
      return *this;
   }
   
   // postfix decrement
   const_reverse_iterator operator -- (int postfix)
   {
      const_reverse_iterator old(*this);
      assert(p);
      p = p->pNext;
      return old;
   }

   // prefix decrement
   const_reverse_iterator & operator -- ()
   {
      assert(p);
      p = p->pNext;
      return *this;
   }

private:
   list <T> :: Node * p;
};

/**********************************************
 * LIST :: assignment operator
 * Copy one list onto another
 *     INPUT  : a list to be copied
 *     OUTPUT :
 *     COST   : O(n) with respect to the number of nodes
 *********************************************/
template <class T>
list <T> & list <T> :: operator = (const list <T> & rhs) throw (const char *)
{
   // erase all the existing elements
   clear();

   // now allocate the new nodes
   for (list <T> :: Node * p = rhs.pHead; p; p = p->pNext)
      push_back(p->data); // this could throw

   // return the new buffer
   return *this;
}

/**********************************************
 * LIST :: CLEAR
 * Remove all the items currently in the linked list
 *     INPUT  :
 *     OUTPUT :
 *     COST   : O(n) with respect to the number of nodes
 *********************************************/
template <class T>
void list <T> :: clear()
{
   // loop through the entire list, removing everything
   list <T> :: Node * pNext;
   for (list <T> :: Node * p = pHead; p; p = pNext)
   {
      pNext = p->pNext;
      delete p;
   }
   pHead = pTail = NULL;
   numItems = 0;
}

/*********************************************
 * LIST :: PUSH BACK
 * add an item to the end of the list
 *    INPUT  : data to be added to the list
 *    OUTPUT :
 *    COST   : O(1)
 *********************************************/
template <class T>
void list <T> :: push_back(const T & data) throw (const char *)
{
   try
   {
      // create the node
      list <T> :: Node * pNew = new list <T> :: Node (data);

      // point it to the old tail
      pNew->pPrev = pTail;

      // now point tail to the new guy
      if (pTail != NULL)
         pTail->pNext = pNew;
      else
         pHead = pNew;   // there is no tail so there is no head!
      
      // finally, this is the new tail
      pTail = pNew;
      numItems++;
   }
   catch (...)
   {
      throw "ERROR: unable to allocate a new node for a list";
   }
}

/*********************************************
 * LIST :: PUSH FRONT
 * add an item to the head of the list
 *     INPUT  : data to be added to the list
 *     OUTPUT :
 *     COST   : O(1)
 *********************************************/
template <class T>
void list <T> :: push_front(const T & data) throw (const char *)
{
   try
   {
      // create the node
      list <T> :: Node * pNew = new list <T> :: Node (data);

      // point it to the old head
      pNew->pNext = pHead;

      // now point head to the new guy
      if (pHead != NULL)
         pHead->pPrev = pNew;
      else
         pTail = pNew;       // there is no head so there is no tail!

      // finally, this is the new head
      pHead = pNew;
      numItems++;
   }
   catch (...)
   {
      throw "ERROR: unable to allocate a new node for a list";
   }
}

/*********************************************
 * LIST :: FRONT
 * retrieves the first element in the list
 *     INPUT  : 
 *     OUTPUT : data to be displayed
 *     COST   : O(1)
 *********************************************/
template <class T>
T & list <T> :: front() throw (const char *)
{
   if (pHead != NULL)
      return pHead->data;
   else
      throw "ERROR: unable to access data from an empty list";
}

/*********************************************
 * LIST :: BACK
 * retrieves the last element in the list
 *     INPUT  : 
 *     OUTPUT : data to be displayed
 *     COST   : O(1)
 *********************************************/
template <class T>
T & list <T> :: back() throw (const char *)
{
   if (pHead != NULL)
      return pTail->data;
   else
      throw "ERROR: unable to access data from an empty list";
}

/******************************************
 * LIST :: REMOVE
 * remove an item from the middle of the list
 *     INPUT  : an iterator to the item being removed
 *     OUTPUT : iterator to the new location 
 *     COST   : O(1)
 ******************************************/
template <class T>
typename list <T> :: iterator  list <T> :: erase(list <T> :: iterator it)
{
   list <T> :: iterator itNext = end();
   
   // invalid iterator case
   if (it == end())
      return it;
   assert(pHead && pTail);
   
   // fixup everything after the current location
   if (it.p->pNext)   // not the last element
   {
      it.p->pNext->pPrev = it.p->pPrev;
      itNext = it.p->pNext;
   }
   else  // are the last element
      pTail = pTail->pPrev;

   // fixup everything before the current location
   if (it.p->pPrev) // not the first element
      it.p->pPrev->pNext = it.p->pNext;
   else
      pHead = pHead->pNext;

   // delete self and return
   delete it.p;
   numItems--;
   return itNext;
}

/******************************************
 * LIST :: INSERT
 * add an item to the middle of the list
 *     INPUT  : data to be added to the list
 *              an iterator to the location where it is to be inserted
 *     OUTPUT : iterator to the new item
 *     COST   : O(1)
 ******************************************/
template <class T>
typename list <T> :: iterator list <T> :: insert(list <T> :: iterator  & it,
                                     const T & data)
               throw (const char *)
{
   // empty list case
   if (pHead == NULL)
   {
      assert(pTail == NULL);
      pHead = pTail = new list <T> :: Node (data);
      return begin();
   }

   // make sure pHead and pTail are correctly set
   assert(pTail && pHead);
   assert(pHead->pPrev == NULL);
   assert(pTail->pNext == NULL);

   try
   { 
      list <T> :: Node * pNew = new list <T> :: Node (data);

      // end of list case
      if (it == end())
      {
         // update pTail as appropriate
         pTail->pNext = pNew;
         pNew->pPrev = pTail;
         pTail = pNew;

         // update the iterator
         it = pNew;
      }
         // otherwise we have a valid iterator
      else
      {
         // set pNext and pPrev
         pNew->pPrev = it.p->pPrev;
         pNew->pNext = it.p;

         // update who pNext and pPrev point to
         if (pNew->pPrev)
            pNew->pPrev->pNext = pNew;
         else
            pHead = pNew;
         if (pNew->pNext)
            pNew->pNext->pPrev = pNew;
         else
            pTail = pNew;

         it = pNew;
      }
      numItems++;
   }
   catch (...)
   {
      throw "ERROR: unable to allocate a new node for a list";
   }

   return it;
}

}; // namespace custom

#endif // LIST_H