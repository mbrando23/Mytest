/***********************************************************************
 * Module:
 *    Assignment 12, Spell Check
 *    Brother Helfrich, CS 235
 * Author:
 *    Luis Orbezua
 * Summary:
 *    This program will implement the spellCheck() function
 ************************************************************************/

#include <stdlib.h>      // for ABS

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <cctype>
using namespace std;

#include "spellCheck.h"
#include "hash.h"


/*******************************************************
* string HASH
* A simple hash of string
*******************************************************/
class SHash : public Hash <string>
{
public:
    SHash(int numBuckets)    throw (const char *) : Hash <string> (numBuckets) {}
    SHash(const SHash & rhs) throw (const char *) : Hash <string> (rhs)        {}

    int hash(const string & value) const
    {
        int ascci;
        if (value.empty() == true)
            throw ("ERROR: can not hash empty strings!");
        ascci = value.at(0);
        int index = abs(ascci) % capacity();
        assert(0 <= index && index < capacity());
        return index;
    }
};

class SpellCheckHelper
{
public:
    SpellCheckHelper(const char* fileName)
        : hash(27)
    {
        // open the file
        ifstream fin(fileName);
        if (fin.fail())
        {
            cout << "ERROR: Unable to open file " << fileName << endl;
            return;
        }

        // read one word at a time and tabulate
        string word;
        while (fin >> word)
        {
            this->hash.insert(word);
        }

        // all done
        fin.close();
    }

    bool hasWord(const string& word)
    {
        return this->hash.find(word);
    }
private:
    SHash hash;

    //void fillHash
};

std::string Lower_Ans(std::string word)
{
std::transform(word.begin(), word.end(), word.begin(), ::tolower);
return word;
}

/*****************************************
 * SPELL CHECK
 * Prompt the user for a file to spell-check
 ****************************************/
void spellCheck()
{
    SpellCheckHelper helper("/home/cs235/week12/dictionary.txt");

    string fileName;
    cout << "What file do you want to check? ";
    cin >> fileName;

    // open the file
    ifstream fin(fileName.c_str());
    if (fin.fail())
    {
        cout << "ERROR: Unable to open file " << fileName << endl;
        return;
    }

    // read one word at a time and tabulate
    string word;
    SHash spelled(27);
    vector<string> wrongWords;
    while (fin >> word)
    {
        string lowerString = Lower_Ans(word);
       

        if (helper.hasWord(lowerString) == false)
            if (spelled.find(word) == false)
            {
                spelled.insert(word);
                wrongWords.push_back(word);
            }
    }

    // all done
    fin.close();

    if (wrongWords.size() == 0)
        cout << "File contains no spelling errors" << endl;
    else
    {
        cout << "Misspelled: " << wrongWords[0];
        for (unsigned i=1; i<wrongWords.size(); i++)
            cout << ", " << wrongWords[i];
        cout << endl;
    }
}