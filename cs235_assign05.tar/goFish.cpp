/***********************************************************************
* Program:
*    Assignment 05, Go Fish
*    Brother JonesL, CS 235
* Author:
*    Luis Orbezua
* Summary:
*    This is all the functions necessary to play Go Fish!
*
*    Estimated:  0.0 hrs
*    Actual:     0.0 hrs
*      Please describe briefly what was the most difficult part.
************************************************************************/

#include <iostream>
#include <fstream>
#include <string>
#include "set.h"
#include "card.h"
#include "goFish.h"
using namespace std;
using namespace custom;

/**********************************************************************
 * loadhand() function
 * The function which starts it all and reading the cards
 ***********************************************************************/
set<Card> loadHand(const char* filename)
{
   set<Card> hand;
   ifstream fin;
   // opening the file to read the fish's names
   fin.open(filename);
   if (!fin) // if fail opening the file
      throw "can not open file ";

   Card card;
   //controling the document
   while (fin >> card)
   {
      // enter new card
      hand.insert(card);
   }
   // document is in the end
   fin.close();

   return hand;
}
/**********************************************************************
 * GO FISH function
 * The function which starts it all and controling the coments
 ***********************************************************************/
void goFish()
{
   set<Card> hand = loadHand("/home/cs235/week05/hand.txt");
   Card card;
   int numMatches = 0;

   cout << "We will play 5 rounds of Go Fish.  Guess the card in the hand\n";
   for (int i=0; i<5; i++)
   {
      cout << "round " << i+1 << ": ";
      cin >> card;

      set<Card>::iterator itFind = hand.find(card);
      if (itFind != hand.end())
      {
         hand.erase(itFind);
         cout << '\t' << "You got a match!\n";
         numMatches++;
      }
      else
      {
         cout << '\t' << "Go Fish!\n";
      }
   }
   cout << "You have " << numMatches <<" matches!\n";
   cout << "The remaining cards: ";
 
   for (set<Card>::const_iterator it = hand.cbegin(); it != hand.cend();)
   {
      cout << *it;
      ++it;
      if (it != hand.cend())
      {
         cout << ", ";
      }
   }
   cout<< endl;
}