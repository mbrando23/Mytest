/***********************************************************************
 * Header:
 *    Set
 * Summary:
 *    This class contains the definitions of a set: a bucket to hold
 *    data for the user. The collector cares less about the order in 
 *    which the data were acquired, rather only what has been acquired.
 *
 *    This will contain the class definition of:
 *       set             : similar to std::set
 *       set :: iterator : an iterator through the set
 * Authors
 *    Orbezuza Luis
 *    Brando Milton
 *    Sanchez Isaac
 ************************************************************************/

#ifndef SET_H
#define SET_H

#include <cassert>

/************************************************
 * class set
 * using a template  to control the different
 * types. Include all the public, privates and 
 * the  variables.  
 ***********************************************/
namespace custom 
{

template <class T>
class set
{
   public:
      // forward declaration
      class iterator; 
      class const_iterator;

      virtual ~set();
      set(); //constructor default
      set(int capacity) throw (const char *); //non default constructor
      set(const set& rhs) throw (const char *); //copy
      set& operator=(const set& rhs) throw (const char *); //assign operator
      int size() const; // number of elements
      bool empty() const; // is the container currently empty
      void clear(); // clear all elements

      iterator find(const T& element) const;//looking element return an iterator
      void insert(const T& element) throw (const char *); //insert a new element 
      void erase(iterator& it); // delete an element inside of iterator

      set operator||(const set& rhs) const throw (const char *); // union
      set operator&&(const set& rhs) const throw (const char *);//inntersection 
      set operator-(const set& rhs) const throw (const char *); // difference

      iterator begin() const;// objects that are not constant
      iterator end() const;
      const_iterator cbegin() const;// constant objects
      const_iterator cend() const;

class iterator
{
   public:
      iterator() : p(NULL) {}
      iterator(T* p) : p(p) {}
      iterator(const iterator& rhs) : p(NULL) { (*this) = rhs; }
      iterator& operator=(const iterator& rhs) { this->p = rhs.p; return (*this); }

      bool operator==(const iterator& rhs) const { return (this->p == rhs.p); }
      bool operator!=(const iterator& rhs) const { return (this->p != rhs.p); }

      iterator& operator++() { ++this->p; return (*this); }
      iterator& operator--() { --this->p; return (*this); }
      iterator operator++(int) { iterator t(this->p); ++this->p; return t; }
      iterator operator--(int) { iterator t(this->p); --this->p; return t; }

      T& operator*() { return (*p); } //return the element

   private:
      T* p;  //pointer to the element
};

class const_iterator  
{
   public:
      const_iterator() : p(NULL) {}
      const_iterator(T* p) : p(p) {}
      const_iterator(const const_iterator& rhs) : p(NULL) { (*this) = rhs; }
      const_iterator& operator=(const const_iterator& rhs) { this->p = rhs.p; return (*this); }

      bool operator==(const const_iterator& rhs) const { return (this->p == rhs.p); }
      bool operator!=(const const_iterator& rhs) const { return (this->p != rhs.p); }

      const_iterator& operator++() { ++this->p; return (*this); }
      const_iterator& operator--() { --this->p; return (*this); }
      const_iterator operator++(int) { const_iterator t(this->p); ++this->p; return t; }
      const_iterator operator--(int) { const_iterator t(this->p); --this->p; return t; }

      T operator*() const { return (*p); } // return a new object 

   private:
      T* p;
};

    private:
        T* array; // array dinamic
        int numElements;
        int numCapacity;
         // index inside of array for elements
        int findIndex(const T& element, bool indexIfNotFound=false) const;
        void resize(int newCapacity) throw (const char *);
        void reset() {this->array = NULL; this->numElements = 0; this->numCapacity = 0;}
		//allocMemory(), auxiliar function to reserve memory if the time has expired 
		static void allocMemory(int capacity, T*& ptr) throw (const char *); 
};

/************************************************
 * destructor set()
 * to control the memory  and we delete using 
 * the [] because the array
 ***********************************************/
template <class T>
set<T>::~set()// destructor implementation
{
   if (this->array != NULL)
   {
      delete [] this->array;
      this->array = NULL;
   }
}

/************************************************
 * default constructor()
 * we reuse the function reset 
 ***********************************************/
template <class T>
set<T>::set()
{
   reset();
}

/************************************************
 * nondefault constructor()
 * 
 ***********************************************/
template <class T>
set<T>::set(int capacity) throw (const char *)
{
   reset();//reuse the function
   resize(capacity);//controlling size
}

/************************************************
 * copy constructor ()
 * 
 ***********************************************/
template <class T>
set<T>::set(const set& rhs) throw (const char *)
{
   reset(); (*this) = rhs;
}

/************************************************
 * assing operator
 * evaluate the right expression and if there is
 * we pass to the left side.
 * 
 ***********************************************/
template <class T>
set<T>& set<T>::operator=(const set<T>& rhs) throw (const char *)
{
   if (this->numCapacity < rhs.size()) 
   {
      this->resize(rhs.size()); 
   }
   
   //copying the elements
   for (int i=0; i<rhs.size(); i++) 
   {
      this->array[i] = rhs.array[i];
   }
   this->numElements = rhs.size();
   return (*this);
}

/************************************************
 * size() function
 * to know how many elements there are
 ***********************************************/
template <class T>
int set<T>::size() const
{
   return this->numElements;
}

/************************************************
 * empty()
 * to know if is true or false that the set is 
 * empty or not
 ***********************************************/
template <class T>
bool set<T>::empty() const
{
   return size()==0;
}

/************************************************
 * clear()
 * to clear the set from elements
 ***********************************************/
template <class T>
void set<T>::clear()
{
   numElements = 0;
}

/************************************************
 * iterator()
 * object that, pointing to some element
 *  in a range of elements
 ***********************************************/
template <class T>
typename set<T>::iterator set<T>::find(const T& element) const
{
   int index = findIndex(element);
   iterator it(this->array + index);
   return it;
}

/************************************************
 * erase()
 * receiving and iterator taking the index and 
 * delete the element inside of the array
 ***********************************************/
template <class T>   
void set<T>::erase(typename set<T>::iterator& it)
{
   T element = (*it);
   int index = findIndex(element);
   if (this->array[index] == element) 
   {
      // to see if there are equal use for loop
      for (int i=index; i<size()-1; i++) 
	  {
         this->array[i] = this->array[i + 1];
      }
      this->numElements--;
   }
}

/************************************************
 * operator||()
 * call union put together both sets and return
 * a new one but not repeat elements
 ***********************************************/
template <class T>
set<T> set<T>::operator||(const set<T>& rhs) const throw (const char *)
{
   // new setReturn to obtain the new set as a union
   set<T> setReturn(this->size() + rhs.size()); // sum of sets sizes
   int iLhs = 0;
   int iRhs = 0;
   int n = 0;

   while (iLhs < this->size() || iRhs < rhs.size()) 
   {
      if (iLhs == this->size()) 
	  {
         setReturn.array[n++] = rhs.array[iRhs++];
      }
      else if (iRhs == rhs.size()) 
	  {
         setReturn.array[n++] = this->array[iLhs++];
      }
      else if (this->array[iLhs] == rhs.array[iRhs]) 
	  {
         setReturn.array[n++] = this->array[iLhs];
         iLhs++;
         iRhs++;
      }
      else if (this->array[iLhs] < rhs.array[iRhs]) 
	  {
         setReturn.array[n++] = this->array[iLhs++];
      }
      else 
	  {
         setReturn.array[n++] = rhs.array[iRhs++];
      }
   }
   
   setReturn.numElements = n;
   return setReturn;
}

/************************************************
 * operator&&()
 * call Intersection to show what is in commune
 ***********************************************/
template <class T>
set<T> set<T>::operator&&(const set& rhs) const throw (const char *)
{
   set setReturn(this->size() + rhs.size()); // sum of sets sizes
   int iLhs = 0;
   int iRhs = 0;
   int n = 0;
   // controlling the size 
   while (iLhs < this->size() || iRhs < rhs.size()) 
   {
      if (iLhs == this->size()) 
	  {
         setReturn.numElements = n;
         return setReturn;
      }
      else if (iRhs == rhs.size()) 
	  {
         setReturn.numElements = n;
         return setReturn;
      }
      else if (this->array[iLhs] == rhs.array[iRhs]) 
	  {
         setReturn.array[n++] = this->array[iLhs];
         iLhs++;
         iRhs++;
      }
      else if (this->array[iLhs] < rhs.array[iRhs]) 
	  {
         iLhs++;
      }
      else 
	  {
         iRhs++;
      }
   }
   setReturn.numElements = n;
   return setReturn;
}

/************************************************
 * operator-()
 * call difference help to obtain what is not 
 * repeat from one set to the other. 
 ***********************************************/
template <class T>
set<T> set<T>::operator-(const set<T>& rhs) const throw (const char *)
{
   set<T> setReturn(this->size() + rhs.size()); // sum of sets sizes
   int iLhs = 0;
   int iRhs = 0;
   int n = 0;

   while (iLhs < this->size() || iRhs < rhs.size()) 
   {
      if (iLhs == this->size()) 
	  {
         setReturn.numElements = n;
         return setReturn;
      }
      else if (iRhs == rhs.size()) 
	  {          
         setReturn.array[n++] = this->array[iLhs++];
      }
      else if (this->array[iLhs] == rhs.array[iRhs]) 
	  {
         iLhs++;
         iRhs++;
      }
      else if (this->array[iLhs] < rhs.array[iRhs]) 
	  {
         setReturn.array[n++] = this->array[iLhs++];
      }
      else 
	  {          
         iRhs++;
      }
   }
   setReturn.numElements = n;
   return setReturn;
}

/************************************************
 * iterators
 * object that, pointing to some element
 * in this case to the begin() in a range of elements
***********************************************/
template <class T>
typename set<T>::iterator set<T>::begin() const
{
   return iterator(this->array);
}

/************************************************
 * iterators
 * object that, pointing to some element
 * in this case to the end() in a range of elements
***********************************************/
template <class T>
typename set<T>::iterator set<T>::end() const
{
   return iterator(this->array+this->numElements);
}
 
/************************************************
 * iterators
 * object that, pointing to some element
 * in this case to the begin() constant
 * in a range of elements
***********************************************/
template <class T>
typename set<T>::const_iterator set<T>::cbegin() const
{
   return const_iterator(this->array);
}

template <class T>
typename set<T>::const_iterator set<T>::cend() const
{
   return const_iterator(this->array+this->numElements);
}

/************************************************
 * findIndex() function
 * index inside of arry for elements
 ***********************************************/
template <class T>
int set<T>::findIndex(const T& element, bool indexIfNotFound) const
{
   int iBegin = 0;
   int iEnd = this->numElements - 1;

   while (iBegin <= iEnd) 
   {
      int iMiddle = (iBegin + iEnd) / 2;

      T e = this->array[iMiddle];
      if (e == element) 
	  {
         return iMiddle;
      }
      if (element < e) 
	  {
         iEnd = iMiddle - 1;
      }
      else 
	  {
         iBegin = iMiddle + 1;
      }
   }

   if (indexIfNotFound == true)
      return (-1 - iBegin);
   else
      return (numElements); // ready for create end iterator
}

/************************************************
 * insert() function
 * to add new elements
 ***********************************************/
template <class T>
void set<T>::insert(const T& element) throw (const char *)
{
   int index = findIndex(element, true);

   if (index >= 0) // the element t exists!!
      return;

   index = -1 - index; // undo the two's compliment

   if (size() + 1 > this->numCapacity)
   {
      T * newData;

      // find the new capacity and allocate
      numCapacity = (numCapacity == 0 ? 1 : numCapacity * 2);
      allocMemory(numCapacity, newData);

      // copy the data over with the new item at spot index
      for (int i = 0; i < index; i++)
         newData[i] = this->array[i];

      newData[index] = element;

      for (int i = index; i < numElements; i++)
         newData[i + 1] = this->array[i];

      // set all the variables and call it a day
      numElements++;
      if (this->array != NULL) 
	  { 
         delete [] this->array; 
      }
      this->array = newData;
   }
   
        // if there is space, just shift
   else
   {
      // shift everything over from the end of the list up to the index
      for (int i = numElements; i > index; i--)
         this->array[i] = this->array[i - 1];

      // now we have space for the new item
      this->array[index] = element;
      numElements++;
   }
}

/************************************************
 * resize() function
 * controlling the size for the elements
 ***********************************************/
template <class T>
void set<T>::resize(int newCapacity) throw (const char *)
{
   T* tempArray;

   assert(newCapacity >= 0);
   newCapacity = (newCapacity == 0)? 1 : newCapacity * 2;
   allocMemory(newCapacity, tempArray);

   for (int i=0; i<this->numElements; i++)
      tempArray[i] = this->array[i];

   if (this->array != NULL)
      delete [] this->array;

   this->numCapacity = newCapacity;
   this->array = tempArray;
}

/************************************************
 * resize() function
 * auxiliar function reserved memory  
 * if the time has expired.
 ***********************************************/ 
template <class T>
void set<T>::allocMemory(int capacity,T*& newData) throw (const char *)
{
   newData = new(std::nothrow) T[capacity];
   if (NULL == newData)
      throw ("ERROR: Unable to allocate a new buffer for Set");
}


}; // namespace custom

#endif // SET_H