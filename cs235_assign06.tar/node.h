#ifndef NODE_H
#define NODE_H

#include <cassert>   // for ASSERT
#include <iostream>  // for NULL
using namespace std;

template <class T>
class Node
{
public:
   public:
      // default constructor: set pointers to NULL. This is the only reason
	  // why Node is not a structure
	  Node() : pNext(NULL), pPrev(NULL), data() {}

      // non-default. Initialize data as we create the node
	  Node(const T & data) : pNext(NULL), pPrev(NULL), data(data) {}

	  // destructor
      ~Node(){this->pNext = NULL; this->pPrev = NULL;} 

	  T data; // user data

	  Node <T> * pNext; // pointer to next node

	  Node <T> * pPrev; // pointer to previous node
};

/***********************************************
* COPY
* Copy the list from the pSource and return
* the new list
* INPUT : the list to be copied
* OUTPUT : return the new list
* COST : O(n)
**********************************************/
template <typename T>
Node<T> * copy(Node<T>* pSource)
{
    Node<T>* pDestination;
    Node<T> * pSrc, * pDest;

    if (pSource == NULL)
    {
        pDestination = NULL;
    }
    else
    {
        pDestination = new Node<T>(pSource->data);
        pSrc = pSource;
        pDest = pDestination;
        for (pSrc = pSrc->pNext; pSrc != NULL; pSrc = pSrc->pNext)
        {
            pDest = insert(pDest, pSrc->data, true);
        }
    }

    return pDestination;
}

/**********************************************
* INSERT
* Insert a new node the the value in "t" into a linked
* list immediately before the current position.
* INPUT : t - the value to be used for the new node
* pCurrent - a pointer to the node before which
* we will be inserting the new node
* after - whether we will be inserting after
* OUTPUT : return the newly inserted item
* COST : O(1)
**********************************************/
template <typename T>
Node<T> * insert(Node<T>* pCurrent, const T& data, bool after=false)
{
    Node<T>* pNewNode = new Node<T>(data);

    if (pCurrent != NULL && after == false)
    {
        pNewNode->pNext = pCurrent;
        pNewNode->pPrev = pCurrent->pPrev;
        pCurrent->pPrev = pNewNode;
        if (pNewNode->pPrev != NULL)
            pNewNode->pPrev->pNext = pNewNode;
    }
    else
    if (pCurrent != NULL && after == true)
    {
        pNewNode->pPrev = pCurrent;
        pNewNode->pNext = pCurrent->pNext;
        pCurrent->pNext = pNewNode;
        if (pNewNode->pNext != NULL)
            pNewNode->pNext->pPrev = pNewNode;
    }

    return pNewNode;
}

/******************************************************
* FIND
* Find a given node in an unsorted linked list. Return
* a pointer to the node if it is found, NULL otherwise.
* INPUT : a pointer to the head of the linked list
* the value to be found
* OUTPUT : a pointer to the node if it is found
* COST : O(n)
********************************************************/
template <typename T>
Node<T> * find(Node<T> * pHead, const T& data)
{
    for (Node<T> * p = pHead; p; p = p->pNext)
        if (p->data == data)
            return p;
    return NULL;
}

/***********************************************
* REMOVE
* Remove the node pSource in the linked list
* INPUT : the node to be removed
* OUTPUT : the pointer to the parent node
* COST : O(1)
**********************************************/
template <typename T>
Node<T> * remove(Node<T> * pRemove)
{
    Node<T>* pNodeReturn;

    if (pRemove == NULL)
        pNodeReturn = NULL;
    else
    {
        if (pRemove->pPrev != NULL)
            pRemove->pPrev->pNext = pRemove->pNext;
        else
        if (pRemove->pNext != NULL)
            pRemove->pNext->pPrev = pRemove->pPrev;

        if (pRemove->pPrev != NULL)
            pNodeReturn = pRemove->pPrev;
        else
            pNodeReturn = pRemove->pNext;

        delete pRemove;
    }

    return pNodeReturn;
}

/*****************************************************
* FREE DATA
* Free all the data currently in the linked list
* INPUT : pointer to the head of the linked list
* OUTPUT : pHead set to NULL
* COST : O(n)
****************************************************/
template <typename T>
void freeData(Node<T> *& pHead)
{
/** iterative version
    for (Node<T> * pNode = pHead; pNode != NULL; )
    {
        Node<T> * pDelete = pNode;
        pNode = pNode->pNext;
        delete pDelete;
    }

    pHead = NULL;
*/

/// recursive version
    if (pHead == NULL) /// base case
    {
        ; /// empy list
    }
    else /// recursive case
    {
        freeData(pHead->pNext);
        delete pHead;
        pHead = NULL;
    }
}

/***********************************************
* DISPLAY
* Display all the items in the linked list from here on back
* INPUT : the output stream
* pointer to the linked list
* OUTPUT : the data from the linked list on the screen
* COST : O(n)
**********************************************/
template <typename T>
ostream & operator << (ostream & out, const Node<T> * pHead)
{
    for (const Node<T> * p = pHead; p; p = p->pNext)
    {
        out << p->data;
        if (p->pNext != NULL)
            out << ", ";
    }
    return out;
}


/******************************************************
* FIND SORTED
* Find the spot in a given linked list where a given Node
* is to go. We will return a pointer to the node preceeding
* one where the new node will exist in the list
* INPUT : a pointer to the head of the linked list
* the value we are inserting
* OUTPUT : a pointer to the node we will be inserting after
* COST : O(n)
********************************************************/
template <class T>
Node <T> * findSorted(Node <T> * pHead,
	const T & t)
{
	// trivial case
	if (NULL == pHead || t < pHead->data)
		return NULL;

	// search for the node
	while (pHead->pNext && pHead->pNext->data < t)
		pHead = pHead->pNext;

	return pHead;
}

/**********************************************
* INSERT SORTED
* Insert a new node the the value in "t" into a linked
* list denoted by pHead. Place the new node in sorted order
* INPUT : the new value to be put into the linked list
* a pointer to the head of the linked list
* OUTPUT : the newly created item
* COST : O(n)
**********************************************/
template <class T>
Node <T> * insertSorted(Node <T> * & pHead,
	const T & t) throw (const char *)
{

	try
	{
		// allocate a new node
		Node <T> * pNew = new Node <T>(t);

		// find the location in the linked list immediately before
		// the new node to be inserted
		Node <T> * pFind = findSorted(pHead, t);

		// insert the new node to the head of the list
		if (pFind == NULL)
		{
			pNew->pNext = pHead;

			if (pHead)
				pHead->pPrev = pNew;

			// pHead->pNext is unchanged
			// pNew->pPrev is NULL because it is the new head
			pHead = pNew;
		}

		// otherwise, insert the new node after the found one
		else
		{
			pNew->pNext = pFind->pNext;
			pNew->pPrev = pFind;
			pFind->pNext = pNew;

			// pFind->pPrev is unchanged
		}
	}

	catch (...)
	{

		throw "ERROR: Unable to allocate a new Node";

	}
}




#endif // NODE_H