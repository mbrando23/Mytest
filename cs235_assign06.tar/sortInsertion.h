/***********************************************************************
 * Header:
 *    INSERTION SORT
 * Summary:
 *    This will contain just the prototype for insertionSortTest(). You may
 *    want to put other class definitions here as well.
 * Authors
 *     Orbezuza Luis
 *     Brando Milton
 *     Sanchez Isaac
 ************************************************************************/

#ifndef INSERTION_SORT_H
#define INSERTION_SORT_H

#include "node.h"

/***********************************************
 * INSERTION SORT
 * Sort the items in the array
 **********************************************/
template <class T>
void sortInsertion(T array[], int num)
{
   /*
   int j, temp;
   for (int i = 0; i < num; i++)
   {
      j = i;
		
      while (j > 0 && array[j] < array[j-1])
      {
         temp = array[j];
         array[j] = array[j-1];
         array[j-1] = temp;
         j--;
      }
   }


   */
}
#endif // INSERTION_SORT_H

