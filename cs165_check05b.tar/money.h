/******************
 * File: money.h
 ******************/
#ifndef MONEY_H
#define MONEY_H

class Money
{
private:
   int dollars;
   int cents;

public:
   void prompt();
   void display() const;
   int  getDollars() const;
   int  getCents() const;
   void setDollars(int);
   void setCents(int);
   Money()
   { 
   dollars = 0;
   cents   = 0;
   }
   Money(int dollars) : cents(0) 
   { 
      setDollars(dollars); 
   }
   Money(int dollars, int cents)
   { 
      setDollars(dollars);
	  setCents(cents); 
   }
};

#endif
