/***********************************************************************
* Header:
*    deque.h
* Summary:
*    This file is a Template class that implements a deque and behaves 
*    as the std::deque class
* Authors
*     Orbezuza Luis 
*     Brando Milton
*     Sanchez Isaac
************************************************************************/

#ifndef DEQUE_H
#define DEQUE_H

#include <iostream>
#include <string>
#include <cassert>

namespace custom
{	
/*************************************************************
* Deque
* a class encapsulating the notion of a array-based circular
* deque as described in the textbook.
*************************************************************/
template <class T>
class deque
{
   friend std::ostream& operator<<(std::ostream& out, deque<T> d)
   {
      out << "{ "; 
      while (!d.empty())
      {
         out << d.front() << " ";
         d.pop_front();
      }
      out << "}";

      return out;
   }

   public:
      
	  //DEF Constructor
      deque();
		
      //Non-DEF Constructor
      deque(int capacity) throw (const char *);
		
      //Copy Constructor
      deque(const deque& rhs) throw (const char *);
		
      // Destructor
      virtual ~deque();
		
      // Assignment Op
      deque& operator=(const deque& rhs) throw (const char *);

      ////////STANDARD METHODS////////
	  int size() const;
      void clear();
      bool empty() const;

      ////////NEW METHODS////////
      void push_back(const T & e) throw(const char *);
      void push_front(const T & e) throw(const char *);
      void pop_back() throw(const char *);
      void pop_front() throw(const char *);
		
      // GET and SET Front
      T & front() throw (const char *);
      const T& front() const throw (const char*);
      
	  // GET and SET Back
      T & back() throw(const char *);
      const T& back() const throw (const char*);
		
   private:
		
      T* array;
      int nCapacity;
      int iFront;
      int iBack;

	  void reset()
      {
         this->array = NULL;
         this->nCapacity = 0;
         this->iFront = 0; 
         this->iBack = -1;
      }
	  
	  // auxiliary method to check the internal state of variables.
      void debug(const std::string& fname)
      {
         std::cout << "debug{" << fname <<"}, c:" << this->nCapacity 
		 << " s:" << this->size() << " f:" << this->iFront << " b:" 
		 << this->iBack << std::endl;
      }
	  
      void resize(int newCapacity = 0) throw(const char*);
      int capacity() const;
      int iFrontNormalized() const;
      int iBackNormalized() const;
	  int iNormalized(int i) const;
};

/*************************************************************
* deque Def Constructor
* sets everything to 0
*************************************************************/
template <class T>
deque<T>::deque()
{
   reset(); // calling the function 
}

/*************************************************************
* deque non Def constructor
* non-default constructor (taking a capacity value as a parameter)
*************************************************************/
template <class T>
deque<T>::deque(int capacity) throw (const char *) 
{
   reset();
   this->resize(capacity);
}

/*************************************************************
* deque Copy Constructor
* sets still everything to zero but sets the rhs to this
* to get space for the deque
*************************************************************/
template <class T> //copy constructor
deque<T>::deque(const deque& rhs) throw (const char *)
{
   reset();
   (*this) = rhs; // copy rhs on *this
}

/*************************************************************
* deque Destructor
* when called the class should delete all the allocated memory.
*************************************************************/
template <class T>
deque<T>::~deque()
{
   if (this->array != NULL)
   {
      delete[] this->array;
      this->array = NULL;
   }
}	
	
/*************************************************************
* deque Assignment operator =
* takes a deque as a parameter and copies all the elements to this.
* if the current buffer size is sufficient, not allocation is made.
* if the current buffer size is not sufficient, enough space is
* allocated to accomodate the new data.
* resize() will handle the allocation
*************************************************************/
template <class T>
deque<T>& deque<T>::operator=(const deque<T>& rhs)  throw (const char *)
{
   this->clear();// reset internal variables

   if (this->capacity() < rhs.size())// check if the capacity is sufficient
   {
       this->resize(rhs.size());
   }
   //copy the elements of rhs to this with the i, the j runs the elements that
   //are in deque, it begins with the ifront
   for (int i=0, j=rhs.iFront; i<rhs.size(); i++)
   {
   //iNormalized translates the value of the indices to values between 0 
   //and capacity-1
       this->push_back(rhs.array[rhs.iNormalized(j)]);
       j++;
   }
   //after finishing the for we had to return
   return (*this); 
}

/*************************************************************
* deque size
* returns the deque size. This method takes no parameters 
* and returns an integer value.
*************************************************************/
template <class T>
int deque<T>::size() const
{
   return (this->iBack - this->iFront + 1); // page 103 of textbook
}

/*************************************************************
* deque clear
* empties the deque of all elements. There are no parameters
* and no return value.
*************************************************************/
template <class T>
void deque<T>::clear() // from book
{
   this->iFront = 0;
   this->iBack = -1;
}

/*************************************************************
* deque empty
* test whether the deque is empty. This method takes no 
* parameters and returns a Boolean value.
*************************************************************/
template <class T>
bool deque<T>::empty() const
{
   return (size() == 0);
}

/*************************************************************
* deque push_back
* adds an element to the deque. This method takes a single parameter
* "element" to be added to the end of the deque and has no 
* return value. Note that if the deque is full, then the 
* capacity will be doubled. In the case of an allocation error
* resize() will handle the allocation error message
*************************************************************/
template <class T>
void deque<T>::push_back(const T& e) throw (const char *)
{
   if (this->size() == this->capacity())
   {
       this->resize(this->capacity() * 2);
	   //throw if resize no sufficient memory
   }
   this->iBack++;
   this->array[this->iBackNormalized()] = e;
}

/*************************************************************
* deque push_front
* adds an element to the deque. This method takes a single parameter
* "element" to be added to the front of the deque and has no 
* return value. Note that if the deque is full, then the 
* capacity will be doubled. In the case of an allocation error
* resize() will handle the allocation error message
*************************************************************/
template <class T>
void deque<T>::push_front(const T& e) throw (const char *)
{
   if (this->size() == this->capacity())
   {
       resize(this->capacity() * 2);
   }

   this->iFront--; // from book
   this->array[iFrontNormalized()] = e;
}

/*************************************************************
* deque pop_back
* removes an element from the tail of the deque, serving to 
* reduce the size by one. Note that if the deque is already 
* empty, the deque remains unchanged.
************************************************************/
template <class T>
void deque<T>::pop_back() throw(const char *)
{
   if (this->empty() == true)
   {
       return;
   }
   this->iBack--;
}

/*************************************************************
* deque pop_front
* removes an element from the head of the deque, serving to 
* reduce the size by one. Note that if the deque is already 
* empty, the deque remains unchanged.
************************************************************/
template <class T>
void deque<T>::pop_front() throw(const char *)
{
   if (this->empty() == true)
   {
       return;
   }
   this->iFront++;
}

/*************************************************************
* deque front Get and Set
* returns the element currently at the front of the deque.
* There are two versions of this method: one that returns the 
* element by-reference so the element can be changed through
* the front() method. The second version returns the element
* by-value or const by-reference so this is not changed.
* If the deque is currently empty, the following exception 
* will be thrown:
* ERROR: attempting to access an element in an empty deque
*************************************************************/

template <class T>
T & deque<T>::front() throw (const char *)
{
   if (this->empty() == true)
   {
       throw ("ERROR: unable to access data from an empty deque");
   }
   return this->array[this->iFrontNormalized()];
}

template <class T>
const T& deque<T>::front() const throw (const char*)
{
   if (this->empty() == true)
   {
       throw ("ERROR: unable to access data from an empty deque");
   }
   return this->array[this->iFrontNormalized()];
}

/*************************************************************
* deque back Get and Set
* returns the element currently at the back of the deque. 
* There are two versions of this method: one that returns the 
* element by-reference so the element can be changed through 
* the back() method. The second version returns the element
* by-value or const by-reference so this is not changed. 
* If the deque is currently empty, the following exception
* will be thrown:
* ERROR: attempting to access an element in an empty deque
*************************************************************/
template <class T>
T& deque<T>::back() throw (const char *)
{
   if (this->empty() == true)
   {
       throw ("ERROR: unable to access data from an empty deque");
   }
   return this->array[this->iBackNormalized()];
}
	
template <class T>
const T& deque<T>::back() const throw (const char*)
{
   if (this->empty() == true)
   {
       throw ("ERROR: unable to access data from an empty deque");
   }
   return this->array[this->iBackNormalized()];
}

/*************************************************************
* Resize
* the Resize will mod the deque to grow to accommodate any amount 
* of data. it will be used by Push, operator=, to handle the 
* new sizes and errors
*************************************************************/
template <class T>
void deque<T>::resize(int newCapacity) throw(const char*)
{
   T* tempArray;
   int lastIndex;

   assert(newCapacity >= 0);

   newCapacity = (newCapacity == 0)? 1 : newCapacity;

   tempArray = new(std::nothrow) T[newCapacity];
   if (tempArray == NULL)
   {
       throw ("ERROR: unable to allocate a new buffer for deque");
   }

   lastIndex = 0;
   for (int j=this->iFront; lastIndex<this->size(); j++)
   {
       tempArray[lastIndex] = this->array[iNormalized(j)];
       lastIndex++;
   }

   if (this->array != NULL)
   {
       delete [] this->array;
   } 

   this->array     = tempArray;
   this->nCapacity = newCapacity;
   this->iFront    = 0;
   this->iBack     = lastIndex - 1;
}

/*************************************************************
* capacity
*************************************************************/
template <class T>
int deque<T>::capacity() const
{
   return this->nCapacity;
}	  
	  
/*************************************************************
* iFrontNormalized
* Will keep track of the head of the deque
*************************************************************/
template <class T>
int deque<T>::iFrontNormalized() const
{
   return this->iNormalized(this->iFront);
}

/*************************************************************
* iBackNormalized
* Will keep track of the tail of the deque
*************************************************************/
template <class T>
int deque<T>::iBackNormalized() const
{
   return this->iNormalized(this->iBack);
}

/*************************************************************
* iNormalized
*************************************************************/
template <class T> 
int deque<T>::iNormalized(int i) const
{
   int iNorm;

   if (i >= 0)
   {
       iNorm = (i % this->nCapacity);
   }
   else
   { // if index is negative
       iNorm = (this->nCapacity - 1) - ((-i - 1) % this->nCapacity);
   }

   return (iNorm);
}


};     // NAMESPACE CUSTOM

#endif //DEQUE_H