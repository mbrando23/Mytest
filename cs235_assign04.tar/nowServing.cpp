/***********************************************************************
 * Implementation:
 *    NOW SERVING
 * Summary:
 *    This will contain the implementation for nowServing() as well as any
 *    other function or class implementations you may need
 * Author
 *    <your names here>
 **********************************************************************/

#include <iostream>     // for ISTREAM, OSTREAM, CIN, and COUT
#include <string>       // for STRING
#include <cassert>      // for ASSERT
#include "nowServing.h" // for nowServing() prototype
#include "deque.h"       // for DEQUE

using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::ostream;
using std::ios;
//using namespace std;
using namespace custom;

/************************************************
 * NOW SERVING
 * The interactive function allowing the user to
 * handle help requests in the Linux lab
 ***********************************************/
void nowServing()
{
   // instructions
   cout << "Every prompt is one minute.  The following input is accepted:\n";
   cout << "\t<class> <name> <#minutes>    : a normal help request\n";
   cout << "\t!! <class> <name> <#minutes> : an emergency help request\n";
   cout << "\tnone                         : no new request this minute\n";
   cout << "\tfinished                     : end simulation\n";

   // your code here

   deque <helpRequest> serving;
   helpRequest servingUntil;
    
   string course; //Class cs124
   string name; //Name student
   int minutes = 0; //#minutesRequired
   bool urgent = false; // is it urgent?
   string input;
   int i = 0;

   do
   {
   
      cout << "<" << i << "> ";
      i++;
      cin >> input;
      if (input != "none")
      {
         if (input == "!!")
         {
            bool urgent = true;
            int minutes = 0;
            cin >> course;
            cin >> name;
            cin >> minutes;
            helpRequest help(urgent, course, name, minutes);
            serving.push_back(help);
         }
         else
         {
            bool urgent = false;
            int minutes = 0;
            course = input;
            cin >> name;
            cin >> minutes;

            helpRequest help(urgent, course, name, minutes);
            serving.push_back(help);
         }
         

      }
      
	  if (servingUntil.getMinutes())
      {
         servingUntil.decrementsTime();
      }
   
      if (!servingUntil.getMinutes())
      {
         if (!serving.empty())
         {
            servingUntil = serving.front();
            serving.pop_front();
         }
      }

      if (servingUntil.getMinutes())
      {
         if (servingUntil.isUrgent())
         {
            cout << "\tEmergency for "
                 << servingUntil.getName()
                 << " for class " << servingUntil.getCourse()
                 << ". Time left: " << servingUntil.getMinutes()
                 << endl;
         }
         else
         {
            cout << "\tCurrently serving " << servingUntil.getName()
                 << " for class " << servingUntil.getCourse()
                 << ". Time left: " << servingUntil.getMinutes() << endl;
         }
      }
 
   }
   while (input != "finished");
    



}