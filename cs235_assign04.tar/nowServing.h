/***********************************************************************
 * Header:
 *    NOW SERVING
 * Summary:
 *    This will contain just the prototype for nowServing(). You may
 *    want to put other class definitions here as well.
 * Author
 *    <your names here>
 ************************************************************************/

#ifndef NOW_SERVING_H
#define NOW_SERVING_H

#include <string>
#include "deque.h"     // for DEQUE
using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::ostream;
using std::ios;

// the interactive nowServing program
void nowServing();

class helpRequest
{
   public:
      //def contructor // t!!         <class>     <name>      <#minutes>
      helpRequest() { urgent = false; course = ""; name = ""; minutes = 0; }

      //non Def Constructor will set the values received from the nowServing.cpp
      // file to the varables in the header file with this
      helpRequest(bool urgent, string course, string name, int minutes) 
      {
         this->urgent = urgent; 
         this->course = course;
         this->name = name;
         this->minutes = minutes;
      }
      
	  //assignment Op, copy everything from the rhs to the variables
      helpRequest & operator = (const helpRequest & rhs)
      {
         this->urgent = rhs.urgent;
         this->course = rhs.course;
         this->name = rhs.name;
         this->minutes = rhs.minutes;
         return *this;
      }

      //getters will return the values from the header file
      // to the cpp
      bool isUrgent() { return urgent; } 
      int getMinutes() { return minutes; }
      string getCourse() { return course; }
      string getName() { return name; }
      void decrementsTime() { minutes--; }

   private:

      int minutes;
      string name;
      string course;
      bool urgent;

};

#endif // NOW_SERVING_H