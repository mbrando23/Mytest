/*********************************************************************
 * File: check04b.cpp
 * Purpose: contains the main method to exercise the Date class.
 *********************************************************************/

#include "date.h"

#include <iostream>
using namespace std;

int main()
{
   // prompt for month, day, year
   int month;
   int day;
   int year;
   cout << "Month: ";
   cin  >> month;
   cout << "Day: ";
   cin  >> day;
   cout << "Year: ";
   cin  >> year;
   cout << endl;
   
   // create a Date object
   Date testDate;
   
   // set its values
   testDate.set(month, day, year);
   
   // call each display function
   testDate.displayAmerican();
   testDate.displayEuropean();
   testDate.displayISO();

   return 0;
}
