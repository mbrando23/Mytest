// File: customer.h

#ifndef CUSTOMER_H
#define CUSTOMER_H

#include "address.h"
#include <iostream>                // input output
#include <string>                  // to use strings
using namespace std;               // standard use of libs

/**************************************************************
 * CUSTOMER
 * Contains the definition of the Customer class
 *************************************************************/

class Customer
{
   private:
      string  name;                // store customer name 
      Address address;             // a class member
	   
   public:
      string  getName();           // return name
      Address getAddress();        // return address name
      void    setName(string);     // set private name
      void    setAddress(Address); // set private address class
      void    display();           // display
      Customer()                   // default inline constructor
      {
         name    = "unspecified";
         address = Address();
      }
      Customer(string name, Address address)
      {
         setName(name);            // non default inline constructor
         this->address = address; 		  
      }
};

#endif
