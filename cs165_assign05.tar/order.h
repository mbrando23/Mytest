// File: order.h

#ifndef ORDER_H
#define ORDER_H

#include "product.h"
#include "customer.h"


#include <iostream>                     // input output
#include <string>                       // to use strings
using namespace std;                    // standard use of libs

/**************************************************************
 * ORDER
 * Contains the definition of the Order class
 *************************************************************/

class Order
{
   private:
      Product  product;                 // private class member 
      int      quantity;                // private member
      Customer customer;                // private class member
	   
   public:
      Product  getProduct();            // return Product
      int      getQuantity();           // return quantity
      Customer getCustomer();           // return Customer
      string   getShippingZip();        // return ZIP 
      float    getTotalPrice();         // return total price
      void     setProduct(Product);     // set class member
      void     setQuantity(int);        // set private member
      void     setCustomer(Customer);   // set class member
      void     displayShippingLabel();  // display shipping label
      void     displayInformation();    // display order information
      Order()                           // default inline constructor 
      {
         quantity = 0;
         product  = Product();
         customer = Customer();
      }
      Order(Product product, int quantity, Customer customer)
      {
         setQuantity(quantity);         // non default inline constructor
         this->product  = product; 
         this->customer = customer;
      }
};


#endif
