// File: customer.cpp

#include "customer.h"
#include <iostream>                  // input output
#include <string>                    // to use strings
#include <iomanip>                   // to use cout.setf and setw
using namespace std;                 // standard use of libs

/*************************************************************
 ******************** GETTERS ********************************
 *************************************************************/
 
/*******************************
 * GETNAME
 * return customer name.
 *********************************/ 
string Customer :: getName()
{
   return name;
}

/*******************************
 * GETADDRESS
 * return customer address.
 *********************************/     
Address Customer :: getAddress()
{
   return address;
}
	  
/*************************************************************
 ******************** SETTERS ********************************
 *************************************************************/
 
/*******************************
 * SETNAME
 * set customer name into member variable.
 *********************************/
void Customer :: setName(string name)
{
   this->name = name;	
}

/*******************************
 * SETADDRESS
 * set customer address into class variable.
 *********************************/
void Customer :: setAddress(Address address)
{
   this->address = address;
}
	    
/*************************************************************
 ******************** DISPLAY ********************************
 *************************************************************/

/*******************************
 * DISPLAY
 * display the name, then calls the address's display method.
 *********************************/ 
void Customer :: display()
{
   cout << name
        << endl;
   address.display();	
}


	
	
	



