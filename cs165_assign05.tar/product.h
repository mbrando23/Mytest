/***************************************************************
 * File: product.h
 * Author: Milton Nogueira Brando Neto
 * Summary:
 * This file gives a class for products in order to handle them.
 ***************************************************************/
#ifndef PRODUCT_H
#define PRODUCT_H
#include <iostream>                 // input output
#include <string>                   // to use strings
using namespace std;                // standard use of libs

/**************************************************************
 * PRODUCT
 * Contains the definition of the Product class
 *************************************************************/
class Product
{
   private:
      string name;                   // store product name 
      string description;            // store product description
      float  weight;                 // store product weight
      float  basePrice;              // store product price
	   
   public:
      void   prompt();               // prompt for products features
      float  getSaleTax();           // return tax
      float  getShippingCost();      // return shipping cost
      float  getTotalPrice();        // return total cost
      string getName();              // return product name
      string getDescription();       // return product description
      float  getBasePrice();         // return principal
      float  getWeight();            // return product weight
      void   setName(string);        // set private member
      void   setDescription(string); // set private member
      void   setBasePrice(float);    // set private member
      void   setWeight(float);       // set private member
      void   displayAdvertising();   // display advertising mode
      void   displayInventory();     // display inventory mode
      void   displayReceipt();       // display receipt mode
      Product()                      // default inline constructor
      {
         name        = "none";
         description = "";
         weight      = 0;
         basePrice   = 0;
      }
      Product(string name, string description, float basePrice, float weight)
      {
         setName(name);              // non defautl inline constructor 
         setDescription(description);
         setBasePrice(basePrice);
         setWeight(weight);
      }
};


#endif
