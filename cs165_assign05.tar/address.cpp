// File: address.cpp

#include "address.h"
#include <iostream>                  // input output
#include <string>                    // to use strings
#include <iomanip>                   // to use cout.setf and setw
using namespace std;                 // standard use of libs

/*************************************************************
 ******************** GETTERS ********************************
 *************************************************************/
 
/*******************************
 * GETSTREET
 * return street name.
 *********************************/ 
string Address :: getStreet()
{
   return street;
}	

/*******************************
 * GETCITY
 * return city name.
 *********************************/       
string Address :: getCity()
{
   return city;
}

/*******************************
 * GETSTATE
 * return State name.
 *********************************/ 
string Address :: getState()
{
   return state;
}

/*******************************
 * GETZIP
 * return ZIP.
 *********************************/ 	  
string Address :: getZip()
{
   return zip;
}
	  
/*************************************************************
 ******************** SETTERS ********************************
 *************************************************************/
 
/*******************************
 * SETSTREET
 * set street name into member variable.
 *********************************/
void Address :: setStreet(string street)
{
   this->street = street;
}

/*******************************
 * SETCITY
 * set city name into member variable.
 *********************************/
void Address :: setCity(string city)
{
   this->city = city;
}

/*******************************
 * SETSTATE
 * set state name into member variable.
 *********************************/
void Address :: setState(string state)
{
   this->state = state;	
}

/*******************************
 * SETZIP
 * set ZIP name into member variable.
 *********************************/
void Address :: setZip(string zip)
{
   this->zip = zip;
}	
	  
	  
/*************************************************************
 ******************** DISPLAY ********************************
 *************************************************************/

/*******************************
 * DISPLAY
 * Display the address.
 *********************************/ 
void Address :: display()
{
   cout << street
        << endl
        << city
        << ", "
        << state
        << " "
        << zip
        << endl; 
}	




