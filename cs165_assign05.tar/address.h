// File: address.h

#ifndef ADDRESS_H
#define ADDRESS_H
#include <iostream>                // input output
#include <string>                  // to use strings
using namespace std;               // standard use of libs

/**************************************************************
 * ADDRESS
 * Contains the definition of the Address class
 *************************************************************/

class Address
{
   private:
      string street;               // store street name 
      string city;                 // store city name
      string state;                // store state name
      string zip;                  // store ZIP code
	   
   public:
      string getStreet();          // return street name
      string getCity();            // return city name
      string getState();           // return state
      string getZip();             // return ZIP
      void   setStreet(string);    // set private street
      void   setCity(string);      // set private city
      void   setState(string);     // set private state
      void   setZip(string);       // set private ZIP
      void   display();            // display     
      Address()                    // default inline constructor
      {
         street = "unknown";
         zip    = "00000";
         state  = "";
         city   = "";
      }
      Address(string street, string city, string state, string zip)
      {
         setStreet(street);        // non default inline constructore
         setCity(city);
         setState(state);
         setZip(zip);
      }
};
 


#endif
