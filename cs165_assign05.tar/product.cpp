/***************************************************************
 * File: product.cpp
 * Author: Milton Nogueira Brando Neto
 * Purpose: Contains the method implementations for the Product class.
 ***************************************************************/

#include "product.h"                 // class work
#include <iostream>                  // input output
#include <string>                    // to use strings
#include <iomanip>                   // to use cout.setf and setw
using namespace std;                 // standard use of libs

/*******************************
 * PROMPT
 * Prompt in order to receive the
 * product features from the user.
 *********************************/
void  Product :: prompt()
{
   cout << "Enter name: ";
   getline(cin, name);               // receive name from user
   cout << "Enter description: ";
   getline(cin, description);        // receive product description
   cout << "Enter weight: ";
   cin  >> weight;                   // receive product weight
   do
   {   
      cout << "Enter price: ";       
      cin  >> basePrice;             // receive price from user
      if (cin.fail())                // if it is not a number
      {
         cin.clear();
         cin.ignore(256, '\n');
      }
   }
   while (basePrice <= 0);           // until price is given rightly
}
   
/*************************************************************
 ******************** GETTERS ********************************
 *************************************************************/   
 
/*******************************
 * GETSALETAX
 * Calculate and return tax related 
 * to the product.
 *********************************/
float Product :: getSaleTax()
{
   return basePrice * 0.06;            // compute tax and return it
}

/*******************************
 * GETSHIPPINGCOST
 * Calculate and return shipping cost
 * related to the product.
 *********************************/   
float Product :: getShippingCost()
{
   if (weight < 5)
      return 2;                        // fixed cost
   else
   {
      int plus = weight - 5;           // variable cost here
      return 2 + (plus * 0.10);
   }
}

/*******************************
 * GETTOTALPRICE
 * Calculate and return total price
 * related to the product.
 *********************************/   
float Product :: getTotalPrice()
{
   float tax      = getSaleTax();      // from other method
   float shipping = getShippingCost(); // from other method	   
   return basePrice + tax + shipping;  // return total cost
}

/*******************************
 * GETNAME
 * return product name.
 *********************************/ 
string Product :: getName()
{
   return name;
}

/*******************************
 * GETDESCRIPTION
 * return product description.
 *********************************/ 
string Product :: getDescription()
{
   return description;
}
	  
/*******************************
 * GETBASEPRICE
 * return product inicial price.
 *********************************/ 
float Product :: getBasePrice()
{
   return basePrice;
}
	  
	  
/*******************************
 * GETWEIGHT
 * return product weight.
 *********************************/ 
float Product :: getWeight()
{
   return weight;	
}

/*************************************************************
 ******************** SETTERS ********************************
 *************************************************************/
 
/*******************************
 * SETNAME
 * set product name into member variable.
 *********************************/
void Product :: setName(string name)
{
   this->name = name;	
}
	  
/*******************************
 * SETDESCRIPTION
 * set product description into member variable.
 *********************************/	  
void Product :: setDescription(string description)
{
   this->description = description;
}

/*******************************
 * SETBASEPRICE
 * set product price into member variable.
 *********************************/
void Product :: setBasePrice(float basePrice)
{
   this->basePrice = basePrice;
}

/*******************************
 * SETWEIGHT
 * set product weight into member variable.
 *********************************/
void Product :: setWeight(float weight)
{
   this->weight = weight;	
}
 

/*************************************************************
 ******************** DISPLAY ********************************
 *************************************************************/

/*******************************
 * DISPLAYADVERTISING
 * Display into the advertising mode.
 *********************************/
void  Product :: displayAdvertising()
{
   cout.setf(ios::fixed);             // not scientific notation
   cout.setf(ios::showpoint);         // show point into numbers 
   cout.precision(2);                 // show 2 decimals
   cout << name
        << " - $"
        << basePrice
        << endl
        << "("
        << description
        << ")"
        << endl;
}

/*******************************
 * DISPLAYINVENTORY
 * Display into the inventory mode.
 *********************************/   
void  Product :: displayInventory()
{
   cout.setf(ios::fixed);            // not scientific notation
   cout.setf(ios::showpoint);        // show point into numbers 
   cout.precision(2);                // show 2 decimals
   cout << "$"
        << basePrice
        << " - "
        << name
        << " - ";
   cout.precision(1);                // show 1 decimal
   cout << weight
        << " lbs"
        << endl;
}

/*******************************
 * DISPLAYRECEIPT
 * Display into the receipt mode.
 *********************************/    
void  Product :: displayReceipt()
{
   cout.setf(ios::fixed);            // not scientific notation
   cout.setf(ios::showpoint);        // show point into numbers
   cout.precision(2);                // show 2 decimals
   cout << name
        << endl
        << "  Price:         $"
        << setw(8) << basePrice         << endl
        << "  Sales tax:     $"
        << setw(8) << getSaleTax()      << endl
        << "  Shipping cost: $"
        << setw(8) << getShippingCost() << endl
        << "  Total:         $"
        << setw(8) << getTotalPrice()   << endl;
}











