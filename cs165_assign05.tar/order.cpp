// File: order.cpp

#include "order.h"

#include <iostream>                  // input output
#include <string>                    // to use strings
#include <iomanip>                   // to use cout.setf and setw
using namespace std;                 // standard use of libs


/*************************************************************
 ******************** GETTERS ********************************
 *************************************************************/
 
/*******************************
 * GETPRODUCT
 * return a product.
 *********************************/ 
Product Order :: getProduct()
{
   return product;	
}

/*******************************
 * GETQUANTITY
 * return a quantity number.
 *********************************/ 	  
int Order :: getQuantity()
{
   return quantity;	
}

/*******************************
 * GETCUSTOMER
 * return a customer.
 *********************************/ 
Customer Order :: getCustomer()
{
   return customer;	
}


/*******************************
 * GETSHIPPINGZIP
 * return the Zip from the customer's address.
 *********************************/ 
string Order :: getShippingZip()
{
   Address address = customer.getAddress();
   return address.getZip();
}
	
	
/*******************************
 * GETTOTALPRICE
 * return the total price of the product (including tax 
 * and shipping) multiplied by the quantity. 
 *********************************/ 
float Order :: getTotalPrice()
{
   float total = product.getTotalPrice(); 
   return quantity * total;
}

/*************************************************************
 ******************** SETTERS ********************************
 *************************************************************/

/*******************************
 * SETPRODUCT
 * set product into class variable.
 *********************************/
void Order :: setProduct(Product product)
{
   this->product = product;
}

/*******************************
 * SETQUANTITY
 *  set quantity into member variable.
 *********************************/
void Order :: setQuantity(int quantity)
{
   this->quantity = quantity;
}

/*******************************
 * SETCUSTOMER
 * set customer into class variable.
 *********************************/
void Order :: setCustomer(Customer customer)
{
   this->customer = customer;
}
	   
/*************************************************************
 ******************** DISPLAY ********************************
 *************************************************************/

/*******************************
 * DISPLAYSHIPPINGLABEL
 * call the customer's display method.
 *********************************/ 
void Order :: displayShippingLabel() 
{
   customer.display();	
}

/*******************************
 * DISPLAYINFORMATION
 * display the customer's name, the product's name,
 * and the total price of the order.
 *********************************/ 
void Order :: displayInformation()
{
   cout.setf(ios::fixed);            // not scientific notation
   cout.setf(ios::showpoint);        // show point into numbers
   cout.precision(2);                // show 2 decimals
   cout << customer.getName()
        << endl
        << product.getName()
        << endl
        << "Total Price: $"
        << getTotalPrice()
        << endl;		
}






