/***********************************************************************
 * Header:
 *    Vector
 * Summary:
 *    This class contains the notion of an vector: a bucket to hold
 *    data for the user. This is just a starting-point for more advanced
 *    constainers such as the vector, set, stack, queue, deque, and map
 *    which we will build later this semester.
 *
 *    This will contain the class definition of:
 *       vector             : similar to std::vector
 *       vector :: iterator : an iterator through the vector
 * Author
 *    Br. Milton
 ************************************************************************/

#ifndef VECTOR_H
#define VECTOR_H

// a little helper macro to write debug code
#ifdef NDEBUG
#define Debug(statement)
#else
#define Debug(statement) statement
#endif // !NDEBUG

#include <iostream>
#include <cassert>  // because I am paranoid

namespace custom
{

/************************************************
* VECTOR
* A class that holds stuff
***********************************************/
template <class T>
class vector
{
   public:

   // default constructor : empty and kinda useless
   vector() : num(0), numCapacity(0), data(0x00000000) {}

   // copy constructor : copy it
   vector(const vector & rhs) throw (const char *);

   // non-default constructor : pre-allocate
   vector(int numCapacity) throw (const char *);

   // destructor : free everything
   ~vector() { if (numCapacity) delete[] data; }

   // assignment operator
   vector & operator = (const vector & rhs) throw (const char *);
   
   // is the container currently empty
   bool empty() const { return num == 0; }

   // remove all the items from the container
   void clear() { num = 0; }

   // how many items are currently in the container?
   int size() const { return num; }
   
   // display
   void display() const;

   // add an item to the container
   void insert(const T & t) throw (const char *);
   void push_back(const T & t) throw (const char *);
   
   // return the capacity
   int capacity() const { return numCapacity; }

   // the various iterator interfaces
   class iterator;
   // return an iterator to the beginning of the list
   iterator begin()      { return iterator (data); }
   // return an iterator to the end of the list
   iterator end() { return iterator (data + num); }
   
   
  // what would happen if I passed -1 or something greater than num?
   T & operator [] (int index)       throw (const char *){ return data[index];}
   T   operator [] (int index) const throw (const char *){ return data[index];}
   
   
   private:

   T * data;        // dynamically allocated array of T

   int num;         // how many items are currently in the Container?

   int numCapacity; // how many items can I put on the Container before full?

};


/**************************************************
* ITERATOR
* An iterator through Container
*************************************************/
template <class T>
class vector <T> :: iterator
{
   public:

   // default constructor
   iterator() : p(0x00000000) {}

   // initialize to direct p to some item
   iterator(T * p) : p(p) {}

   // copy constructor
   iterator(const iterator & rhs) { *this = rhs; }

   // assignment operator
   iterator & operator = (const iterator & rhs)
   {
      this->p = rhs.p;
      return *this;
   }

   // not equals operator
   bool operator != (const iterator & rhs) const
   {
      return rhs.p != this->p;
   }

   // dereference operator
   T & operator * ()
   {
      return *p;
   }

   // prefix increment
   iterator & operator ++ ()
   {
      p++;
      return *this;
   }


   // postfix increment
   iterator operator++(int postfix)
   {
      iterator tmp(*this);
      p++;
      return tmp;
   }

   private:

   T * p;

};

/*******************************************
* CONTAINER :: COPY CONSTRUCTOR
*******************************************/
template <class T>
vector <T> ::vector(const vector <T> & rhs) throw (const char *)
{
   assert(rhs.numCapacity >= 0);

   // do nothing if there is nothing to do
   if (rhs.numCapacity == 0)
   {
      numCapacity = num = 0;
      data = 0x00000000;
      return;
   }

   // attempt to allocate
   try
   {
      data = new T[rhs.numCapacity];
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: Unable to allocate a new buffer for vector";
   }

   // copy over the stuff
   assert(rhs.num >= 0 && rhs.num <= rhs.numCapacity);
   numCapacity = rhs.numCapacity;
   num = rhs.num;

   for (int i = 0; i < num; i++)
      data[i] = rhs.data[i];

}

/**********************************************
* CONTAINER : NON-DEFAULT CONSTRUCTOR
* Preallocate the container to "capacity"
**********************************************/
template <class T>
vector <T> :: vector(int numCapacity) throw (const char *)
{
   assert(numCapacity >= 0);
   // do nothing if there is nothing to do
   
   if (numCapacity == 0)
   {
      this->numCapacity = this->num = 0;
      this->data = 0x00000000;
      return;
   }

   // attempt to allocate
   try
   {
      data = new T[numCapacity];
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: Unable to allocate a new buffer for vector";
   }

   // copy over the stuff
   this->numCapacity = numCapacity;
   this->num = numCapacity;

}

/***************************************************
* CONTAINER :: INSERT
* Insert an item on the end of the container
**************************************************/
template <class T>
void vector <T> :: insert(const T & t) throw (const char *)
{
   // do we have space?
   if (numCapacity == 0 || numCapacity == num)
      throw "ERROR: Insufficient space";

   // add an item to the end
   data[num++] = t;
   
}

/*****************************************************
 * PUSH BACK
 * Extends the size of the vector if necessary, 
 * before inserting item
 ****************************************************/
template <class T>
void vector <T> :: push_back(const T & t) throw (const char *)
{
   T* newData;

   if (num >= numCapacity)
   {

      if (numCapacity == 0)
      {
         numCapacity = 1;
      }

      else
      {
         numCapacity *= 2;
      }

      newData = new T[numCapacity];

      for (int idx = 0; idx < num; ++idx)
      {
         newData[idx] = data[idx];
      }

      delete[] data;

      data = newData;

   }
   
   insert(t);

}

/********************************************
 * vector : DISPLAY
 * A debug utility to display the contents of the vector
 *******************************************/
template <class T>
void vector <T> :: display() const
{
   std::cerr << "vector<T>::display()\n";
   std::cerr << "\tnum = " << num << "\n";
   for (int i = 0; i < num; i++)
      std::cerr << "\tdata[" << i << "] = " << data[i] << "\n";
}


/*******************************************
 * vector :: Assignment Operator
 *******************************************/
template <class T>
vector <T> & vector <T> :: operator = (const vector <T> & rhs)
          throw (const char *)
{
   num = rhs.num;
   
   for (int i = 0; i < numCapacity; i++)
      data[i] = rhs.data[i];

   return *this;
}


}; // namespace custom


#endif // vector_H








