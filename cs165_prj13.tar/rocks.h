/***********************************************************************
* Header File:
*    Rocks : The representation of asteroids
* Author:
*    Milton Nogueira Brando Neto
* Summary:
*    Everything we need to know about asteroids.
************************************************************************/

#ifndef rocks_h
#define rocks_h

#define BIG_ROCK_SIZE 16
#define MEDIUM_ROCK_SIZE 8
#define SMALL_ROCK_SIZE 4

#define BIG_ROCK_SPIN 2
#define MEDIUM_ROCK_SPIN 5
#define SMALL_ROCK_SPIN 10


#include "uiDraw.h"
#include "flyingObject.h"
#include <vector>


class Rocks : public FlyingObject
{
public:

	Rocks() {};

	Rocks(Point point) { setPoint(point); }

	virtual int hit(std::vector<Rocks*> & rocks) = 0;

	virtual int getRadius() = 0;

	virtual void setRadius(int radius) = 0;


protected:

	int rotate;


};



//   BigRock

class BigRock : public Rocks
{
public:

	BigRock();

	BigRock(Point point);

	virtual int hit(std::vector<Rocks*> & rocks);

	virtual void draw();

	virtual int getRadius() { return radius; }

	virtual void setRadius(int radius) { this->radius = radius; }



private:

	int radius;


};


//   MediumRock
class MediumRock : public Rocks
{
public:

	MediumRock();

	MediumRock(Point point, Velocity velocity, int order);

	virtual int hit(std::vector<Rocks*> & rocks);

	virtual void draw();

	virtual int getRadius() { return radius; }

	virtual void setRadius(int radius) { this->radius = radius; }

	int getOrder() { return order; }

	void setOrder(int order) { this->order = order; }


private:

	int radius;

	int order;

};


//   SmallRock
class SmallRock : public Rocks
{
public:

	SmallRock();

	SmallRock(Point point, Velocity velocity);

	virtual int hit(std::vector<Rocks*> & rocks);

	virtual void draw();

	virtual int getRadius() { return radius; }

	virtual void setRadius(int radius) { this->radius = radius; }


private:

	int radius;

};


//   DeathStar
class DeathStar : public Rocks
{
public:

	DeathStar();

	DeathStar(Point point);

	virtual int hit(std::vector<Rocks*> & rocks);

	virtual void draw();

	virtual int getRadius() { return radius; }

	virtual void setRadius(int radius) { this->radius = radius; }


private:

	int radius;

};



#endif /* rocks_h */
