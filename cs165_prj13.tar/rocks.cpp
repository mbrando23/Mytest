/*****************************************************
* File: rocks.cpp
* Author: Br. Milton Nogueira Brando Neto
*
* Description: This file contains the methods for rocks.
******************************************************/


#include "rocks.h"
#include <cmath> // used for sin, cos, and M_PI

# define M_PI  3.14159265358979323846 /* pi */

// Put your Rock methods here


/*********************************************
* BIG Default Constructor
*********************************************/
BigRock::BigRock()
{
	setRadius(BIG_ROCK_SIZE);
	
	float y = random(-200, 200);
	float x = random(-200, 200);
	point.setY(y);
	point.setX(x);

	float dx = (-sin(M_PI / 180.0 * (random(0, 360))));
	float dy = (cos(M_PI / 180.0 * (random(0, 360))));

	//float dx = random(-1.0, 1.0);
	//float dy = random(-1.0, 1.0);

	if (dx > dy && dx > 0)
		dx = 1;
	if (dx > dy && dx < 0)
		dy = -1;
	if (dy > dx && dy > 0)
		dy = 1;
	if (dy > dx && dy < 0)
		dx = -1;


	//std::cout << dx << std::endl << dy << std::endl;

	velocity.setDx(dx);
	velocity.setDy(dy);	
}


/*********************************************
* BIG Non Default Constructor
*********************************************/
BigRock::BigRock(Point point)
{
	setPoint(point);
	setRadius(BIG_ROCK_SIZE);
}


/*********************************************
* MEDIUM Default Constructor
*********************************************/
MediumRock::MediumRock()
{
	setRadius(MEDIUM_ROCK_SIZE);

	float y = random(-200, 200);
	float x = random(-200, 200);
	point.setY(y);
	point.setX(x);
	
	velocity.setDy(random(-1.0, 1.0));
	velocity.setDx(random(-1.0, 1.0));
	if (velocity.getDy() == 0.0)
		velocity.setDy(1.0);
	if (velocity.getDx() == 0.0)
		velocity.setDx(1.0);
}


/*********************************************
* MEDIUM Non Default Constructor
*********************************************/
MediumRock::MediumRock(Point point, Velocity velocity, int order)
{
	setPoint(point);
	setVelocity(velocity);
	setRadius(MEDIUM_ROCK_SIZE);
	setOrder(order);
}



/*********************************************
* SMALL Default Constructor
*********************************************/
SmallRock::SmallRock()
{
	setRadius(SMALL_ROCK_SIZE);
	
	float y = random(-200, 200);
	float x = random(-200, 200);
	point.setY(y);
	point.setX(x);

	velocity.setDy(random(-1.0, 1.0));
	velocity.setDx(random(-1.0, 1.0));
	if (velocity.getDy() == 0.0)
		velocity.setDy(1.0);
	if (velocity.getDx() == 0.0)
		velocity.setDx(1.0);
}


/*********************************************
* SMALL Non Default Constructor
*********************************************/
SmallRock::SmallRock(Point point, Velocity velocity)
{
	setPoint(point);
	setVelocity(velocity);
	setRadius(SMALL_ROCK_SIZE);
}


/*********************************************
* DEATHSTAR Default Constructor
*********************************************/
DeathStar::DeathStar()
{
	setRadius(BIG_ROCK_SIZE);

	float y = random(-200, 200);
	float x = random(-200, 200);
	point.setY(y);
	point.setX(x);

	float dx = (-sin(M_PI / 180.0 * (random(0, 360))));
	float dy = (cos(M_PI / 180.0 * (random(0, 360))));

	//float dx = random(-1.0, 1.0);
	//float dy = random(-1.0, 1.0);

	if (dx > dy && dx > 0)
		dx = 1;
	if (dx > dy && dx < 0)
		dy = -1;
	if (dy > dx && dy > 0)
		dy = 1;
	if (dy > dx && dy < 0)
		dx = -1;


	//std::cout << dx << std::endl << dy << std::endl;

	velocity.setDx(dx);
	velocity.setDy(dy);
}


/*********************************************
* DEATHSTAR Non Default Constructor
*********************************************/
DeathStar::DeathStar(Point point)
{
	setPoint(point);
}



///////////////////////////////////////
// BIG OTHERS: HIT AND DRAW
///////////////////////////////////////


/********************************************
BIG :: HIT
********************************************/
int BigRock::hit(std::vector<Rocks*> & rocks)
{
	setAlive(false);

	Rocks * pRock = NULL;
	Velocity velocityFirst;
	Velocity velocitySecond;

	velocityFirst.setDx(velocity.getDx());
	velocityFirst.setDy(velocity.getDy() + 1);
	pRock = new MediumRock(getPoint(), velocityFirst, 1);
	rocks.push_back(pRock);

	velocitySecond.setDx(velocity.getDx());
	velocitySecond.setDy(velocity.getDy() - 1);
	pRock = new MediumRock(getPoint(), velocitySecond, 2);
	rocks.push_back(pRock);
	
	Velocity velocitySmall;
	velocitySmall.setDx(velocity.getDx() + 2);
	velocitySmall.setDy(velocity.getDy());
	pRock = new SmallRock(getPoint(), velocitySmall);
	rocks.push_back(pRock);


	return 5;
}


/********************************************
BIG :: DRAW
********************************************/
void BigRock::draw()
{
	drawLargeAsteroid(point, rotate += BIG_ROCK_SPIN);
}


///////////////////////////////////////
// MEDIUM OTHERS: HIT AND DRAW
///////////////////////////////////////

/********************************************
MEDIUM :: HIT
********************************************/
int MediumRock::hit(std::vector<Rocks*> & rocks)
{
	
	setAlive(false);

	Rocks * pRock = NULL;

	Velocity velocitySmallOne;
	Velocity velocitySmallTwo;

	if (getOrder() == 1)
	{
		velocitySmallOne.setDx(velocity.getDx() + 3);
		velocitySmallOne.setDy(velocity.getDy());
		pRock = new SmallRock(getPoint(), velocitySmallOne);
		rocks.push_back(pRock);

		velocitySmallTwo.setDx(velocity.getDx() - 3);
		velocitySmallTwo.setDy(velocity.getDy());
		pRock = new SmallRock(getPoint(), velocitySmallTwo);
		rocks.push_back(pRock);
	}
	else
	{
		velocitySmallOne.setDx(velocity.getDx() + 3);
		velocitySmallOne.setDy(velocity.getDy());
		pRock = new SmallRock(getPoint(), velocitySmallOne);
		rocks.push_back(pRock);

		velocitySmallTwo.setDx(velocity.getDx() - 3);
		velocitySmallTwo.setDy(velocity.getDy());
		pRock = new SmallRock(getPoint(), velocitySmallTwo);
		rocks.push_back(pRock);
	}
	
	return 3;
}


/********************************************
MEDIUM :: DRAW
********************************************/
void MediumRock::draw()
{
	drawMediumAsteroid(point, rotate += MEDIUM_ROCK_SPIN);
}



///////////////////////////////////////
// SMALL OTHERS: HIT AND DRAW
///////////////////////////////////////

/********************************************
SMALL :: HIT
********************************************/
int SmallRock::hit(std::vector<Rocks*> & rocks)
{
	setAlive(false);
	return 1;
}

/********************************************
SMALL :: DRAW
********************************************/
void SmallRock::draw()
{
	drawSmallAsteroid(point, rotate += SMALL_ROCK_SPIN);
}


///////////////////////////////////////
// DEATHSTAR OTHERS: HIT AND DRAW
///////////////////////////////////////

/********************************************
DEATHSTAR :: HIT
********************************************/
int DeathStar::hit(std::vector<Rocks*> & rocks)
{
	setAlive(true);
	return 1;
}

/********************************************
DEATHSTAR :: DRAW
********************************************/
void DeathStar::draw()
{
	drawCircle(point, 40);
	Point other;
	other.setX(point.getX() + 15);
	other.setY(point.getY() + 20);
	drawCircle(other, 10);
	Point lineStart;
	lineStart.setX(point.getX() - 40);
	lineStart.setY(point.getY());
	Point lineEnd;
	lineEnd.setX(point.getX() + 40);
	lineEnd.setY(point.getY());
	drawLine(lineStart, lineEnd);
}


