/*****************************************************
* File: Stars.cpp
* Author: Br. Milton Nogueira Brando Neto
*
* Description: This file contains the methods for bullets.
******************************************************/

// Put your stars methods here


#include "stars.h"


/*********************************************
* Constructors
*********************************************/
Stars::Stars()
{
	star.setX(random(-200, 200));
	star.setY(random(-200, 200));
}

/*********************************************
* Constructors
*********************************************/
Stars::Stars(Point star)
{
	setStars(star);
}




/********************************************
BULLETS :: DRAW
set velocity for a flying object
********************************************/
void Stars::draw()
{
	drawStars(star);
}






