/***********************************************************************
* Header File:
*    Bullet : The representation of a bullet
* Author:
*    Milton Nogueira Brando Neto
* Summary:
*    Everything we need to know about firing into the game.
************************************************************************/


#ifndef bullet_h
#define bullet_h

#define BULLET_SPEED 5
#define SHOTGUN_SPEED 5
#define BULLET_LIFE 40


#include "flyingObject.h"
#include <vector>


// Put your Bullet class here

class Bullet : public FlyingObject
{
public:

	Bullet();

	Bullet(Point point);

	virtual void draw();

	void fire(Point point, float angle);

	void shotGun(Point point, float angle, std::vector<Bullet>& bullets);


private:



};




#endif /* bullet_h */
