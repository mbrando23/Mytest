/***********************************************************************
 * Header File:
 *    VELOCITY : A class for velocity
 * Author:
 *    Br. Milton Nogueira B Neto
 * Summary:
 *    Everything you need to know about speed.
 ************************************************************************/

#ifndef VELOCITY_H
#define VELOCITY_H


class Velocity
{
   private:

      float dX;                      // horizontal inertia 

      float dY;                      // vertical inertia

   public:

      Velocity();                    // defaul constructor

      Velocity(float dX, float dY);  // non-default constructor

      float getDx() const;           // return horizontal velocity

      float getDy() const;           // return vertical velocity

      void setDx(float dX);          // set horizontal velocity

      void setDy(float dY);          // set vertical velocity

};


#endif

