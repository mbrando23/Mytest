/*********************************************************************
 * File: game.cpp
 * Description: Contains the implementation of the game class methods.
 *
 *********************************************************************/

#include <algorithm>
 
// needed for the getClosestDistance function...
#include <limits>

#include "game.h"
#include "uiDraw.h"
#include "uiInteract.h"
#include "point.h"

#include <vector>

#define DEATH_STAR 50

using namespace std;


/***************************************
* GAME CONSTRUCTOR
***************************************/
Game::Game(Point tl, Point br)
	: topLeft(tl), bottomRight(br)
{
	// Set up the initial conditions of the game
	score = 0;
	control = 0;
	timer = 0;
	second = 0;
	createRocks();
	topRight = Point(300, 300);
}

/****************************************
* GAME DESTRUCTOR
****************************************/
Game :: ~Game()
{
	// TODO: Check to see if there is currently a rock allocated
	//       and if so, delete it.
	vector<Rocks*>::iterator it = rock.begin();
	while (it != rock.end())
	{
		it = rock.erase(it);
	}
	
}


/**************************************************************************
* GAME :: CREATE ROCKS
* Create a rock of a random type according to the rules of the game.
**************************************************************************/
void Game::createRocks()
{
	Rocks * pRock = NULL;
	for (int i = 0; i < 5; i++)
	{
		pRock = new BigRock;
		rock.push_back(pRock);
	}


	// create the stars
	Point pointStar;

	for (int i = 0; i < 30; i++)
	{
		pointStar.setX(random(-300, 300));
		pointStar.setY(random(-300, 300));
		Stars newStar(pointStar);
		stars.push_back(newStar);
	}

}


/***************************************
* GAME :: ADVANCE
* advance the game one unit of time
***************************************/
void Game::advance()
{
	advanceShip();
	advanceBullets();
	advanceRock();
	second++;
	handleCollisions();
	cleanUpZombies();

	// this advances the timer by less than the frame rate
	if (second % 40 == 0)
	   timer++;
	
	// this kills the ship after 1 minute
	if (timer == 60)
		ship.kill();
}

/***************************************
* GAME :: ADVANCE SHIP
* Go through ship and advance it.
***************************************/
void Game::advanceShip()
{
	if (ship.isAlive())
	{
		// this ship is alive, so tell it to move forward
		ship.advance();
	}
}
/***************************************
* GAME :: ADVANCE BULLETS
* Go through each bullet and advance it.
***************************************/
void Game::advanceBullets()
{
	// Move each of the bullets forward if it is alive
	for (int i = 0; i < bullets.size(); i++)
	{
		if (bullets[i].isAlive())
		{
			// this bullet is alive, so tell it to move forward
			bullets[i].advance();

			if (bullets[i].getHealth() == 0)
			{
				// the bullet has left the screen
				bullets[i].kill();
			}

		}
	}
}


/**************************************************************************
* GAME :: ADVANCE ROCK
*
* 1. If there is no rock, create one with some probability
* 2. If there is a rock, and it's alive, advance it
**************************************************************************/
void Game::advanceRock()
{
	for (vector<Rocks*>::iterator it = rock.begin(); it != rock.end(); it++)
	{
		if ((*it)->isAlive())
		{
			// this rock is alive, so tell it to move forward
			(*it)->advance();
		}
	}
}



/**************************************************************************
* GAME :: HANDLE COLLISIONS
* Check for a collision between a rock and a bullet.
**************************************************************************/
void Game::handleCollisions()
{
	
	std::vector<Rocks*> newRock;
	
	vector<Rocks*>::iterator it = rock.begin();
	
	int points = 0;

	for (vector<Rocks*>::iterator it = rock.begin(); it != rock.end(); it++)
	{
		if ((*it) != NULL && (*it)->getRadius() == BIG_ROCK_SIZE)
		{
			if (ship.isAlive() && getClosestDistance(ship, *(*it)) <= BIG_ROCK_SIZE)
			{
				// hit the rock
				(*it)->hit(newRock);

				// the ship is dead as well
				ship.kill();
			}
		}
		else
			if (ship.isAlive() && getClosestDistance(ship, *(*it)) <= CLOSE_ENOUGH)
			{
				// hit the rock
				(*it)->hit(newRock);

				// the ship is dead as well
				ship.kill();
			}
	}


	  // now check for a hit (if it is close enough to any live bullets)
	for (int i = 0; i < bullets.size(); i++)
	{
		if (bullets[i].isAlive())
		{
			// this bullet is alive, see if its too close
			for (vector<Rocks*>::iterator it = rock.begin(); it != rock.end(); it++)
			{
				if ((*it) != NULL && (*it)->getRadius() == BIG_ROCK_SIZE)
				{
					// BTW, this logic could be more sophisiticated, but this will
					// get the job done for now...
					if (getClosestDistance(bullets[i], *(*it)) <= BIG_ROCK_SIZE)
					{
						// the bullet is dead as well
						bullets[i].kill();
						
						// hit the rock
						points = (*it)->hit(newRock);
						score += points;
					}
				}
				if ((*it) != NULL && (*it)->getRadius() == MEDIUM_ROCK_SIZE)
				{
					int points = 0;
					// BTW, this logic could be more sophisiticated, but this will
					// get the job done for now...
					if (getClosestDistance(bullets[i], *(*it)) <= MEDIUM_ROCK_SIZE)
					{
						// the bullet is dead as well
						bullets[i].kill();
						
						// hit the rock
						points = (*it)->hit(newRock);
						score += points;
					}
				}

				if ((*it) != NULL && (*it)->getRadius() == SMALL_ROCK_SIZE)
				{

					// BTW, this logic could be more sophisiticated, but this will
					// get the job done for now...
					if (getClosestDistance(bullets[i], *(*it)) <= SMALL_ROCK_SIZE)
					{
						// the bullet is dead as well
						bullets[i].kill();
						
						// hit the rock
						points = (*it)->hit(newRock);
						score += points;
					}
				}

			}
		}
	}

	rock.insert(rock.end(), newRock.begin(), newRock.end());


}



/***************************************
* GAME :: HANDLE INPUT
* accept input from the user
***************************************/
void Game::handleInput(const Interface & ui)
{
	// Change the direction of the ship
	if (ui.isLeft())
	{
		ship.rotateLeft();
	}

	if (ui.isRight())
	{
		ship.rotateRight();
	}


	// Check for "Normal Gun"
	if (ui.isSpace() && ship.isAlive())
	{
		Bullet newBullet;
		newBullet.fire(ship.getPoint(), ship.getAngle());

		bullets.push_back(newBullet);
	}

	
	// Check for restart
	if (ui.isR() && !ship.isAlive())
	{
	
		vector<Rocks*>::iterator it = rock.begin();

		while (it != rock.end())
		{
			if ((*it)->isAlive())
			{
				Rocks* pRock = *it;
				delete pRock;

				pRock = NULL;

				it = rock.erase(it);
			}
			else
			{
				it++; // advance
			}
		}
		
		Rocks * pRock = NULL;
		for (int i = 0; i < 5; i++)
		{
			pRock = new BigRock;
			rock.push_back(pRock);
		}
		
		ship.setAlive(true);
		score = 0;
		control = 0;
		timer = 0;

		Velocity velocityRestart;
		velocityRestart.setDx(0);
		velocityRestart.setDy(0);

		Point pointRestart;
		pointRestart.setY(0);
		pointRestart.setX(0);

		ship.setPoint(pointRestart);
		ship.setVelocity(velocityRestart);

		advance();
		

	}

	// Check for backward thrust 
	if (ui.isDown() && ship.isAlive())
	{
		ship.moveBackward();
		Bullet newBullet;
		newBullet.shotGun(ship.getPoint(), ship.getAngle(), bullets);
		drawLanderFlames(ship.getPoint(), 1, 0, 0);
	}
	else
	{
	
	}

	// Check for thrust
	if (ui.isUp() && ship.isAlive())
	{
		ship.moveForward();
	}
	else
	{
		ship.setThrust(false);
	}


}

/*********************************************
* GAME :: DRAW
* Draw everything on the screen
*********************************************/
void Game::draw(const Interface & ui)
{
	// draw the rocks
	for (vector<Rocks*>::iterator it = rock.begin(); it != rock.end(); it++)
	{
		if ((*it)->isAlive())
		{
			// create the DeathStar
			if (score >= DEATH_STAR && control == 0)
			{
				Rocks * pDeath = NULL;
				pDeath = new DeathStar;
				rock.push_back(pDeath);
				control += 1;
			}

			// then call it's draw method
			(*it)->draw();
		}
	}

	
	

	// draw the bullets, if they are alive
	for (int i = 0; i < bullets.size(); i++)
	{
		if (bullets[i].isAlive())
		{
			bullets[i].draw();

		}
	}


	
	if (ship.isAlive())
	{
		// draw the ship
		ship.draw();

		// Put the score on the screen
		Point scoreLocation;
		scoreLocation.setX(topLeft.getX() + 5);
		scoreLocation.setY(topLeft.getY() - 5);

		drawNumber(scoreLocation, score);

		Point timerLocation;
		timerLocation.setX(topRight.getX() - 30);
		timerLocation.setY(topRight.getY() - 5);

		drawNumber(timerLocation, timer);


		// draw the stars
		for (int i = 0; i < stars.size(); i++)
		{
			stars[i].draw();
		}

	}


	// draw the ship
	if (!ship.isAlive())
	{
		Point gameOver;
		gameOver.setX(-85);
		gameOver.setY(55);

		drawText(gameOver, "Game Over: hit 'r' to play again");

		Point points;
		points.setX(-35);
		points.setY(0);

		drawText(points, "Final points:");

		Point scoreLocation;
		scoreLocation.setX(45);
		scoreLocation.setY(9);

		drawNumber(scoreLocation, score);
	}


}

/**************************************************************************
* GAME :: CLEAN UP ZOMBIES
* Remove any dead objects
**************************************************************************/
void Game::cleanUpZombies()
{
	// Look for dead bullets
	vector<Bullet>::iterator bulletIt = bullets.begin();

	while (bulletIt != bullets.end())
	{
	   Bullet bullet = *bulletIt;
	   // Asteroids Hint:
	   // If we had a list of pointers, we would need this line instead:
	   //Bullet* pBullet = *bulletIt;

	   if (!bullet.isAlive())
	   {
	      // If we had a list of pointers, we would need to delete the memory here...
	      // remove from list and advance
		   bulletIt = bullets.erase(bulletIt);
	   }
	   else
	   {
	      bulletIt++; // advance
	   }
	}

	// Look for dead rocks
	vector<Rocks*>::iterator it = rock.begin();

	while (it != rock.end())
	{
		if (!(*it)->isAlive())
		{
			Rocks* pRock = *it;
			delete pRock;

			pRock = NULL;

			it = rock.erase(it);
		}
		else
		{
			it++; // advance
		}
	}

	if (rock.size() == 0)
	{
		ship.setAlive(false);
	}
}


/**********************************************************
 * Function: getClosestDistance
 * Description: Determine how close these two objects will
 *   get in between the frames.
 **********************************************************/

float Game :: getClosestDistance(const FlyingObject &obj1, const FlyingObject &obj2) const
{
   // find the maximum distance traveled
   float dMax = max(abs(obj1.getVelocity().getDx()), abs(obj1.getVelocity().getDy()));
   dMax = max(dMax, abs(obj2.getVelocity().getDx()));
   dMax = max(dMax, abs(obj2.getVelocity().getDy()));
   dMax = max(dMax, 0.1f); // when dx and dy are 0.0. Go through the loop once.
   
   float distMin = std::numeric_limits<float>::max();
   for (float i = 0.0; i <= dMax; i++)
   {
      Point point1(obj1.getPoint().getX() + (obj1.getVelocity().getDx() * i / dMax),
                     obj1.getPoint().getY() + (obj1.getVelocity().getDy() * i / dMax));
      Point point2(obj2.getPoint().getX() + (obj2.getVelocity().getDx() * i / dMax),
                     obj2.getPoint().getY() + (obj2.getVelocity().getDy() * i / dMax));
      
      float xDiff = point1.getX() - point2.getX();
      float yDiff = point1.getY() - point2.getY();
      
      float distSquared = (xDiff * xDiff) +(yDiff * yDiff);
      
      distMin = min(distMin, distSquared);
   }
   
   return sqrt(distMin);
}


