/***********************************************************************
* Header File:
*    Stars : The representation of stars
* Author:
*    Milton Nogueira Brando Neto
* Summary:
*    Everything we need to know about firing into the game.
************************************************************************/


#ifndef stars_h
#define stars_h


#include <vector>
#include "point.h"
#include "uiDraw.h"
#include "flyingObject.h"

// Put your Bullet class here

class Stars : public FlyingObject
{
public:

	Stars();

	Stars(Point star);

	virtual void draw();


private:


};




#endif /* stars_h */
#pragma once
