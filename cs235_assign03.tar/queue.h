/***********************************************************************
* Header:
*    queue.h
* Summary:
*    This file is a Template class that implements a queue and behaves 
*    as the std::queue class
* Author
*     Orbezuza Luis
*     Amorim Luiciano
*     Brando Milton
*     Isaac Sanchez
************************************************************************/

#ifndef QUEUE_H
#define QUEUE_H

#include <iostream>

namespace custom
{
	/*************************************************************
	* Queue
	* a class encapsulating the notion of a array-based circular
	* queue as described in the textbook.
	*************************************************************/
	template <class T>
	class queue
	{

		
		friend std::ostream & operator << (std::ostream & out, queue & rhs)
		{
			int index;
			out << "{ ";
			//out << "ipop:" << rhs.numPop << " " << "ipush:" << rhs.numPush << " ::: ";
			for (int i = rhs.numPop; i<rhs.numPush; i++)
			{
				index = i % rhs.capacity;

				out
					//<< "(" << index << "):"
					<< rhs.array[index];
				//. if (i<rhs.numPush-1)
				out << " ";
			}
			out << "}";
			//out << std::endl;
			return out;
		}
		


	public:
		//DEF Constructor
		queue();
		//Non-DEF Constructor
		queue(int capacity) throw (const char *);
		//Copy Constructor
		queue(const queue& rhs) throw (const char *);
		// Destructor
		virtual ~queue();
		// Assignment Op
		queue& operator=(const queue& rhs) throw (const char *);

		int size() const;
		void clear();
		bool empty() const;

		////////NEW METHODS////////
		void push(const T & element) throw(const char *);
		void pop() throw(const char *);
		// GET and SET Front
		T & front() throw (const char *);
		T front() const throw (const char *);
		// GET and SET Back
		T & back() throw(const char *);
		T back() const throw(const char *);
		//////////////////////////
	private:
		T* array;
		int capacity;
		int numPush;
		int numPop;

		void resize(int newCapacity = 0) throw(const char*);
		int iHead();
		int iTail();
	};

	/*************************************************************
	* Queue Destructor
	* when called the class should delete all the allocated memory.
    *************************************************************/
	template <class T>
	queue<T>::~queue()
	{
		if (this->array != NULL)
		{
			delete[] this->array;
			this->array = NULL;
		}
		this->capacity = 0;
		this->numPush = 0;
		this->numPop = 0;
	}

	/*************************************************************
	* Queue Def Constructor
	*  Sets everything to 0
	*************************************************************/
	template <class T>
	queue<T>::queue()
		: array(NULL), capacity(0), numPush(0), numPop(0){}

	/*************************************************************
	* Queue non Def constructor
	*  non-default constructor (taking a capacity value as a parameter)
	*  If allocation is not possible, the following error will be thrown:
    *   ERROR: Unable to allocate a new buffer for queue
	*************************************************************/
	template <class T>     
	queue<T>::queue(int newCapacity) throw (const char *)
		: array(NULL), capacity(0), numPush(0), numPop(0)
	{
		resize(newCapacity);
	}

	/*************************************************************
	* Queue Copy Constructor
	* Sets still everything to zero but sets the rhs to this
	* to get space for the queue
	*************************************************************/
	template <class T>
	queue<T>::queue(const queue& rhs) throw (const char *)
		: array(NULL), capacity(0), numPush(0), numPop(0)
	{
		(*this) = rhs;
	}


	/*************************************************************
	* Queue Assignment operator =
	* takes a queue as a parameter and copies all the elements to this.
	* If the current buffer size is sufficient, not allocation is made.
	* If the current buffer size is not sufficient, enough space is
	* allocated to accomodate the new data.
	* resize() will handle the allocation
	*************************************************************/
	template <class T>
	queue<T>& queue<T>::operator=(const queue<T>& rhs)  throw (const char *)
	{
		this->numPush = this->numPop = 0;
		if (this->capacity < rhs.size())
		{
			resize(rhs.size());
		}
		for (int i = rhs.numPop; i<rhs.numPush; i++)
		{
			int index;
			index = i % rhs.capacity;
			push(rhs.array[index]);
		}

		return (*this);
	}

	/*************************************************************
	* Queue Size
	* Return the queue size. This method takes no parameters 
	* and returns an integer value.
	*************************************************************/
	template <class T>
	int queue<T>::size() const
	{
		return (this->numPush - this->numPop); // page 83
	}

	/*************************************************************
	* Queue Clear
	* Empties the queue of all elements. There are no parameters
	* and no return value.
	*************************************************************/
	template <class T>
	void queue<T>::clear()
	{
		this->numPush = 0;
		this->numPop = 0;
	}

	/*************************************************************
	* Queue Empty
	* Test whether the queue is empty. This method takes no 
	* parameters and returns a Boolean value.
	*************************************************************/
	template <class T>
	bool queue<T>::empty() const
	{
		return (size() == 0);
	}

	/*************************************************************
	* Queue Push
	* Adds an element to the queue. This method takes a single parameter
	* "element" to be added to the end of the queue and has no 
	* return value. Note that if the queue is full, then the 
	* capacity will be doubled. In the case of an allocation error
	* resize() will handle the allocation error message
	*************************************************************/
	template <class T>
	void queue<T>::push(const T& element) throw (const char *)
	{
		int tail;

		if (this->size() == this->capacity)
		{
			resize(this->capacity * 2);
		}
		this->numPush++;
		tail = this->iTail();
		this->array[tail] = element;
	}

	/*************************************************************
	* Queue Pop
	* Removes an element from the head of the queue, serving to 
	* reduce the size by one. Note that if the queue is already 
	* empty, the queue remains unchanged.
	************************************************************/
	template <class T>
	void queue<T>::pop() throw(const char *)
	{
		if (empty() == false)
		{
			this->numPop++;
		}
	}


	/*************************************************************
	* Queue Front Get and Set
	* Returns the element currently at the front of the queue.
	* There are two versions of this method: one that returns the 
	* element by-reference so the element can be changed through
	* the front() method. The second version returns the element
	* by-value or const by-reference so this is not changed.
	* If the queue is currently empty, the following exception 
	* will be thrown:
	* ERROR: attempting to access an element in an empty queue
	*************************************************************/
	template <class T>
	T & queue<T>::front() throw (const char *)
	{
		int headIndex;
		if (this->empty() == true)
		{
			throw "ERROR: attempting to access an element in an empty queue";
		}
		else
		{
			headIndex = this->iHead();
			return this->array[headIndex];
		}
	}

	template <class T>
	T queue<T>::front() const throw (const char *)
	{
		if (this->empty())
		{
			throw "ERROR: attempting to access an element in an empty queue";
		}
		else
		{
			return this->array[this->iHead()];
		}
	}


	/*************************************************************
	* Queue Back Get and Set
	* Returns the element currently at the back of the queue. 
	* There are two versions of this method: one that returns the 
	* element by-reference so the element can be changed through 
	* the back() method. The second version returns the element
	* by-value or const by-reference so this is not changed. 
	* If the queue is currently empty, the following exception
	* will be thrown:
	* ERROR: attempting to access an element in an empty queue
	*************************************************************/
	template <class T>
	T& queue<T>::back() throw (const char *)
	{
		if (this->empty())
		{
			throw ("ERROR: attempting to access an element in an empty queue");
		}
		else
		{
			return this->array[this->iTail()];
		}
	}

	template <class T>
	T queue<T>::back() const throw(const char *)
	{
		if (this->empty())
		{
			throw ("ERROR: attempting to access an element in an empty queue");
		}
		else
		{
			return this->array[this->iTail()];
		}
	}


	/*************************************************************
	* Resize
	* the Resize will mod the queue to grow to accommodate any amount 
	* of data. it will be used by Push, operator=, to handle the 
	* new sizes and errors
	*************************************************************/
	template <class T>
	void queue<T>::resize(int newCapacity) throw(const char*)
	{
		T* tempArray;
		int lastIndex;

		//assert(newCapacity >= 0);

		if (newCapacity == 0)
		{
			newCapacity = (this->capacity ? this->capacity * 2 : 1);
		}

		tempArray = new(std::nothrow) T[newCapacity];
		if (tempArray == NULL)
		{
			throw "ERROR: Unable to allocate a new buffer for queue";
		}

		lastIndex = 0;
		for (int i = this->numPop; i<this->numPush; i++)
		{
			tempArray[lastIndex] = this->array[i % this->capacity];
			lastIndex++;
		}

		if (this->array != NULL)
		{
			delete[] this->array;
		}

		this->capacity = newCapacity;
		this->numPop = 0;
		this->numPush = lastIndex;
		this->array = tempArray;
	}


	/*************************************************************
	* iHead
	* Will keep track of the head of the queue
	* check page 82
	*************************************************************/
	template <class T>
	int queue<T>::iHead()
	{
		return (this->numPop % this->capacity);
	}

	/*************************************************************
	* iTail
	* Will keep track of the tail of the queue
	* check page 82
	*************************************************************/
	template <class T>
	int queue<T>::iTail()
	{
		int result;

		result = (this->numPush - 1) % this->capacity;

		return result;
	}
};
#endif //QUEUE_H