#include "Transaction.h"

Transaction::Transaction(int in_shareCount, Dollars in_sharePrice, Dollars in_soldPrice)
{
	this->m_shareCount = in_shareCount;
	this->m_buyPrice = in_sharePrice;
	this->m_soldPrice = in_soldPrice;
	this->m_sold = in_soldPrice != 0;
}

// Gets the profit for this transaction
Dollars Transaction::getProfit() const
{
	return Dollars((this->m_soldPrice - this->m_buyPrice) * this->m_shareCount);
}

// Sells a subset of the shares, reducing the share count by the
// amount sold; returns the number of shares sold - in case
// a caller tries to sell more shares than available
Transaction Transaction::sellShares(int in_sellCount, Dollars in_salePrice)
{
	this->m_shareCount -= in_sellCount;
	return Transaction(in_sellCount, this->m_buyPrice, in_salePrice);
}

// Displays the transaction
void Transaction::display(std::ostream & out) const
{
	out << (*this);
}

std::ostream & operator << (std::ostream & out, const Transaction & rhs)
{
	if (rhs.m_sold == true)
	{
		out << "\tSell " << rhs.m_shareCount << " shares at " << rhs.m_soldPrice << " for a profit of " << rhs.getProfit() << std::endl;
	}
	else
	{
		out << "\tBought " << rhs.m_shareCount << " shares at " << rhs.m_buyPrice << std::endl;
	}


	return out;
}