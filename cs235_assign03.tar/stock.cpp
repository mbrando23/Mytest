#include <iostream>    // for ISTREAM, OSTREAM, CIN, and COUT
#include <string>      // for STRING
#include <cassert>     // for ASSERT
#include <sstream>
#include <iomanip>
#include "stock.h"     // for STOCK_TRANSACTION
#include "queue.h"     // for QUEUE
#include "Transaction.h"
using namespace std;
using namespace custom;

/************************************************
* STOCKS BUY SELL
* The interactive function allowing the user to
* buy and sell stocks
***********************************************/
void stocksBuySell()
{
	string order;
	int amount;
	Dollars price;
	Dollars proceeds;
	queue<Transaction> queueTransactions;

	cout.setf(ios::fixed | ios::showpoint);
	cout.precision(2);

	// instructions
	cout << "This program will allow you to buy and sell stocks. "
		<< "The actions are:\n";
	cout << "  buy 200 $1.57   - Buy 200 shares at $1.57\n";
	cout << "  sell 150 $2.15  - Sell 150 shares at $2.15\n";
	cout << "  display         - Display your current stock portfolio\n";
	cout << "  quit            - Display a final report and quit the program\n";

	bool isEnd = false;
	do
	{
		cout << "> ";
		cin.clear();
		cin.ignore();
		cin >> order;

		if (order == "quit")
		{
			isEnd = true;
		}
		else if (order == "buy")
		{
			cin >> amount >> price;

			Transaction t(amount, price, 0);
			queueTransactions.push(t);
		}
		else if (order == "sell")
		{
			cin >> amount >> price;

			Transaction b = queueTransactions.back();
			Transaction t = b.sellShares(amount, price);
			queueTransactions.push(t);
		}
		else if (order == "display")
		{
			if (queueTransactions.empty() == false)
			{
				queue<Transaction> temp(queueTransactions);

				cout << "Currently held:" << endl;
				while (queueTransactions.empty() == false)
				{
					cout << queueTransactions.front();
					queueTransactions.pop();
				}
			}
			cout << "Proceeds: " << proceeds << endl;
		}
		else
		{
			cout << "order unknown!\n";
		}

	} while (isEnd == false);
}