/***************************************************************
 * File: product.h
 * Author: Milton Nogueira Brando Neto
 * Summary:
 * This file gives a class for products in order to handle them.
 ***************************************************************/
#ifndef PRODUCT_H
#define PRODUCT_H
#include <iostream>                // input output
#include <string>                  // to use strings
using namespace std;               // standard use of libs

/**************************************************************
 * PRODUCT
 * Contains the definition of the Product class
 *************************************************************/
class Product
{
   private:
      string name;                 // stores product name 
      string description;          // stores product description
      float  weight;               // stores product weight
      float  price;                // stores product price
	   
   public:
      void  prompt();              // prompts for products features
      float getSaleTax();          // returns tax
      float getShippingCost();     // returns shipping cost
      float getTotalPrice();       // returns total cost
      void  displayAdvertising();  // display advertising mode
      void  displayInventory();    // display inventory mode
      void  displayReceipt();      // display receipt mode
};


#endif
