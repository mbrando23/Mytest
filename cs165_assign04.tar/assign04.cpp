/***************************************************************
 * File: assign04.cpp
 * Author: Milton Nogueira Brando Neto
 * Purpose: Contains the main function to use the Product class.
 ***************************************************************/

#include <iostream>                        // input output
#include <string>                          // to use strings
using namespace std;                       // standard use of libs

#include "product.h"                       // using class

/**********************************************************************
 * MAIN: a simple driver program for Product class.
 *********************************************************************/
int main()
{
   // Declare of Product object
   Product product;

   // Call of prompt function
   product.prompt();

   // Choose of the display mode
   cout << endl;
   cout << "Choose from the following options:\n";
   cout << "1 - Advertising profile\n";
   cout << "2 - Inventory line item\n";
   cout << "3 - Receipt\n";
   cout << endl;
   cout << "Enter the option that you would like displayed: ";
   
   // Give the display mode to the user
   int choice;
   cin >> choice;
   cout << endl;

   if (choice == 1)
   {
      // Call of display advertising profile function
      product.displayAdvertising();
   }
   else if (choice == 2)
   {
      // Call of display inventory line item function
      product.displayInventory();
   }
   else
   {
      // Call of display receipt function
      product.displayReceipt();
   }

   return 0;
}
