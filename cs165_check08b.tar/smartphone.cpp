/*******************
 * smartphone.cpp
 *******************/

#include "smartphone.h"



// TODO: Put your SmartPhone methods here

void SmartPhone :: prompt()
{
   phone.promptNumber();
   
   cout << "Email: ";
   cin  >> email;
}  

void SmartPhone :: display()
{
   phone.display();   // MUST BE DISPLAY
   
   cout << email
        << endl;
}


