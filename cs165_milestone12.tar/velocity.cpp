/***********************************************************************
 * Implementation File:
 *    VELOCITY : Created for speed control.
 * Author:
 *    Br. Milton Nogueira B. Neto
 * Summary:
 *    Accelerates or not and be careful with the speed.
 ************************************************************************/

#include "velocity.h"


///////////////////////////////////////
// CONSTRUCTORS
///////////////////////////////////////


/********************************************
VELOCITY :: CONSTRUCTOR
defaul constructor
********************************************/
Velocity::Velocity()
{
   setDx(0.0);
   setDy(0.0);
}


/********************************************
VELOCITY :: CONSTRUCTOR
non-default constructor
********************************************/
Velocity::Velocity(float dX, float dY)
{
   setDx(dX);
   setDy(dY);

}


///////////////////////////////////////
// GETTERS
///////////////////////////////////////

/*********************************************
VELOCITY :: GET DX
return horizontal velocity
*********************************************/
float Velocity :: getDx() const
{
   return dX;
}


/*********************************************
VELOCITY :: GET DY
return vertical velocity
*********************************************/
float Velocity :: getDy() const
{
   return dY;
}


///////////////////////////////////////
// SETTERS
///////////////////////////////////////

/*********************************************
VELOCITY :: SET DX
set horizontal velocity
*********************************************/
void Velocity::setDx(float dX)
{
   this->dX = dX;
}

/*********************************************
VELOCITY :: SET DY
set vertical velocity
*********************************************/
void Velocity::setDy(float dY)
{
   this->dY = dY;
}

