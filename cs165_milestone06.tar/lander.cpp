/***********************************************************************
* Implementation File:
*    LANDER : Representative of a craft lander.
* Author:
*    Br. Milton Nogueira B Neto
* Summary:
*    Everything about a lunar lander.
************************************************************************/

#include "lander.h"


/********************************************
LANDER :: CONSTRUCTOR
********************************************/
Lander::Lander()
{

   
}

/********************************************
LANDER :: GETPOINT

********************************************/
Point Lander::getPoint() const
{
	return point;
}

/********************************************
LANDER :: GETVELOCITY

********************************************/
Velocity Lander::getVelocity() const
{
	return velocity;
}

/********************************************
LANDER :: ISALIVE

********************************************/
bool Lander::isAlive()
{
	return true;
}

/********************************************
LANDER :: ISLANDED

********************************************/
bool Lander::isLanded()
{
	return false;
}

/********************************************
LANDER :: GETFUEL

********************************************/
int Lander::getFuel()
{

	return 500;
}

/********************************************
LANDER :: CANTHRUST

********************************************/
bool Lander::canThrust()
{

	return true;
}

/********************************************
LANDER :: SETLANDED

********************************************/
void Lander::setLanded(bool)
{


}

/********************************************
LANDER :: SETALIVE

********************************************/
void Lander::setAlive(bool)
{


}

/********************************************
LANDER :: SETFUEL

********************************************/
void Lander::setFuel(int)
{


}

/********************************************
LANDER :: APPLYGRAVITY

********************************************/
void Lander::applyGravity(float)
{


}

/********************************************
LANDER :: APPLYTHRUSTLEFT

********************************************/
void Lander::applyThrustLeft()
{


}

/********************************************
LANDER :: APPLYTHRUSTRIGHT

********************************************/
void Lander::applyThrustRight()
{


}

/********************************************
LANDER :: APPLYTHRUSTBOTTOM

********************************************/
void Lander::applyThrustBottom()
{


}

/********************************************
LANDER :: ADVANCE

********************************************/
void Lander::advance()
{


}

/********************************************
LANDER :: DRAW
For the Lander class to draw it on the screen.
********************************************/
void Lander::draw()
{
	drawLander(point);

}
