/***********************************************************************
* Header File:
*    LANDER : A class representing the lunar craft.
* Author:
*    Br. Milton Nogueira B Neto
* Summary:
*    Everything about a lunar lander.
************************************************************************/

#ifndef LANDER_H
#define LANDER_H

#include "point.h"
#include "velocity.h"
#include "uiDraw.h"

/********************************************
* LANDER
* So easy for an astronaut
********************************************/

class Lander
{
private:
	// it needs a place
	Point point;
	
	// it has inertia
	Velocity velocity;

public:

	Lander();

	Point getPoint() const;

	Velocity getVelocity() const;

	bool isAlive();

	bool isLanded();

	int getFuel();

	bool canThrust();

	void setLanded(bool);

	void setAlive(bool);

	void setFuel(int);

	void applyGravity(float);

	void applyThrustLeft();

	void applyThrustRight();

	void applyThrustBottom();

	void advance();

	void draw();

};

#endif
