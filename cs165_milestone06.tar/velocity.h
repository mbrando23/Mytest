/***********************************************************************
* Header File:
*    VELOCITY : A class for lander velocity
* Author:
*    Br. Milton Nogueira B Neto
* Summary:
*    Putting the craft on the road.
************************************************************************/

#ifndef VELOCITY_H
#define VELOCITY_H


/********************************************
* LANDER
* So easy for an astronaut
********************************************/
class Velocity
{
private:


public:

	Velocity();

	Velocity(float, float);

	float getDx();

	float getDy();

	void setDx(float);

	void setDy(float);

};


#endif

