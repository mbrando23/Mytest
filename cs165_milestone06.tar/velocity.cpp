/***********************************************************************
* Implementation File:
*    VELOCITY : Created for speed craft control.
* Author:
*    Br. Milton Nogueira B. Neto
* Summary:
*    Everything you need to know about not dying on the Moon.
************************************************************************/

#include "velocity.h"


/********************************************
* VELOCITY :: CONSTRUCTOR
********************************************/
Velocity::Velocity()
{

}


/********************************************
* VELOCITY :: CONSTRUCTOR
********************************************/
Velocity::Velocity(float, float)
{

}


/*********************************************
* VELOCITY :: GET DX
* 
*********************************************/
float Velocity :: getDx()
{
	float vel = 0;
	return vel;
}


/*********************************************
* VELOCITY :: GET DY
*
*********************************************/
float Velocity :: getDy()
{
	float vel = 0;
	return vel;
}


/*********************************************
* VELOCITY :: SET DX
*
*********************************************/
void Velocity::setDx(float)
{

}

/*********************************************
* VELOCITY :: SET DY
*
*********************************************/
void Velocity::setDy(float)
{
	
}

